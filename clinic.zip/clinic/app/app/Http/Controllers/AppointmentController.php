<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\App;

class AppointmentController extends Controller
{
    public $timestamps = true;

    public function __construct()
    {
        $this->middleware('auth', [
            'except' => [
                'makeAppointment',
                'getAll',
                'makeFullAppointment',
            ]
        ]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $currentUser = auth()->user();
        $appointmentType = 'admin';
        if($currentUser->role == 'clinic-client') {
            $request->patient_id = $currentUser->id;
            $appointmentType = 'client';
        }

        if($currentUser->role == 'clinic-admin' || $currentUser->role == 'clinic-staff') {
            $request->clinic_id = $currentUser->clinic_id;
            $appointmentType = 'clinic';
        }

        $this->cancelAppointments();
        $request->limit = 20;
        $appointments = $this->queryAppointments($request);
        
        return view('pages.appointments.index', [
            'appointments' => $appointments,
            'request' => $request,
            'appointmentType' => $appointmentType,
        ])
        ->with('i',(request()->input('page',1) - 1) * 20);
    }

    public function getAll(Request $request)
    {
        $currentUser = auth()->user();
        $appointments = $this->queryAppointments($request);
        
        return [
            'request' => $request->all(),
            'data' => $appointments,
        ];
    }

    public function queryAppointments($request)
    {
        $appointments = DB::table('appointments')
        ->select(
            'appointments.id AS appointment_id', 
            'users.firstname', 
            'users.lastname', 
            'users.email', 
            'appointments.appointment_date', 
            'appointments.appointment_time', 
            'appointments.appointment_timeend', 
            'appointments.status',
            'clinics.name as clinic_name'
        )
        ->leftJoin('users', 'appointments.patient_id', '=', 'users.id')
        ->leftJoin('clinics', 'appointments.clinic_id', '=', 'clinics.id')
        ->where([
            [DB::raw('CONCAT(users.firstname, " ", users.lastname)'),'LIKE', "%{$request->name}%"],
            ['appointments.status','LIKE', $request->status],
        ])
        ->where(function($query) use ($request) {
            if (!empty($request->datefrom) && empty($request->dateto)) {
                $query->where('appointment_date', '>=', $request->datefrom);
            } elseif (empty($request->datefrom) && !empty($request->dateto)) {
                $query->where('appointment_date', '<=', $request->dateto);
            } elseif (!empty($request->datefrom) && !empty($request->dateto)) {
                $query->whereBetween('appointments.appointment_date', [$request->datefrom, $request->dateto]);
            }

            if (!empty($request->patient_id)) {
                $query->where('appointments.patient_id', '=', $request->patient_id);
            }

            if (!empty($request->clinic_id)) {
                $query->where('appointments.clinic_id', '=', $request->clinic_id);
            }
        })
        ->orderByDesc('appointments.appointment_date');

        if (isset($params['limit']) && !empty($params['limit'])) {
            $appointments = $appointments->paginate($params['limit']);
        } else {
            $appointments = $appointments->get();
        }

        return $appointments;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $currentUser = auth()->user();
        $params = [
            'patient_id' => '',
            'client_id' => '',
            'appointmentType' => 'admin',
        ];

        if($currentUser->role == 'clinic-client') {
            $params['patient_id'] = $currentUser->id;
            $params['appointmentType'] = "client";
        } elseif($currentUser->role == 'clinic-admin' || $currentUser->role == 'clinic-staff') {
            $params['clinic_id'] = $currentUser->clinic_id;
            $params['appointmentType'] = "clinic";
        }

        return view('pages.appointments.create-appointment', [
            'request' => $request,
            'params' => $params,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'id' => ['required'],
            'firstname' => ['required', 'string', 'max:255'],
            'lastname' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255'],
            'phone' => ['required', 'string', 'max:255'],
            'address' => ['string', 'max:255'],
            'appointment_date' => ['string', 'max:255'],
            'appointment_time' => ['string', 'max:255'],
            'status' => ['string', 'max:255'],
        ]);

        $data = [
            'patient_id' => $request->id,
            'pet_id' => $request->pet_id,
            'appointment_date' => $request->appointment_date,
            'appointment_time' => $request->appointment_time,
            'status' => $request->status,
            'message' => $request->message,
            'created_at' => now(),
            'updated_at' => now()
        ];
        DB::table('appointments')->insert($data);

        return redirect()->route('appointments.index')
        ->with('success','Succefully added an Appointment for <b>' . $request->firstname . ' ' . $request->lastname . '</b>');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $currentUser = auth()->user();
        $appointment = DB::table('appointments')
            ->select(
                'appointments.id AS appointment_id', 
                'appointments.clinic_id',
                'appointments.patient_id',
                'appointments.pet_id',
                'users.firstname', 
                'users.lastname', 
                'users.email', 
                'users.contact_no', 
                'users.address', 
                'appointments.appointment_date', 
                'appointments.appointment_time', 
                'appointments.appointment_timeend', 
                'appointments.services', 
                'appointments.status',
                'appointments.message',
                'appointments.findings',
                'pets.name AS pet_name',
                'pets.species AS pet_species',
                'pets.breed AS pet_breed',
                'pets.gender AS pet_gender',
                'pets.color AS pet_color',
                'pets.weight AS pet_weight',
                'pets.birthdate AS pet_birthdate',
                'clinics.name AS clinic_name',
            )
            ->leftJoin('users', 'appointments.patient_id', '=', 'users.id')
            ->leftJoin('pets', 'appointments.pet_id', '=', 'pets.id')
            ->leftJoin('clinics', 'appointments.clinic_id', '=', 'clinics.id')
            ->where([
                ['appointments.id','=', $id],
            ])
            ->first();

        $sameInfo = DB::table('patients')
            ->where(function ($query) use ($appointment) {
                $query->where([
                    ['firstname' , 'LIKE', $appointment->firstname],
                    ['lastname' , 'LIKE', $appointment->lastname]
                ])
                ->orWhere('email', 'LIKE', $appointment->email);
            })
            ->where([
                ['id', '<>', $appointment->patient_id]
            ])
            ->get();
        
        $pets = DB::table('pets')
            ->where([
                ['patient_id', '=', $appointment->patient_id]
            ])
            ->orderby('name')
            ->get();

        $services = DB::table('clinicservices')
            ->select('id', 'title', 'price')
            ->where([
                ['clinic_id', '=', $appointment->clinic_id]
            ])
            ->get();

        $readOnly = "";
        if ($currentUser->role === 'clinic-client') {
            $readOnly = "disabled";
        }
        return view('pages.appointments.edit', [
            'id' => $id,
            'appointment' => $appointment,
            'sameInfo' => $sameInfo,
            'pets' => $pets,
            'services' => $services,
            'readOnly' => $readOnly,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'firstname' => ['required', 'string', 'max:255'],
            'lastname' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255'],
            'phone' => ['required', 'string', 'max:255'],
            'appointment_date' => ['string', 'max:255'],
            'appointment_time' => ['string', 'max:255'],
            'status' => ['string', 'max:255'],
        ]);

        $data = [
            'pet_id' => $request->pet_id,
            'appointment_date' => $request->appointment_date,
            'appointment_time' => $request->appointment_time,
            'appointment_timeend' => $request->appointment_timeend,
            'services' => json_encode($request->services),
            'status' => $request->status,
            'message' => $request->message,
            'findings' => $request->findings,
            'updated_at' => now(),
        ];

        DB::table('appointments')
        ->where('id', $id)
        ->update($data);

        return redirect()->route('appointments.edit', $id)
        ->with('success','Succefully updated the appointment for <b>' . $request->firstname . ' ' . $request->lastname . '</b>');
    }

    public function quickUpdate(Request $request)
    {
        $this->validate($request,[
            'appointment_date' => ['string', 'max:255'],
            'appointment_time' => ['string', 'max:255'],
            'appointment_timeend' => ['string', 'max:255'],
            'status' => ['string', 'max:255'],
        ]);

        $data = [
            'appointment_date' => $request->appointment_date,
            'appointment_time' => $request->appointment_time,
            'appointment_timeend' => $request->appointment_timeend,
            'status' => $request->status,
            'updated_at' => now(),
        ];

        DB::table('appointments')
        ->where('id', $request->id)
        ->update($data);

        return redirect()->route('appointments.index', ['date' => $request->appointment_date])
        ->with('success','Succefully updated the appointment for <b>' . $request->name . '</b>');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $appointment = DB::table('appointments')
        ->where('id', $id)
        ->delete();

        return redirect()->route('appointments.index')
        ->with('success','Succefully deleted the appointment');
    }

    public function mergeRecord(Request $request) 
    {
        DB::table('appointments')
        ->where('patient_id', $request->child)
        ->update([
            'patient_id' => $request->parent
        ]);

        DB::table('patients')
        ->where('id', $request->child)
        ->delete();

        return redirect()->route('appointments.edit', $request->appointment_id);
    }

    /**
     * Store a newly created appointment from frontend.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function makeAppointment(Request $request)
    {
        $this->validate($request, [
            'firstname' => ['required', 'string', 'max:255'],
            'lastname' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255'],
            'phone' => ['required', 'string', 'max:255'],
            'address' => ['string', 'max:255'],
            'appointment_date' => ['required', 'string', 'max:255'],
            'appointment_time' => ['required', 'string', 'max:255'],
        ]);
        $patient = DB::table('patients')
        ->where([
            // [DB::raw('CONCAT(patients.firstname, " ", patients.lastname)'),'LIKE', "%{$request->firstname}%"],
            ['firstname','LIKE', $request->firstname],
            ['lastname','LIKE', $request->lastname],
        ])
        ->orWhere('email', 'LIKE', $request->email)
        ->first();

        if (!$patient) {
            $this->validate($request,[
                'firstname' => ['required', 'string', 'max:255'],
                'lastname' => ['required', 'string', 'max:255'],
                'email' => ['required', 'string', 'email', 'max:255', 'unique:patients'],
            ]);
    
            $data = [
                'firstname' => $request->firstname,
                'lastname' => $request->lastname,
                'email' => $request->email,
                'phone' => $request->phone,
                'address' => $request->address,
                'created_at' => now(),
                'updated_at' => now()
            ];
            DB::table('patients')->insert($data);

            $patient = DB::table('patients')
            ->where([
                ['firstname','LIKE', $request->firstname],
                ['lastname','LIKE', $request->lastname],
            ])
            ->orWhere('email', 'LIKE', $request->email)
            ->first();
        } else {
            $this->validate($request,[
                'firstname' => ['required', 'string', 'max:255'],
                'lastname' => ['required', 'string', 'max:255'],
                'email' => ['required', 'string', 'email', 'max:255'],
            ]);
    
            $data = [
                'firstname' => $request->firstname,
                'lastname' => $request->lastname,
                'email' => $request->email,
                'phone' => $request->phone,
                'address' => $request->address,
                'updated_at' => now()
            ];
    
            DB::table('patients')
            ->where('id', $patient->id)
            ->update($data);
        }

        $data = [
            'clinic_id' => $request->clinic_id,
            'patient_id' => $patient->id,
            'appointment_date' => $request->appointment_date,
            'appointment_time' => $request->appointment_time,
            'service_id' => $request->service_id,
            'status' => 'pending',
            'message' => $request->message,
            'created_at' => now(),
            'updated_at' => now()
        ];
        DB::table('appointments')->insert($data);

        return redirect()->route('thankyou')
        ->with('success','Your appointment has been sent.');
    }
    /**
     * Cancel all Approved/Pending Appointment beyond the current data
     */
    public function cancelAppointments()
    {
        $data = [
            'status' => 'cancelled',
            'updated_at' => now(),
        ];

        $cancelAppointments = DB::table('appointments')
        ->whereDate('appointment_date', '<', date('Y-m-d'))
        ->whereIn('status', ['pending', 'approved'])
        ->update($data);
    }

    public function makeFullAppointment(Request $request)
    {
        $petInfo = $request->selectedPet;
        $petID = $petInfo['id'];

        if (isset($petInfo)) {
            $petData = [
                'patient_id' => $request->patientID,
                'name' => $petInfo['name'],
                'species' => $petInfo['species'],
                'breed' => $petInfo['breed'],
                'birthdate' => $petInfo['birthdate'],
                'gender' => $petInfo['gender'],
                'color' => $petInfo['color'],
                'weight' => $petInfo['weight'],
                'clinics' => $petInfo['clinics'],
                'updated_at' => now()
            ];

            $petData['clinics'][] = $request->clinic['id'];
            $petData['clinics'] = array_unique($petData['clinics']);

            if ($petInfo['id']) {
                DB::table('pets')
                ->where('id', $petInfo['id'])
                ->update($petData);
            } else {
                $petData['clinics'] = json_encode([$request->clinic['id']]);
                $petData['created_at'] = now();
                $petID = DB::table('pets')->insertGetId($petData);
            }
        }

        $time = new \DateTime($request->time);
        $time->add(new \DateInterval("PT1H"));
        $timeEnd = $time->format("H:i");

        $datetime = new \DateTime($request->date);
        $appointmentDate = $datetime->format("Y-m-d");

        $appointmentData = [
            'clinic_id' => $request->clinic['id'],
            'patient_id' => $request->patientID,
            'pet_id' => $petID,
            'appointment_date' => $appointmentDate,
            'appointment_time' => $request->time,
            'appointment_timeend' => $timeEnd,
            'services' => json_encode($request->services),
            'message' => '',
            'findings' => '',
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ];

        $appointmentID = DB::table('appointments')->insertGetId($appointmentData);

        return [
            'success' => true,
            'id' => $appointmentID,
            'data' => $appointmentData,
        ];
    }
}
