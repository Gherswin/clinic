<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
// use App\Providers\RouteServiceProvider;
// use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function submit(Request $request)
    {
        $this->validate($request,[
          'username' => 'required',
          'password'=> 'required',
        ]);
        
        $username = $request->input('username');
        $password = $request->input('password');
        $redirect = $request->input('redirect');

        if(Auth::attempt(['email' => $username,'password' => $password, 'status' => 'active'])){
            $request->session()->regenerate();
            if ($redirect) {
                return redirect(rawurldecode($redirect))->with('status','Successfully login');
            }
            return redirect('/dashboard')->with('status','Successfully login');
        }

        if(Auth::attempt(['username' => $username,'password' => $password, 'status' => 'active'])){
            $request->session()->regenerate();

            if ($redirect) {
                return redirect(rawurldecode($redirect))->with('status','Successfully login');
            }

            return redirect('/dashboard')->with('status','Successfully login');
        }

        if ($redirect) {
            return redirect('/login?redirect=' . $redirect)->with('error','Invalid username or password');
        }
        return redirect('/login')->with('error','Invalid username or password');
    }
    
    public function showLoginForm(Request $request)
    {
        if (Auth::check()) {
            return redirect()->route('dashboard');
        } else {
            return view('pages.password.login', [
                'redirect' => $request->redirect,    
            ]);
        }
    }

    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/login');
    }
}
