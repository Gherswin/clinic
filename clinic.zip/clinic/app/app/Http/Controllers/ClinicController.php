<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ClinicController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth', [
            'except' => [
                'show',
                'getClinics',
                'getAll',
            ]
        ]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $currentUser = auth()->user();
        if($currentUser->role != 'admin') {
            return redirect()->route('dashboard');
        }

        $clinics = DB::table('clinics')
        ->where([
            ['name','LIKE', "%{$request->name}%"],
            ['address','LIKE', "%{$request->address}%"],
        ])
        ->paginate(20);

        return view('pages.clinics.index', [
            'clinics' => $clinics,
            'request' => $request
        ])
        ->with('i',(request()->input('page',1) - 1) * 20);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $currentUser = auth()->user();
        if($currentUser->role != 'admin') {
            return redirect()->route('dashboard');
        }

        $clinicUsers = DB::table('users')
            ->where('role', '=', 'clinic-admin')
            ->orderBy('firstname', 'ASC')
            ->get();
        return view('pages.clinics.create',[
            'clinicUsers' => $clinicUsers,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            // 'user_id' => ['required', 'string'],
            'name' => ['required', 'string', 'max:255'],
            'address' => ['required', 'string', 'max:255'],
            // 'email' => ['required', 'string', 'email', 'max:255'],
        ]);

        $imageName = "";
        if (!empty($request->image)) {
            $imageName = time(). '.' . $request->image->extension();  
            $request->image->move(public_path('images/clinics'), $imageName);
        }

        $operatingHours = [];
        if (!empty($request->mon_timestart) || !empty($request->mon_timeend)) {
            $operatingHours[] = [
                'day'=> "mon",
                'timestart'=> $request->mon_timestart,
                'timeend'=> $request->mon_timeend,
            ];
        }
        if (!empty($request->tue_timestart) || !empty($request->tue_timeend)) {
            $operatingHours[] = [
                'day'=> "tue",
                'timestart'=> $request->tue_timestart,
                'timeend'=> $request->tue_timeend,
            ];
        }
        if (!empty($request->wed_timestart) || !empty($request->wed_timeend)) {
            $operatingHours[] = [
                'day'=> "wed",
                'timestart'=> $request->wed_timestart,
                'timeend'=> $request->wed_timeend,
            ];
        }
        if (!empty($request->thu_timestart) || !empty($request->thu_timeend)) {
            $operatingHours[] = [
                'day'=> "thu",
                'timestart'=> $request->thu_timestart,
                'timeend'=> $request->thu_timeend,
            ];
        }
        if (!empty($request->fri_timestart) || !empty($request->fri_timeend)) {
            $operatingHours[] = [
                'day'=> "fri",
                'timestart'=> $request->fri_timestart,
                'timeend'=> $request->fri_timeend,
            ];
        }
        if (!empty($request->sat_timestart) || !empty($request->sat_timeend)) {
            $operatingHours[] = [
                'day'=> "sat",
                'timestart'=> $request->sat_timestart,
                'timeend'=> $request->sat_timeend,
            ];
        }
        if (!empty($request->sun_timestart) || !empty($request->sun_timeend)) {
            $operatingHours[] = [
                'day'=> "sun",
                'timestart'=> $request->sun_timestart,
                'timeend'=> $request->sun_timeend,
            ];
        }

        $data = [
            'user_id' => $request->user_id,
            'name' => $request->name,
            'address' => $request->address,
            'email' => $request->email,
            'contact_no' => $request->contact_no,
            'operating_hours' => serialize($operatingHours),
            'image' => $imageName,
            'updated_at' => now()
        ];
        DB::table('clinics')->insert($data);

        return redirect()->route('clinics.index')
        ->with('success','Succefully added <b>' . $request->name  . '</b>');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $clinic = DB::table('clinics')->find($id);
        $services = DB::table('clinicservices')
            ->where([
                ['clinic_id', '=', $clinic->id]
            ])
            ->get();

        return view('pages.clinics.show',[
            'clinic' => $clinic,
            'services' => $services,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $currentUser = auth()->user();
        if($currentUser->role == 'clinic-client') {
            return redirect()->route('dashboard');
        }
        if(($currentUser->role == 'clinic-admin' || $currentUser->role == 'clinic-staff') && $id !== $currentUser->clinic_id) {
            return redirect()->route('dashboard');
        }
        
        $clinic = DB::table('clinics')->find($id);
        // $mainContact = DB::table('users')->find($clinic->user_id);
        $clinicUsers = DB::table('users')
            ->where('clinic_id', '=', $clinic->id)
            ->orderBy('firstname', 'ASC')
            ->get();

        if($clinic->operating_hours) {
            $operatingHours = unserialize($clinic->operating_hours);
            foreach($operatingHours as $time) {
                $clinic->{$time['day'] . "_timestart"} = $time['timestart'];
                $clinic->{$time['day'] . "_timeend"} = $time['timeend'];
            } 
        }

        $services = DB::table('clinicservices')
            ->where([
                ['clinic_id', '=', $clinic->id]
            ])
            ->get();

        return view('pages.clinics.edit', [
            'clinic' => $clinic,
            'clinicUsers' => $clinicUsers,
            'services' => $services,
        ])->with('i',(request()->input('page',1) - 1) * 20);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            // 'user_id' => ['required', 'string'],
            'name' => ['required', 'string', 'max:255'],
            'address' => ['required', 'string', 'max:255'],
            // 'email' => ['required', 'string', 'email', 'max:255'],
        ]);
        
        $imageName = "";
        if (!empty($request->image)) {
            $imageName = time(). '.' . $request->image->extension();  
            $request->image->move(public_path('images/clinics'), $imageName);
        }

        $operatingHours = [];
        if (!empty($request->mon_timestart) || !empty($request->mon_timeend)) {
            $operatingHours[] = [
                'day'=> "mon",
                'timestart'=> $request->mon_timestart,
                'timeend'=> $request->mon_timeend,
            ];
        }
        if (!empty($request->tue_timestart) || !empty($request->tue_timeend)) {
            $operatingHours[] = [
                'day'=> "tue",
                'timestart'=> $request->tue_timestart,
                'timeend'=> $request->tue_timeend,
            ];
        }
        if (!empty($request->wed_timestart) || !empty($request->wed_timeend)) {
            $operatingHours[] = [
                'day'=> "wed",
                'timestart'=> $request->wed_timestart,
                'timeend'=> $request->wed_timeend,
            ];
        }
        if (!empty($request->thu_timestart) || !empty($request->thu_timeend)) {
            $operatingHours[] = [
                'day'=> "thu",
                'timestart'=> $request->thu_timestart,
                'timeend'=> $request->thu_timeend,
            ];
        }
        if (!empty($request->fri_timestart) || !empty($request->fri_timeend)) {
            $operatingHours[] = [
                'day'=> "fri",
                'timestart'=> $request->fri_timestart,
                'timeend'=> $request->fri_timeend,
            ];
        }
        if (!empty($request->sat_timestart) || !empty($request->sat_timeend)) {
            $operatingHours[] = [
                'day'=> "sat",
                'timestart'=> $request->sat_timestart,
                'timeend'=> $request->sat_timeend,
            ];
        }
        if (!empty($request->sun_timestart) || !empty($request->sun_timeend)) {
            $operatingHours[] = [
                'day'=> "sun",
                'timestart'=> $request->sun_timestart,
                'timeend'=> $request->sun_timeend,
            ];
        }

        $data = [
            'user_id' => $request->user_id,
            'name' => $request->name,
            'address' => $request->address,
            'email' => $request->email,
            'contact_no' => $request->contact_no,
            'operating_hours' => serialize($operatingHours),
            'updated_at' => now()
        ];

        if (!empty($request->image)) {
            $data['image'] = $imageName;
        }

        DB::table('clinics')
        ->where('id', $id)
        ->update($data);
        
        return redirect()->route('clinics.edit', $id)
        ->with('success','Succefully updated <b>' . $request->name . '</b>');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $patients = DB::table('patients')
        ->where('id', $id)
        ->delete();

        return redirect()->route('patients.index')
        ->with('success','Succefully deleted the record');
    }

    /*
     * Front End
     */
    public function getClinics(Request $request)
    {
        $clinics = DB::table('clinics')
        ->where(function($query) use ($request) {
            if (!empty($request->search)) {
                $query->where('clinics.name', 'LIKE', "%{$request->search}%")
                    ->orWhere('clinics.address', 'LIKE', "%{$request->search}%");
            }
        })
        // ->leftJoin('clinics', 'clinics.user_id', '=', 'users.id')
        ->orderBy('clinics.name', 'ASC')
        ->paginate(20);

        return view('pages.frontend.clinics', [
            'clinics' => $clinics,
            'request' => $request
        ])
        ->with('i',(request()->input('page',1) - 1) * 20);
    }

    /*
     * API
     */
    public function getAll(Request $request)
    {
        $result = [];
        $clinics = DB::table('clinics')
        ->where(function($query) use ($request) {
            if (!empty($request->search)) {
                $query->where('clinics.name', 'LIKE', "%{$request->search}%")
                    ->orWhere('clinics.address', 'LIKE', "%{$request->search}%");
            } 
            if (!empty($request->id)) {
                $query->where('clinics.id', '=', $request->id);
            }
        })
        
        ->orderBy('clinics.name', 'ASC');
        
        if (isset($request->limit) && !empty($request->limit) ) {
            $result = $clinics->paginate($request->limit);
        }

        $result = [ 'data' => $clinics->get() ];

        if ($result['data']) {
            foreach($result['data'] as $key => $data) {
                $result['data'][$key]->operating_hours = unserialize( $data->operating_hours);
            }
        }

        return $result;
    }
}
