<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth', [
            'except' => [
                'homepage',
            ]
        ]);
    }

    public function homepage(Request $request)
    {
        $clinics = DB::table('clinics')
        ->orderBy('name', 'ASC')
        ->get();

        return view('pages.frontend.index', [
            'clinics' => $clinics,
        ]); 
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {        
        $currentUser = auth()->user();
        if($currentUser->role == 'clinic-client') {
            $myAppointments = DB::table('appointments')
            ->select(
                'appointments.id AS appointment_id', 
                'patients.firstname', 
                'patients.lastname', 
                'appointments.appointment_date', 
                'appointments.appointment_time', 
                'appointments.status', 
            )
            ->leftJoin('patients', 'appointments.patient_id', '=', 'patients.id')
            // ->whereBetween('appointment_date', [ date("Y-m-d"), date("Y-m-d", strtotime('sunday this week'))])
            ->where([
                ['patient_id', '=', $currentUser->id]
            ])
            ->orderby('appointment_date')
            ->get();

            return view('pages.dashboard.client', [
                'myAppointments' => $myAppointments,
            ]);
        }

        // $startDate = (strtotime(date('Y-m-d')) > strtotime('monday this week')) ?
        $thisWeekAppointments = DB::table('appointments')
        ->select(
            'appointments.id AS appointment_id', 
            'users.firstname', 
            'users.lastname', 
            'appointments.appointment_date', 
            'appointments.appointment_time', 
            'appointments.status', 
        )
        ->leftJoin('users', 'appointments.patient_id', '=', 'users.id')
        ->whereBetween('appointment_date', [ date("Y-m-d"), date("Y-m-d", strtotime('sunday this week'))])
        ->where([
            ['appointments.status', '=', 'approved']
        ])
        ->orderby('appointment_date');

        if ($currentUser->role == "clinic-admin" || $currentUser->role == "clinic-staff") {
            $thisWeekAppointments = $thisWeekAppointments->where('appointments.clinic_id', '=', $currentUser->clinic_id);
        } 

        $thisWeekAppointments = $thisWeekAppointments->get();

        $pendingAppointments = DB::table('appointments')
        ->select(
            'appointments.id AS appointment_id', 
            'users.firstname', 
            'users.lastname', 
            'appointments.appointment_date', 
            'appointments.appointment_time', 
            'appointments.status', 
        )
        ->leftJoin('users', 'appointments.patient_id', '=', 'users.id')
        ->where([
            ['appointments.status', 'LIKE', 'pending']
        ])
        ->orderby('appointment_date');
        
        if ($currentUser->role == "clinic-admin" || $currentUser->role == "clinic-staff") {
            $pendingAppointments = $pendingAppointments->where('appointments.clinic_id', '=', $currentUser->clinic_id);
        } 

        $pendingAppointments = $pendingAppointments->get();

        return view('pages.dashboard.index', [
            'thisWeekAppointments' => $thisWeekAppointments,
            'pendingAppointments' => $pendingAppointments,
        ]);
    }
}
