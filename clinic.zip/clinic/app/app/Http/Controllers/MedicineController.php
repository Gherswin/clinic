<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MedicineController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth', [
            'except' => [
                'getItems'
            ]
        ]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $medicines = DB::table('itemsummary')
        ->where([
            ['item_code','LIKE', "%{$request->item_code}%"],
            ['item_name','LIKE', "%{$request->item_name}%"],
            ['item_classification','LIKE', "%{$request->item_classification}%"],
        ])
        ->orderby('item_code')
        ->paginate(20);

        return view('pages.medicines.index', [
            'medicines' => $medicines,
            'request' => $request
        ])
        ->with('i',(request()->input('page',1) - 1) * 20);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pages.medicines.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'item_code' => ['required', 'string', 'max:255'],
            'item_name' => ['required', 'string', 'max:255'],
            'item_classification' => ['required', 'string', 'max:255'],
            'orig_price' => ['required', 'string', 'max:255'],
            'retail_price' => ['required', 'string', 'max:255'],
        ]);

        $data = [
            'item_code' => $request->item_code,
            'item_name' => $request->item_name,
            'item_classification' => $request->item_classification,
            'orig_price' => $request->orig_price,
            'retail_price' => $request->retail_price,
            'created_at' => now(),
            'updated_at' => now()
        ];

        DB::table('items')->insert($data);

        return redirect()->route('medicines.index')
        ->with('success','Succefully added <b>' . $request->item_code . ' -  ' . $request->item_name . '</b>');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id, Request $request)
    {
        $medicine = DB::table('itemsummary')
        ->where([
            ['id','=', $id],
        ])
        ->first();

        // Get Stocks History
        $stocks = DB::table('itemstocks')
        ->where([
            ['item_id', 'LIKE', $id],
        ])
        ->orderByDesc('created_at')
        ->paginate(10);
        
        // Get Purchases History
        $purchases = DB::table('purchasedetails')
        ->where([
            ['item_id', 'LIKE', $id],
        ])
        ->orderByDesc('created_at')
        ->paginate(10);
        
        return view('pages.medicines.edit', [
            'medicine' => $medicine,
            'stocks' => $stocks,
            'purchases' => $purchases,
        ])->with('i',(request()->input('page',1) - 1) * 20);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'item_code' => ['required', 'string', 'max:255'],
            'item_name' => ['required', 'string', 'max:255'],
            'item_classification' => ['required', 'string', 'max:255'],
            'orig_price' => ['required', 'string', 'max:255'],
            'retail_price' => ['required', 'string', 'max:255'],
        ]);

        $data = [
            'item_code' => $request->item_code,
            'item_name' => $request->item_name,
            'item_classification' => $request->item_classification,
            'orig_price' => $request->orig_price,
            'retail_price' => $request->retail_price,
            'created_at' => now(),
            'updated_at' => now()
        ];

        DB::table('items')
        ->where('id', $id)
        ->update($data);
        
        return redirect()->route('medicines.edit', $id)
        ->with('success','Succefully updated <b>' . $request->item_code . ' - ' . $request->item_name . '</b>');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $appointment = DB::table('items')
        ->where('id', $id)
        ->delete();

        return redirect()->route('medicines.index')
        ->with('success','Succefully deleted the record');
    }

    public function getItems(Request $request) 
    {
        $medicines = DB::table('itemsummary')
        ->where([
            ['item_code','LIKE', "%{$request->item_code}%"],
            ['item_name','LIKE', "%{$request->item_name}%"],
            ['item_classification','LIKE', "%{$request->item_classification}%"],
            [DB::raw('ABS(total_qty - total_purchase)'), '>=', (int)$request->stocks],
        ])
        ->where(function($query) use ($request) {
            if (isset($request->s)) {
                $query->orWhere('item_code', 'LIKE', "%{$request->s}%");
                $query->orWhere('item_name', 'LIKE', "%{$request->s}%");
                $query->orWhere('item_classification', 'LIKE', "%{$request->s}%");
            }
        })
        ->orderby('item_code')
        ->paginate(20);

        return $medicines;
    }
}
