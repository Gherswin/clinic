<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class PatientController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth', [
            'except' => [
                'getAll'
            ]
        ]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $currentUser = auth()->user();
        if($currentUser->role != 'admin') {
            return redirect()->route('dashboard');
        }

        $patients = DB::table('users')
        ->where([
            ['firstname','LIKE', "%{$request->firstname}%"],
            ['lastname','LIKE', "%{$request->lastname}%"],
            ['role','=', "clinic-client"],
        ])
        ->paginate(20);

        return view('pages.patients.index', [
            'patients' => $patients,
            'request' => $request
        ])
        ->with('i',(request()->input('page',1) - 1) * 20);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $currentUser = auth()->user();
        if($currentUser->role != 'admin') {
            return redirect()->route('dashboard');
        }

        return view('pages.patients.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'firstname' => ['required', 'string', 'max:255'],
            'lastname' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
        ]);

        $data = [
            'firstname' => $request->firstname,
            'lastname' => $request->lastname,
            'email' => $request->email,
            'contact_no' => $request->contact_no,
            'address' => $request->address,
            'password' => Str::random(8),
            'role' => 'clinic-client',
            'created_at' => now(),
            'updated_at' => now()
        ];
        DB::table('users')->insert($data);

        return redirect()->route('patients.index')
        ->with('success','Succefully added <b>' . $request->firstname . ' ' . $request->lastname . '</b>');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $currentUser = auth()->user();
        if($currentUser->role != 'admin') {
            return redirect()->route('dashboard');
        }
        
        $patient = DB::table('users')->find($id);

        $appointments = DB::table('appointments')
        ->where([
            ['patient_id', '=', $id]
        ])
        ->orderByDesc('appointments.appointment_date')
        ->paginate(10);

        return view('pages.patients.edit', [
            'patient' => $patient,
            'appointments' => $appointments,
        ])->with('i',(request()->input('page',1) - 1) * 20);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'firstname' => ['required', 'string', 'max:255'],
            'lastname' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255'],
        ]);

        $data = [
            'firstname' => $request->firstname,
            'lastname' => $request->lastname,
            'email' => $request->email,
            'contact_no' => $request->contact_no,
            'address' => $request->address,
            'updated_at' => now()
        ];

        DB::table('users')
        ->where('id', $id)
        ->update($data);
        
        return redirect()->route('patients.edit', $id)
        ->with('success','Succefully updated <b>' . $request->firstname . ' ' . $request->lastname . '</b>');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $patients = DB::table('patients')
        ->where('id', $id)
        ->delete();

        return redirect()->route('patients.index')
        ->with('success','Succefully deleted the record');
    }

    /*
     * API
     */
    public function getAll(Request $request)
    {
        $patients = DB::table('patients')
        ->select('id',DB::raw('CONCAT(firstname, " ", lastname) as fullname'), 'firstname', 'lastname', 'email', 'phone', 'address')
        ->where([
            [DB::raw('CONCAT(firstname, " ", lastname)'),'LIKE', "%{$request->name}%"],
            ['email','LIKE', $request->email],
            ['id','LIKE', $request->id],
        ])
        ->orWhere('email', $request->oremail)
        ->orderByDesc('id');
        
        if (isset($request->limit) && !empty($request->limit) ) {
            return $patients->paginate($request->limit);
        }

        return [ 'data' => $patients->get() ];
    }
}
