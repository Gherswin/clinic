<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PetController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth', [
            'except' => [
                'getPets'
            ]
        ]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $currentUser = auth()->user();
        $appointmentType = 'admin';
        if($currentUser->role == 'clinic-client') {
            $request->patient_id = $currentUser->id;
            $appointmentType = 'client';
        }

        if($currentUser->role == 'clinic-admin' || $currentUser->role == 'clinic-staff') {
            $request->clinic_id = $currentUser->clinic_id;
            $appointmentType = 'clinic';
        }
        $pets = DB::table('pets')
        ->select(
            'pets.id AS pet_id',
            'users.firstname as firstname',
            'users.lastname as lastname',
            'pets.name AS name',
            'pets.species AS species',
            'pets.breed AS breed',
        )
        ->leftJoin('users', 'pets.patient_id', '=', 'users.id')
        ->where([
            [DB::raw('CONCAT(users.firstname, " ", users.lastname)'),'LIKE', "%{$request->owner}%"],
            ['name','LIKE', $request->pet_name],
            ['species','LIKE', $request->species],
            ['breed','LIKE', $request->breed],
        ])
        ->where(function($query) use ($request) {
            if (!empty($request->patient_id)) {
                $query->where('pets.patient_id', '=', $request->patient_id);
            }

            if (!empty($request->clinic_id)) {
                $query->whereJsonContains('pets.clinics', $request->clinic_id);
            }
        })
        ->paginate(20);

        return view('pages.pets.index', [
            'pets' => $pets,
            'request' => $request
        ])
        ->with('i',(request()->input('page',1) - 1) * 20);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $patients = DB::table('users')
        ->select(
            'id',
            'firstname',
            'lastname',
        )
        ->orderby('firstname')
        ->where('role', '=', 'clinic-client')
        ->get();
        
        return view('pages.pets.create', [
            'patients' => $patients,
            'request' => $request,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'patient_id' => ['required'],
            'name' => ['required', 'string', 'max:255'],
            'species' => ['required', 'string', 'max:255'],
            'breed' => ['required', 'string', 'max:255'],
            'gender' => ['required', 'string', 'max:255'],
            'weight' => ['required'],
        ]);

        $currentUser = auth()->user();
        $appointmentType = 'admin';
        if($currentUser->role == 'clinic-client') {
            $request->patient_id = $currentUser->id;
            $appointmentType = 'client';
        }

        if($currentUser->role == 'clinic-admin' || $currentUser->role == 'clinic-staff') {
            $request->clinic_id = $currentUser->clinic_id;
            $appointmentType = 'clinic';
        }
        $data = [
            'patient_id' => $request->patient_id,
            'name' => $request->name,
            'species' => $request->species,
            'breed' => $request->breed,
            'birthdate' => $request->birthdate,
            'gender' => $request->gender,
            'color' => $request->color,
            'weight' => $request->weight,
            'clinics' => json_encode([$request->clinic_id]),
            'created_at' => now(),
            'updated_at' => now()
        ];
        DB::table('pets')->insert($data);

        return redirect()->route('pets.index')
        ->with('success','Succefully added <b>' . $request->name . ' - ' . $request->species . '</b>');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pet = DB::table('pets')->find($id);

        $patients = DB::table('users')
        ->select(
            'id',
            'firstname',
            'lastname',
        )
        ->orderby('firstname')
        ->where('role', '=', 'clinic-client')
        ->get();

        $appointments = DB::table('appointments')
        ->where([
            ['pet_id', '=', $id]
        ])
        ->orderByDesc('appointments.appointment_date')
        ->paginate(10);


        return view('pages.pets.edit', [
            'pet' => $pet,
            'patients' => $patients,
            'appointments' => $appointments,
        ])->with('i',(request()->input('page',1) - 1) * 20);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'patient_id' => ['required'],
            'name' => ['required', 'string', 'max:255'],
            'species' => ['required', 'string', 'max:255'],
            'breed' => ['required', 'string', 'max:255'],
            'gender' => ['required', 'string', 'max:255'],
            'weight' => ['required'],
        ]);

        $data = [
            'patient_id' => $request->patient_id,
            'name' => $request->name,
            'species' => $request->species,
            'breed' => $request->breed,
            'birthdate' => $request->birthdate,
            'gender' => $request->gender,
            'color' => $request->color,
            'weight' => $request->weight,
            'created_at' => now(),
            'updated_at' => now()
        ];

        DB::table('pets')
        ->where('id', $id)
        ->update($data);
        
        return redirect()->route('pets.edit', $id)
        ->with('success','Succefully added <b>' . $request->name . ' - ' . $request->species . '</b>');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $pets = DB::table('pets')
        ->where('id', $id)
        ->delete();

        return redirect()->route('pets.index')
        ->with('success','Succefully deleted the record');
    }

    public function getPets(Request $request) 
    {
        $pets = DB::table('pets')
        ->where([
            ['patient_id','LIKE', $request->patient_id],
        ])
        ->orderby('name');
        
        if (isset($request->limit) && !empty($request->limit) ) {
            return $pets->paginate($request->limit);
        }
        $results = $pets->get();

        $results = $results->map(function($item) {
            $item->clinics = json_decode($item->clinics);
            return $item;
        });
        
        return [ 'data' => $results ];
    }
}
