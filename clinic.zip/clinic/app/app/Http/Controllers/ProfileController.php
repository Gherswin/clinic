<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class ProfileController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function profile()
    {
        $user = auth()->user();

        return view('pages.profile.profile', [
            'staff' => $user,
        ]);
    }

    public function submit(Request $request)
    {
        $currentUser = auth()->user();
        $this->validate($request, [
            'firstname' => ['required', 'string', 'max:255'],
            'lastname' => ['required', 'string', 'max:255'],
        ]);

        $user = User::where('id', $currentUser->id)->first();
        $user->firstname = $request->firstname;
        $user->lastname = $request->lastname;
        $user->save();

        if ($currentUser->role == 'clinic-client') {
            $patient = [
                'firstname' => $request->firstname,
                'lastname' => $request->lastname,
                'email' => $request->email,
                // 'phone' => $request->phone,
                // 'address' => $request->address,
                'updated_at' => now()
            ];
    
            DB::table('patients')
            ->where('email', $request->email)
            ->update($patient);
        }

        return redirect()->route('profile')
        ->with('success','Succefully updated your profile');
    }

    public function changePassword(Request $request)
    {
        $currentUser = auth()->user();

        $this->validate($request, [
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'old_password' => [
                'required', 
                'string', 
                'min:8', 
                function($attr, $val, $fail) use ($currentUser) {
                  
                    if (!Hash::check($val, $currentUser->password)) {
                        $fail("Old Password did not match");
                    }
                }
            ]
        ]);

        $user = User::where('id', $currentUser->id)->first();
        $user->password = Hash::make($request->password);
        $user->save();

        return back()
        ->with('success','Your password has been updated');
    }
}
