<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class RegisterController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }
    
    public function makeAppointment()
    {
        return view('pages.frontend.make-appointment', [
            
        ]);
    }

    public function signUp(Request $request)
    {
        return view('pages.frontend.sign-up', [
            'redirect' => $request->redirect
        ]);
    }

    public function submitSignUp(Request $request)
    {
        $this->validate($request, [
            'firstname' => ['required', 'string', 'max:255'],
            'lastname' => ['required', 'string', 'max:255'],
            'contact_no' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        $data = [
            'firstname' => $request->firstname,
            'lastname' => $request->lastname,
            'email' => $request->email,
            'contact_no' => $request->contact_no,
            'clinic_id' => 0,
            'status' => 'active',
            'role' => 'clinic-client',
            'password' => Hash::make($request->password),
            'created_at' => now(),
            'updated_at' => now()
        ];
        
        DB::table('users')->insert($data);

        $params = [
            'clinic_id' => $request->clinic
        ];
        
        if(Auth::attempt(['email' => $request->email,'password' => $request->password, 'status' => 'active'])){
            $request->session()->regenerate();

            if ($request->redirect) {
                return redirect(rawurldecode($request->redirect))->with('status','Successfully login');
            }

            return redirect()->route('appointments.create', $params);
        }

    }

    public function submit(Request $request)
    {
        $currentUser = auth()->user();
        $this->validate($request, [
            'firstname' => ['required', 'string', 'max:255'],
            'lastname' => ['required', 'string', 'max:255'],
        ]);

    }
}
