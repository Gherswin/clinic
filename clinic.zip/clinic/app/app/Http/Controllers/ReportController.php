<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function productsReport(Request $request)
    {
        $monthBack = isset($request->month_back) ? $request->month_back : 6;
        $monthBack = date('Y-m-01', strtotime("-{$monthBack} months"));

        if (isset($request->medicine) && !empty($request->medicine)) {
            $report = DB::table('purchasedetails')
            ->select(
                DB::raw('extract(YEAR from created_at) AS purchase_year'),
                DB::raw('extract(MONTH from created_at) AS purchase_month'),
                DB::raw('SUM(qty * price) AS total_sales')
            )
            ->where([
                // ['created_at','LIKE',  date("m-Y", strtotime("-1 months")) . "%"] ,
                ['created_at','>',  $monthBack],
                ['item_id','=',$request->medicine]
            ])
            ->groupBy(DB::raw('extract(YEAR from created_at), extract(MONTH from created_at)'))
            ->get();
        } else {
            $report = DB::table('purchases')
            ->select(
                DB::raw('extract(YEAR from created_at) AS purchase_year'),
                DB::raw('extract(MONTH from created_at) AS purchase_month'),
                DB::raw('SUM(total_amount) AS total_sales')
            )
            ->where([
                // ['created_at','LIKE',  date("m-Y", strtotime("-1 months")) . "%"] ,
                ['created_at','>',  $monthBack],
            ])
            ->groupBy(DB::raw('extract(YEAR from created_at), extract(MONTH from created_at)'))
            ->get();
        }
        

        $medicines = DB::table('items')
        ->select('id','item_name')
        ->orderby('item_name')
        ->get();

        return view('pages.reports.products', [
            'request' => $request,
            'report' => $report,
            'medicines' => $medicines,
        ])
        ->with('i',(request()->input('page',1) - 1) * 20);
    }

    public function appointmentsReport(Request $request)
    {
        $monthBack = isset($request->month_back) ? $request->month_back : 6;
        $monthBack = date('Y-m-01', strtotime("-{$monthBack} months"));
        
        $report = DB::table('appointments')
        ->select(
            DB::raw('EXTRACT(YEAR from appointment_date) AS report_year'),
            DB::raw('EXTRACT(MONTH from appointment_date) AS report_month'),
            DB::raw('COUNT(id) AS total_appointments')
        )
        ->where([
            ['status','LIKE', 'done'],
            // ['created_at','>',  DB::raw("DATE_SUB(now(), INTERVAL {$monthBack} MONTH)")],
            ['appointment_date','>',  $monthBack],
        ])
        ->groupBy(DB::raw('extract(YEAR from appointment_date), extract(MONTH from appointment_date)'))
        ->get();

        return view('pages.reports.appointments', [
            'request' => $request,
            'report' => $report,
        ])
        ->with('i',(request()->input('page',1) - 1) * 20);
    }
}
