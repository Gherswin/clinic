<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ServiceController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth', [
            'except' => [
                'getAll',
            ]
        ]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'clinic_id' => ['required'],
            'title' => ['required', 'string', 'max:255'],
        ]);

        $data = [
            'clinic_id' => $request->clinic_id,
            'title' => $request->title,
            'description' => $request->description,
            'price' => $request->price,
            'created_at' => now(),
            'updated_at' => now()
        ];
        DB::table('clinicservices')->insert($data);

        return redirect()->route('clinics.edit', $request->clinic_id)
        ->with('success','Succefully added <b>' . $request->title . '</b>  as services');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'clinic_id' => ['required'],
            'title' => ['required', 'string', 'max:255'],
        ]);

        $data = [
            'clinic_id' => $request->clinic_id,
            'title' => $request->title,
            'description' => $request->description,
            'price' => $request->price,
            'updated_at' => now()
        ];

        DB::table('clinicservices')
            ->where('id', $id)
            ->update($data);
        
        return redirect()->route('clinics.edit', $request->clinic_id)
            ->with('success','Succefully Updated <b>' . $request->title . '</b>');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        $pets = DB::table('clinicservices')
            ->where('id', $id)
            ->delete();

        return redirect()->route('clinics.edit', $request->clinic_id)
            ->with('success','Succefully deleted the record');
    }

    /*
     * API
     */
    public function getAll(Request $request)
    {
        $data = DB::table('clinicservices')
        ->where(function($query) use ($request) {
            if (!empty($request->clinic_id)) {
                $query->where('clinic_id', '=', $request->clinic_id);
            }
        })
        ->orderBy('title', 'ASC');
        
        if (isset($request->limit) && !empty($request->limit) ) {
            return $data->paginate($request->limit);
        }

        return [ 'data' => $data->get() ];
    }
}
