<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Foundation\Auth\RegistersUsers;

class StaffController extends Controller
{
    use RegistersUsers;

    public function __construct()
    {
        $this->middleware('auth',[
            'except' => [
                'getClients',
            ]
        ]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $user = auth()->user();

        if($user->role != 'admin' && $user->role != 'clinic-admin') {
            return redirect()->route('dashboard');
        }

        $currentUser = auth()->user();
        $users = DB::table('users')
        ->where([
            ['firstname','LIKE', "%{$request->firstname}%"],
            ['lastname','LIKE', "%{$request->lastname}%"],
            ['role','LIKE', $request->role],
            ['status','LIKE', $request->status],
            ['id','<>', $currentUser->id],
            ['role','<>', 'clinic-client'],
        ]);

        if($user->role == 'clinic-admin') {
            $users = $users->where('clinic_id', '=', $currentUser->clinic_id);
        }
        
        
        $users = $users->paginate(20);

        return view('pages.staffs.index', [
            'staffs' => $users,
            'request' => $request
        ])
        ->with('i',(request()->input('page',1) - 1) * 20);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $user = auth()->user();

        if($user->role != 'admin' && $user->role != 'clinic-admin') {
            return redirect()->route('dashboard');
        }

        return view('pages.staffs.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = auth()->user();

        $this->validate($request, [
            'firstname' => ['required', 'string', 'max:255'],
            'lastname' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'username' => ['required', 'string', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        $data = [
            'firstname' => $request->firstname,
            'lastname' => $request->lastname,
            'username' => $request->username,
            'email' => $request->email,
            'role' => $request->role,
            'status' => $request->status,
            'password' => Hash::make($request->password),
        ];

        if($user->role == 'clinic-admin') {
           $data['clinic_id'] = $user->clinic_id;
        }

        DB::table('users')->insert($data);

        return redirect()->route('staffs.index')
        ->with('success','Succefully added <b>' . $request->firstname . ' ' . $request->lastname . '</b>');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $currentUser = auth()->user();
        if($currentUser->role != 'admin') {
            return redirect()->route('dashboard');
        }

        $user = User::find($id);
        $currentUser = auth()->user();

        if ($id == $currentUser->id) {
            return redirect()->route('staffs.index');
        }
        return view('pages.staffs.edit', [
            'staff' => $user,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'firstname' => ['required', 'string', 'max:255'],
            'lastname' => ['required', 'string', 'max:255'],
        ]);

        $user = User::where('id', $id)->first();
        $user->firstname = $request->firstname;
        $user->lastname = $request->lastname;
        $user->role = $request->role;
        $user->status = $request->status;
        $user->save();

        return redirect()->route('staffs.index')
        ->with('success','Succefully updated <b>' . $request->firstname . ' ' . $request->lastname . '</b>');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::find($id);
        $user->delete();

        return redirect()->route('staffs.index')
        ->with('success','Succefully deleted <b>' . $user->firstname . ' ' . $user->lastname . '</b>');
    }

    public function getClients(Request $request)
    {
        $users = DB::table('users')
        ->select(DB::raw('CONCAT(users.firstname, " ", users.lastname) as name'), 'id')
        ->where([
            ['firstname','LIKE', "%{$request->firstname}%"],
            ['lastname','LIKE', "%{$request->lastname}%"],
            ['role','=', 'clinic-client'],
        ])
        ->get();

        return $users;
    }
}
