import vue from 'vue/dist/vue.js';
import vuecal from 'vue-cal';

new vue({
    el: '#appointments',
    components: {
        'vue-cal': vuecal
    },
    data() {
        return {
            appointmentType: webInfo.appointmentType,
            formData: {
                date: webInfo.params.date,
                name: webInfo.params.name,
                status: webInfo.params.status,
                patient_id: webInfo.params.patient_id,
                clinic_id: webInfo.params.clinic_id,
            },
            appointments: [],
            selectedAppointment: {}
        }
    },
    methods: {
        async fetchAppointments({view, startDate, endDate, week}) {
            console.log('Fetching events', { view, startDate, endDate, week })
            let self = this
            let appointments = new Promise((resolve, reject) => {
                self.appointments = []
                self.formData.date = self.formatDate(startDate)
                self.pushHistory({
                    date: self.formatDate(startDate),
                    name: self.formData.name,
                    status: self.formData.status,
                })

                let data = {
                    datefrom: this.formatDate(startDate),
                    dateto: this.formatDate(endDate),
                    status: self.formData.status,
                    name: self.formData.name,
                }

                if (self.appointmentType === 'clinic') {
                    data.clinic_id = webInfo.currentUser.clinic_id
                } else if (self.appointmentType === 'client') {
                    data.patient_id = webInfo.currentUser.id
                }

                jQuery.ajax({
                    method: 'GET',
                    data: data,
                    url: `${webInfo.baseUrl}/api/appointments`,
                    beforeSend: function() {
                        // self.pushHistory();
                    },
                    success: function(response) {
                        if (response.data.length) {
                            response.data.forEach((appointment) => {
                                self.appointments.push({
                                    start: self.formatDate(`${appointment.appointment_date} ${appointment.appointment_time}`, 'full'),
                                    end: self.formatDate(`${appointment.appointment_date} ${appointment.appointment_timeend}`, 'full'),
                                    appointmentDetails: appointment,
                                    title: (self.appointmentType === 'client') ? appointment.clinic_name : `${appointment.firstname} ${appointment.lastname}`,
                                    background: true,
                                    class: appointment.status,
                                    link: `/appointments/${appointment.appointment_id}/edit`,
                                })
                            })
                        }
                        resolve();
                    },
                    error: function() {},
                });
            });
        },

        selectAppointment(appointment) {
            this.selectedAppointment = appointment.appointmentDetails
            console.log({
                appointmentDetails: appointment.appointmentDetails
            })
        },

        formatDate(date,format = '') {
            var d = new Date(date),
                month = '' + (d.getMonth() + 1),
                day = '' + d.getDate(),
                year = d.getFullYear(),
                hour = d.getHours(),
                min = d.getMinutes();
        
            if (month.length < 2) 
                month = '0' + month;
            if (day.length < 2) 
                day = '0' + day;

            if (format == 'full') {
                return `${year} ${month} ${day} ${hour}:${min}`;
            } else if(format == 'time') {
                return `${hour}:${min}`;
            }
        
            return [year, month, day].join('-');
        },

        pushHistory(param) {
			let addPage = '',
				slug = '/appointments/';

			// if (this.APIQuery.paged > 1) {
			// 	addPage = '/page/' + this.APIQuery.paged;
			// }

            //serialize url object
			let urlStr = jQuery.param(param);
            let addQuestionMark = urlStr.trim() != '' ? '?' + urlStr : '';

			history.pushState(
				{
					date: param.date,
				},
				document.title,
				slug + addQuestionMark
			);
		},
    },
    created(){
        console.log('appointments')
    }
})