import Vue from 'vue/dist/vue.js';
import VueMultiselect from 'vue-multiselect';
new Vue({
	el: '#appointment__create',
    components: {
		VueMultiselect,
	},
	data: {
		formData: {
			id: (typeof webInfo.appointmentInfo !== 'undefined') ? webInfo.appointmentInfo.id : '',
			pet_id: (typeof webInfo.appointmentInfo !== 'undefined') ? webInfo.appointmentInfo.pet_id : '',
			firstname: (typeof webInfo.appointmentInfo !== 'undefined') ? webInfo.appointmentInfo.firstname : '',
			lastname: (typeof webInfo.appointmentInfo !== 'undefined') ? webInfo.appointmentInfo.lastname : '',
			email: (typeof webInfo.appointmentInfo !== 'undefined') ? webInfo.appointmentInfo.email : '',
			phone: (typeof webInfo.appointmentInfo !== 'undefined') ? webInfo.appointmentInfo.phone : '',
			address: (typeof webInfo.appointmentInfo !== 'undefined') ? webInfo.appointmentInfo.address : '',
			appointmentDate: (typeof webInfo.appointmentInfo !== 'undefined') ? webInfo.appointmentInfo.appointment_date : '',
			appointmentTime: (typeof webInfo.appointmentInfo !== 'undefined') ? webInfo.appointmentInfo.appointment_time : '',
			status: (typeof webInfo.appointmentInfo !== 'undefined') ? webInfo.appointmentInfo.status : 'approved',
			message: (typeof webInfo.appointmentInfo !== 'undefined') ? webInfo.appointmentInfo.message : '',
		},
		selected: {
            patientInfo: {},
			petInfo: {}
        },
        patients : [],
        pets : [],
    },
	computed: {
		filteredPatients() {
			return this.patients.map((patient) => ({
				name: patient.fullname,
				id: patient.id,
			}));
		},
		filteredPets() {
			console.log('trigger filtered Pets');
			return this.pets.map((pet) => ({
				name: `${pet.name} - ${pet.species}`,
				id: pet.id,
			}));
		},
	},
    methods: {
        getPatients() {
            const self = this;

			if (this.patients.length !== 0) {
				return Promise.resolve(this.patients);
			}

            return new Promise((resolve, reject) => {
				const test = jQuery.ajax({
					method: 'GET',
					data: {},
					url: `${webInfo.baseUrl}/api/patients`,
					beforeSend: function() {
						// self.pushHistory();
					},
					success: function(response) {
                        self.patients = response.data;
						setTimeout(() => {
							if (typeof webInfo.params.patient !== 'undefined') {
								self.populateInfo({
									id: webInfo.params.patient,
								});
							}
						}, 300);
						resolve();
					},
					error: function() {},
				});
			});
		},
		
		getPets(patientID = '') {
			let self = this;
			patientID = (!patientID) ? this.selected.patientInfo.id : patientID;
			console.log(patientID);

			return new Promise((resolve, reject) => {
				const test = jQuery.ajax({
					method: 'GET',
					data: {
						patient_id: patientID
					},
					url: `${webInfo.baseUrl}/api/pets`,
					beforeSend: function() {
						// self.pushHistory();
					},
					success: function(response) {
						self.pets = response.data;
						console.log(self.pets);
						resolve();
					},
					error: function() {},
				});
			});
		},

		populateInfo(data) {
			let self = this;
			let patientInfo =  this.patients.find((info) => {
				if (info.id == data.id) {
					self.formData.id = info.id;
					self.formData.firstname = info.firstname;
					self.formData.lastname = info.lastname;
					self.formData.email = info.email;
					self.formData.phone = info.phone;
					self.formData.address = info.address;
					return info;
				}
			})
		},

		populatePetInfo(data) {
			let self = this;
			let petInfo =  this.pets.find((info) => {
				if (info.id == data.id) {
					self.formData.pet_id = info.id;
					return info;
				}
			})
		},
    },

	watch: {
		// 'selected.patientInfo' : function(val) {
		// 	this.getPets(val.id);
		// }
	},

    created() {
		this.getPatients();
		// if (typeof webInfo.params.patient !== 'undefined') {
		// 	this.getPatients();
		// }else {
		// 	console.log('no params');
		// }
    }
});
