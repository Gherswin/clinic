import vue from 'vue/dist/vue.js';
import VueMultiselect from 'vue-multiselect';
import vuecal from 'vue-cal';
import VueTimepicker from 'vue2-timepicker';

if (document.querySelector('#make-an-appointment')) {
  new vue({
    el: '#make-an-appointment',
    components: {
      VueMultiselect,
      'vue-cal': vuecal,
      VueTimepicker,
    },
    data: {
      appointmentType: webInfo.params.appointmentType,
      formData: {
        clinic: {},
        services: [],
        patientID: '',
        clinicID: '',
        selectedPatient: {},
        selectedPet: {
          id: '',
          name: '',
          species: '',
          breed: '',
          gender: '',
          color: '',
          weight: '',
          birthdate: '',
          clinics: '',
        },
  
        date: '',
        time: '',
      },
      activeStep: 1,
      patients: [],
      pets: [],
      clinics: [],
      services: [],
      hideDays: [],
      minTime: {},
      maxTime: {},
    },
    computed: {
      filteredClinics() {
        return this.clinics
        
        // return this.clinics.map((clinic) => ({
        // 	name: clinic.name,
        // 	id: clinic.id,
        // }));
      },
      filteredServices() {
        return this.services.map((service) => ({
          title: service.title,
          id: service.id,
          price: service.price,
          formattedPrice: new Intl.NumberFormat('fil-PH', { style: 'currency', currency: 'PHP' }).format(Number(service.price)),
        }));
      },
      availableTime() {
        let availTime = []
        if (this.minTime.hour != '' && this.maxTime.hour != '') {
          for(let x = this.minTime.hour; x < this.maxTime.hour; x++) {
            let time = new Date()
            time.setHours(x)
            time.setMinutes(this.minTime.minute)
            time.setSeconds(0)
            availTime.push({
              raw: `${time.getHours()}:${this.minTime.minute}`,
              // formatted: this.convertTime(`${time.getHours()}:${this.minTime.minute}`),
              formatted: time.toLocaleString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }),
            })
          }
        }
  
        return availTime
      }
    },
    methods: {
      getPets() {
        const self = this;
  
        return new Promise((resolve, reject) => {
          const test = jQuery.ajax({
            method: 'GET',
            data: {
              patient_id: self.formData.patientID,
            },
            url: `${webInfo.baseUrl}/api/pets`,
            beforeSend: function() {
              // self.pushHistory();
            },
            success: function(response) {
              self.pets = response.data;
              resolve();
            },
            error: function() {},
          });
        });
      },
      getClinics(params = {}) {
        const self = this;
  
        if (this.clinics.length !== 0) {
          return Promise.resolve(this.patients);
        }
  
        return new Promise((resolve, reject) => {
          const test = jQuery.ajax({
            method: 'GET',
            data: params,
            url: `${webInfo.baseUrl}/api/clinics`,
            beforeSend: function() {
              // self.pushHistory();
            },
            success: function(response) {
              self.clinics = response.data;
              resolve();
            },
            error: function() {},
          });
        });
      },
      getServices(id = "") {
        const self = this;
  
        return new Promise((resolve, reject) => {
          const test = jQuery.ajax({
            method: 'GET',
            data: {
              clinic_id: id,
            },
            url: `${webInfo.baseUrl}/api/services`,
            beforeSend: function() {
              // self.pushHistory();
            },
            success: function(response) {
              console.log({
                action: 'services',
                response
              })
              self.services = response.data;
              resolve();
            },
            error: function() {},
          });
        });
      },
      getPatients() {
        const self = this;
  
        if (this.patients.length !== 0) {
          return Promise.resolve(this.patients);
        }
  
        return new Promise((resolve, reject) => {
          const test = jQuery.ajax({
            method: 'GET',
            data: {},
            url: `${webInfo.baseUrl}/api/clients`,
            beforeSend: function() {
              // self.pushHistory();
            },
            success: function(response) {
              self.patients = response;
              resolve();
            },
            error: function() {},
          });
        });
      },
      populateInfo(data) {
        this.formData.clinic = data
        
        if (data.operating_hours.length) {
          let self = this
          let days = []
          let daysInWeek = [1, 2, 3, 4, 5, 6, 7]
  
          data.operating_hours.forEach(data => {
            if (data.day === 'mon') days.push(1)
            if (data.day === 'tue') days.push(2)
            if (data.day === 'wed') days.push(3)
            if (data.day === 'thu') days.push(4)
            if (data.day === 'fri') days.push(5)
            if (data.day === 'sat') days.push(6)
            if (data.day === 'sun') days.push(7)
  
            self.hideDays = daysInWeek.filter(data => !days.includes(data))
          })
        }
        this.getServices(data.id)
      },
      async selectPatient(data) {
        console.log(data)
        this.formData.patientID = data.id
      },
      selectPet(data) {
        this.formData.petID = data.id;
        this.formData.petID = data.id;
        this.formData.selectedPet = {
          id: data.id,
          name: data.name,
          species: data.species,
          breed: data.breed,
          gender: data.gender,
          color: data.color,
          weight: data.weight,
          birthdate: data.birthdate,
          clinics: data.clinics,
        };
  
        jQuery('#select-pet').modal('hide');
      },
      prevStep() {
        this.activeStep -= 1
      },
      nextStep() {
        if (this.activeStep === 3) {
          this.submitAppointment()
          return
        }
        this.activeStep += 1
      },
  
      setAppointmentDate(event) {
        let self = this
        // this.formData.date = new Date(event).toISOString().substring(0, 10)
        const selectedDate = new Date(event)
        const day = selectedDate.getDay()
        const days = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"]
        const selectedDay = days[day]
        this.formData.date = selectedDate.getFullYear() + '-' + (parseInt(selectedDate.getMonth()) + 1) + '-' + selectedDate.getDate()
        console.log(selectedDate)
        
        this.formData.clinic.operating_hours.forEach(data => {
          if (data.day === selectedDay) {
            self.minTime = {
              raw: data.timestart,
              hour: Number(data.timestart.slice(0, 2)),
              minute: data.timestart.slice(3, 5),
              formatted: self.convertTime(data.timestart),
            }
            self.maxTime = {
              raw: data.timeend,
              hour: Number(data.timeend.slice(0, 2)),
              minute: data.timeend.slice(3, 5),
              formatted: self.convertTime(data.timeend),
            }
          }
        })
      },
  
      submitAppointment() {
        const self = this
  
        return new Promise((resolve, reject) => {
          const test = jQuery.ajax({
            method: 'POST',
            data: self.formData,
            url: `${webInfo.baseUrl}/api/appointments/store`,
            beforeSend: function() {
              // self.pushHistory();
            },
            success: function(response) {
              console.log({
                data: self.formData,
                response
              })
              window.location.href = "/appointments"
              resolve();
            },
            error: function() {},
          });
        });
      },
  
      convertTime(time) {
        let hours = Number(time.slice(0,2));
        let minutes = time.slice(3,5);
        let ampm = hours >= 12 ? "PM" : "AM";
        hours = hours % 12;
        hours = hours ? hours : 12;
        return hours + ":" + minutes + " " + ampm;
      },
    },
    async created() {
      this.formData.patientID = webInfo.params.patient_id
      let clinicID = webInfo.params.clinic_id
  
      if (webInfo.selectedClinic) {
        clinicID = webInfo.selectedClinic
      }
  
      if (clinicID) {
        await this.getClinics({
          id: webInfo.params.clinic_id,
        })
        this.formData.clinicID = this.clinics[0]
        await this.populateInfo(this.clinics[0])
      } else {
        this.getClinics()
      }
    },
  })
}
