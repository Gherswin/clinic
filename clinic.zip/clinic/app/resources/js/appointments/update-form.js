window.addEventListener('load', function() {
	$('.btn-print').click((e) => {
		e.preventDefault();
		let findings,
			data = {
				date: $('#appointment_date').val(),
				doctorNote: $('#findings').val(),
			};

		findings = `<div class="print__findings-item">
			<div class="print__findings-item-date">
				<strong>Appointment Date</strong>: ${data.date}
			</div>
			<div class="print__findings-item-note">
				<pre>${data.doctorNote}</pre>
			</div>
		</div>`;

		printFindings(findings);
	});

	function printFindings(findingsContent = '') {
		
		let cssDiv = generateCSS();
		let data  = {
			owner: `${webInfo.appointmentInfo.firstname} ${webInfo.appointmentInfo.lastname}`,
			petName: webInfo.appointmentInfo.pet_name,
			species: webInfo.appointmentInfo.pet_species,
			breed: webInfo.appointmentInfo.pet_breed,
			gender: webInfo.appointmentInfo.pet_gender,
			color: webInfo.appointmentInfo.pet_color,
			weight: webInfo.appointmentInfo.pet_weight,
			birthdate: webInfo.appointmentInfo.pet_birthdate,
		}

		let htmlToPrint = `<!DOCTYPE html>
			<html>
				<head>
					${cssDiv}
				</head>
				<body>
					<h2 style="text-align:center;margin-bottom: 30px">PET HUB CARE</h2>
					<div class="print__details">
						<div class="print__details-item">
							<strong>Owner:</strong> ${data.owner}    
						</div>
						<div class="print__details-item">
							<strong>Pet Name:</strong> ${data.petName}    
						</div>
						<div class="print__details-item">
							<strong>Species:</strong> ${data.species}    
						</div>
						<div class="print__details-item">
							<strong>Breed:</strong> ${data.breed}    
						</div>
						<div class="print__details-item">
							<strong>Gender:</strong> ${data.gender}    
						</div>
						<div class="print__details-item">
							<strong>Color:</strong> ${data.color}    
						</div>
						<div class="print__details-item">
							<strong>Weight:</strong> ${data.weight}    
						</div>
						<div class="print__details-item">
							<strong>Birthdate:</strong> ${data.birthdate}    
						</div>
					</div>
					<div class="print__findings">
						${findingsContent}
					</div>
				</body>
			</html>`;

			window.frames.print_frame.document.body.innerHTML = htmlToPrint;
			window.frames.print_frame.window.focus();
			window.frames.print_frame.window.print();
	}
});

function generateCSS() {
	return `<style type="text/css">
		body {
			font-family: verdana;
			font-size: 10px;
		}
		pre {
			white-space: pre-wrap;       /* css-3 */
			white-space: -moz-pre-wrap;  /* Mozilla, since 1999 */
			white-space: -pre-wrap;      /* Opera 4-6 */
			white-space: -o-pre-wrap;    /* Opera 7 */
			word-wrap: break-word;       /* Internet Explorer 5.5+ */
			font-family: verdana;
			font-size: 10px;
		}
		.print__details {
			display: flex;
			flex-wrap: wrap;
		}
		.print__details-item {
			width: 50%;
			line-height: 1.3;
		}

		.print__findings {
			margin-top: 40px;
		}
		.print__findings-item {
			margin-bottom: 20px;
		}
		.print__findings-item-date {
			border-top: 1px solid;
			border-bottom: 1px solid;
			padding: 10px 0px;
			font-size: 12px;
		}
	</style>`;
}