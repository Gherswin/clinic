import Vue from 'vue/dist/vue.js';
import VueMultiselect from 'vue-multiselect';

new Vue({
	el: '#pos',
    components: {
		VueMultiselect,
	},
    
    data: {
        time: {
            interval: null,
            time: null
        },
        filter: {
            itemCode: '',
            qty: 1,
        },
        show: {
            itemSuggestion: false,
            isPayDisabled: true,
        },
        items:{
            isLoading: false,
            data: [],
        },
        inventory: {
            filter: {
                item_code: '',
                item_name: '',
                item_classification: '',
            },
            data: []
        },
        formData: {
            patient: null,
            items: [],
            totalPrice: 0,
            amountPaid: null,
            change: null,
            changeLabel: null,
        },
        patients : [],
    },

    computed: {
		filteredPatients() {
			return this.patients.map((patient) => ({
				name: patient.fullname,
				id: patient.id,
			}));
		},
	},

    methods: {
        getPatients() {
            const self = this;

			if (this.patients.length !== 0) {
				return Promise.resolve(this.patients);
			}

            return new Promise((resolve, reject) => {
				const test = jQuery.ajax({
					method: 'GET',
					data: {},
					url: `${webInfo.baseUrl}/api/patients`,
					beforeSend: function() {
						// self.pushHistory();
					},
					success: function(response) {
                        self.patients = response.data;
						resolve();
					},
					error: function() {},
				});
			});
		},
        populateInfo(data) {
            this.formData.patient = data.id;
		},
        
        getTotalPrice() {
            this.formData.totalPrice = 0;

            if (this.formData.items.length) {
                this.formData.items.forEach(item => {
                    this.formData.totalPrice += item.total;
                });
            }
        },

        addItem(item, qty = 1) {
            this.formData.items.push({
                id: item.id,
                item_name: item.item_name,
                qty: qty,
                price: item.retail_price,
                total: item.retail_price * qty,
            });

            this.getTotalPrice();

            this.show.itemSuggestion = false;
            this.filter.itemCode = '';
            this.filter.qty = 1;
        },
        submitTransaction() {
            let self = this;

            return new Promise((resolve, reject) => {
				jQuery.ajax({
					method: 'POST',
                    headers: {  
                        'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content') 
                    },
					data: {
                        userID: webInfo.currentUser.id,
                        patientID: (self.formData.patient)? self.formData.patient.id : 0, 
                        items: self.formData.items, 
                        totalPrice: self.formData.totalPrice, 
                        amountPaid: self.formData.amountPaid, 
                        _token: jQuery('meta[name="csrf-token"]').attr('content') ,
                    },
					url: `${webInfo.baseUrl}/api/pos/store`,
					beforeSend: function(xhr) {
						xhr.setRequestHeader('X-CSRF-TOKEN', jQuery('meta[name="csrf-token"]').attr('content') );
					},
					success: function(response) {
                        self.resetFields();
                        jQuery('#complete-transaction').modal('show');
                        
						resolve();
					},
					error: function() {},
				});
			});
        },

        removeItem(index) {
            this.formData.items.splice(index, 1);
            this.getTotalPrice();
        },

        resetFields() {
            this.formData = {
                patient: null,
                items: [],
                totalPrice: 0,
                amountPaid: null,
                change: null,
                changeLabel: null,
            };
        },

        formatNumber(number, decimal = 2) {
            return new Number(number).toLocaleString('en-US', {minimumFractionDigits: decimal});
        },

        getInventory() {
            let self = this;

            return new Promise((resolve, reject) => {
                const test = jQuery.ajax({
                    method: 'GET',
                    data: self.inventory.filter,
                    url: `${webInfo.baseUrl}/api/items`,
                    beforeSend: function() {
                        // self.pushHistory();
                    },
                    success: function(response) {
                        self.inventory.data = response.data;
                        console.log(self.inventory.data);
                        resolve();
                    },
                    error: function() {},
                });
            });
        },
    },

    watch: {
		'filter.itemCode': function() {
            let self = this;

            if (this.filter.itemCode.length > 2) {
                this.show.itemSuggestion = true;
                this.items.isLoading = true;

                return new Promise((resolve, reject) => {
                    const test = jQuery.ajax({
                        method: 'GET',
                        data: {
                            s: self.filter.itemCode,
                            stocks: 1,
                        },
                        url: `${webInfo.baseUrl}/api/items`,
                        beforeSend: function() {
                            // self.pushHistory();
                        },
                        success: function(response) {
                            self.items.data = response.data;
                            self.items.isLoading = false;

                            resolve();
                        },
                        error: function() {},
                    });
                });
            } else {
                this.show.itemSuggestion = false;
            }
        },
        'formData.amountPaid': function() {
            let change = this.formData.amountPaid - this.formData.totalPrice;
            if (change >= 0) {
                this.formData.change = change;
                this.formData.changeLabel = this.formatNumber(change);
                this.show.isPayDisabled = false;
                return;
            }
            this.formData.changeLabel = null;
            this.formData.change = null;
            this.show.isPayDisabled = true;
            
            // alert('insuficient amount');
            // document.getElementById("amount_paid").focus();
        },
	},

    created() {
        this.getPatients();

        // update the time every second
        this.time.interval = setInterval(() => {
            // Concise way to format time according to system locale.
            // In my case this returns "3:48:00 am"
            this.time.time = Intl.DateTimeFormat(navigator.language, {
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric'
            }).format()
        }, 1000)
    },
});