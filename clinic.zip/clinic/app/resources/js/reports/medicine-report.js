const monthWord = (month) => {
    if (month == '1') {
        return 'Jan';
    } else if (month == '2') {
        return 'Feb';
    } else if (month == '3') {
        return 'Mar';
    } else if (month == '4') {
        return 'Apr';
    } else if (month == '5') {
        return 'May';
    } else if (month == '6') {
        return 'Jun';
    } else if (month == '7') {
        return 'Jul';
    } else if (month == '8') {
        return 'Aug';
    } else if (month == '9') {
        return 'Sep';
    } else if (month == '10') {
        return 'Oct';
    } else if (month == '11') {
        return 'Nov';
    } else if (month == '12') {
        return 'Dec';
    }

    return month;
}

var forecast = [];
if (webInfo.data.length) {
    // for (let x = 1; x <= (3 + webInfo.data.length); x++) {
    for (let x = 1; x <= 3; x++) {
        let  lastMonth = webInfo.data.at(-1).purchase_month;
        m = (parseInt(lastMonth) + x > 12) ? (parseInt(lastMonth) + x) % 12: parseInt(lastMonth) + x;
        y = ((parseInt(lastMonth) + x) / 12 > 1) ? parseInt(webInfo.data.at(-1).purchase_year) + 1 : webInfo.data.at(-1).purchase_year;
        forecast.push({
            purchase_month: monthWord(m) + " " + y,
        });
    }
}

const historyIndex = webInfo.data.map((d, i) => [i, parseInt(d.total_sales)]);

const predict = (data, newX) => {
    const round = n => Math.round(n * 100) / 100;

    const sum = data.reduce((acc, pair) => {
        const x = pair[0];
        const y = pair[1];

        if (y !== null) {
            acc.x += x;
            acc.y += y;
            acc.squareX += x * x;
            acc.product += x * y;
            acc.len += 1;
        }

        return acc;
    }, { x: 0, y: 0, squareX: 0, product: 0, len: 0 });

    const run = ((sum.len * sum.squareX) - (sum.x * sum.x));
    const rise = ((sum.len * sum.product) - (sum.x * sum.y));
    const gradient = run === 0 ? 0 : round(rise / run);
    const intercept = round((sum.y / sum.len) - ((gradient * sum.x) / sum.len));

    let result = round((gradient * newX) + intercept);
    
    if (result <= 0) {
        return 0;
    }

    return result;
}

forecast = forecast.map((d, i) => {
    return {
        x: d.purchase_month,
        y: predict(historyIndex, historyIndex.length - 1 + i),
    };
});

let prodData = webInfo.data.map((d, i) => {
    return {
        x: monthWord(d.purchase_month) + " " + d.purchase_year,
        y: d.total_sales, 
    };
})

let prodDataOffset = webInfo.data.map((d, i) => {
    if (i == webInfo.data.length - 1) {
        return {
            x: monthWord(d.purchase_month),
            y: d.total_sales, 
        }
    }
    return {
        x: monthWord(d.purchase_month),
        y: null, 
    };
})

var myChart = new Chart("myChart", {
    type: "line",
    data: {
        labels: prodData.map((d) => d.x).concat(forecast.map((d) => d.x)),
        datasets: [
            {
                label: 'Sales',
                data: prodData,
                backgroundColor: ['transparent'],
                borderColor: ['#3490dc'],
                borderWidth: 2,
                pointBackgroundColor: "#F19820",
                pointRadius: 5,
            },
            {
                label: 'Sales Prediction',
                data: prodDataOffset.concat(forecast),
                backgroundColor: ['transparent'],
                borderColor: ['#3490dc'],
                borderDash: [20],
                borderWidth: 2,
                pointBackgroundColor: "#F19820",
                pointRadius: 5,
            },
        ]
    },
    options: {
        elements: {
            line: {
                tension: 0.2
            }
        },
        tooltips: {
            callbacks: {
                label: function(tooltipItem, data) {
                    return tooltipItem.yLabel.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
            }
        }
    }
});