@extends('layouts.login')

@section('content')
<div class="card">
    <div class="card-body">
        @if (session('status'))
            <div class="alert alert-success text-center" role="alert">
                {{ session('status') }}
            </div>
        @endif
        <form method="POST" action="{{ route('password.email') }}">
            @csrf
            <div class="form-group row">
                <div class="col-md-12 mb-2 text-center">
                    <h4>Forgot Password</h4>
                </div>
                <div class="col-md-12 mb-3">
                    <label for="email">E-Mail Address</label>
                    <input 
                        id="email" 
                        type="email" 
                        class="form-control @error('email') is-invalid @enderror" 
                        name="email" 
                        value="{{ old('email') }}" 
                        required 
                        autocomplete="email" 
                        autofocus
                    />
                    @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary w-100">
                         {{ __('Send Password Reset Link') }}
                    </button>
                </div>
                
                <div class="col-md-12 text-center mt-4">
                    <a href="{{ route('login') }}" class="color-primary">Back to Login</a>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
