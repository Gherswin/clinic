@extends('layouts.login')

@section('content')
<div class="card">
    <div class="card-body">
        @if (session('status'))
            <div class="alert alert-success text-center" role="alert">
                {{ session('status') }}
            </div>
        @endif
        <form method="POST" action="{{ route('password.update') }}">
            @csrf
            <input type="hidden" name="token" value="{{ $token }}">
            <div class="form-group row">
                <div class="col-md-12 mb-2 text-center">
                    <h4>Forgot Password</h4>
                </div>
                <div class="col-md-12 mb-3">
                    <label for="email">E-Mail Address</label>
                    <input 
                        id="email" 
                        type="email" 
                        class="form-control @error('email') is-invalid @enderror" 
                        name="email" 
                        value="{{ $email ?? old('email') }}"
                        required 
                        autocomplete="email" 
                        readonly
                    />
                    @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="col-md-12 mb-3">
                    <label for="password">Password</label>
                    <input 
                        id="password" 
                        type="password" 
                        class="form-control @error('password') is-invalid @enderror" 
                        name="password" 
                        required 
                        autocomplete="new-password"
                    />
                    @error('password')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="col-md-12 mb-3">
                    <label for="password-confirm">Confirm Password</label>
                    <input 
                        id="password-confirm" 
                        type="password" 
                        class="form-control" 
                        name="password_confirmation" 
                        required 
                        autocomplete="new-password"
                    />
                    @error('password')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary w-100">
                         {{ __('Reset Password') }}
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>


@endsection
