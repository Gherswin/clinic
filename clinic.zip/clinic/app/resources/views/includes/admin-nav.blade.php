<nav class="navbar navbar-expand-md navbar-light bg-primary-light shadow-sm p-0" style="height:50px">
    <div class="container max-w-unset p-0">
        <a class="navbar-brand" href="{{ url('/dashboard') }}" style="padding: 0px 12px;">
            <span class="logo-imgholder">
                <img
                    class="logo-img" 
                    src="{{ asset('images/logo.jpg') }}" 
                />
            </span>
            <span class="logo-text">PawHub</span>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav mr-auto">

            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                @guest
                    @if (Route::has('login'))
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                        </li>
                    @endif

                    @if (Route::has('register'))
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                        </li>
                    @endif
                @else
                    <li class="nav-item d-md-none d-block">
                        <a href="{{route('dashboard')}}" class="nav-link">Dashboard</a>
                    </li>
                    <li class="nav-item d-md-none d-block">
                        <a href="{{ route('appointments.index') }}" class="nav-link">Appointments</a>
                    </li>
                    <li class="nav-item d-md-none d-block">
                        <a href="{{ route('patients.index') }}" class="nav-link">Clients</a>
                    </li>
                    <li class="nav-item d-md-none d-block">
                        <a href="{{ route('pets.index') }}" class="nav-link">Pets</a>
                    </li>
                    <li class="nav-item d-md-none d-block">
                        <a href="{{ route('medicines.index') }}" class="nav-link">Medicines</a>
                    </li>
                    <li class="nav-item d-md-none d-block">
                        <a href="{{ route('sales-counter.index') }}" class="nav-link">Sales Counter</a>
                    </li>
                    {{-- <li class="nav-item dropdown d-md-none d-block">
                        <a id="reportDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            Reports
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="reportDropdown">
                            <a class="dropdown-item" href="{{ route('reports.appointments') }}">
                               Appointments
                            </a>
                            <a class="dropdown-item" href="{{ route('reports.products') }}">
                               Medicines
                            </a>
                        </div>
                    </li> --}}
                    @if(Auth::user()->role == 'admin')
                    <li class="nav-item d-md-none d-block">
                        <a class="nav-link" href="{{ route('reports.products') }}">
                            Medicine Reports
                        </a>
                    </li>
                   
                    <li class="nav-item d-md-none d-block">
                        <a href="{{ route('staffs.index') }}" class="nav-link">Staffs</a>
                    </li>
                    @endif
                    <li class="nav-item dropdown welcome">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                           Welcome {{ Auth::user()->firstname }} {{ Auth::user()->lastname }}
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ route('profile') }}">
                                {{ __('Profile') }}
                            </a>
                            <a class="dropdown-item" href="{{ route('logout') }}"
                               onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                                {{ __('Logout') }}
                            </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>
                        </div>
                    </li>
                @endguest
            </ul>
        </div>
    </div>
</nav>