<div class="admin-sidebar">
    <div class="admin-sidebar__inner">
        <div class="sidebar__items ">
            <a href="{{route('dashboard')}}" class="sidebar__items-link {{ Request::is('dashboard') ? 'active' : '' }}">
                <i class="icon fas fa-tachometer-alt mr-2"></i> Dashboard
            </a>
        </div>
        <div class="sidebar__items">
            <a href="{{ route('appointments.index') }}" class="sidebar__items-link {{ Request::routeIs('appointments.*') ? 'active' : '' }}">
                <i class="icon fas fa-calendar-check mr-2"></i> Appointments
            </a>
        </div>
        @if(Auth::user()->role == 'admin')
            <div class="sidebar__items">
                <a href="{{ route('patients.index') }}" class="sidebar__items-link {{ Request::routeIs('patients.*') ? 'active' : '' }}">
                    <i class="icon fas fa-user-injured mr-2"></i>Clients 
                </a>
            </div>
        @endif
        @if(Auth::user()->role == 'admin')
            <div class="sidebar__items">
                <a href="{{ route('clinics.index') }}" class="sidebar__items-link {{ Request::routeIs('clinics.*') ? 'active' : '' }}">
                    <i class="icon fas fa-clinic-medical mr-2"></i>Clinics 
                </a>
            </div>
        @endif

        <div class="sidebar__items">
            <a href="{{ route('pets.index') }}" class="sidebar__items-link {{ Request::routeIs('pets.*') ? 'active' : '' }}">
                <i class="icon fas fa-paw mr-2"></i>Pets 
            </a>
        </div>
        {{-- 
        <div class="sidebar__items">
            <a href="{{ route('medicines.index') }}" class="sidebar__items-link {{ Request::routeIs('medicines.*') ? 'active' : '' }}">
                <i class="icon fas fa-briefcase-medical mr-2"></i> Medicines
            </a>
        </div>
        <div class="sidebar__items">
            <a href="{{ route('sales-counter.index') }}" class="sidebar__items-link {{ Request::routeIs('sales-counter.*') ? 'active' : '' }}">
                <i class="icon fas fa-cash-register mr-2"></i> Sales Counter
            </a>
        </div>
        <div class="sidebar__items sidebar__items-dropdown">
            <a href="#" class="sidebar__items-link {{ Request::routeIs('reports.*') ? 'active' : '' }}">
                <i class="icon fas fa-file-alt mr-2"></i> Reports
            </a>
            <div class="dropdown">
                <a class="dropdown-item" href="{{ route('reports.appointments') }}">
                    Appointments
                 </a>
                 <a class="dropdown-item" href="{{ route('reports.products') }}">
                    Medicines
                 </a>
            </div>
        </div> --}}
        @if(Auth::user()->role == 'admin' || Auth::user()->role == 'clinic-admin')
            <div class="sidebar__items">
                <a href="{{ route('staffs.index') }}" class="sidebar__items-link {{ Request::routeIs('staffs.*') ? 'active' : '' }}">
                    <i class="icon fas fa-users mr-2"></i> Staffs
                </a>
            </div>
        @endif
        @if(Auth::user()->role == 'clinic-admin')
            <div class="sidebar__items">
                <a href="{{ route('clinics.edit', Auth::user()->clinic_id) }}" class="sidebar__items-link {{ Request::routeIs('clinics.*') ? 'active' : '' }}">
                    <i class="icon fas fa-clinic-medical mr-2"></i> Clinic Information
                </a>
            </div>
        @endif

        <div class="sidebar__items">
            <a href="{{ route('profile') }}" class="sidebar__items-link {{ Request::routeIs('profile') ? 'active' : '' }}">
                <i class="fas fa-user-alt mr-2"></i> Profile
            </a>
        </div>
    </div>
</div>