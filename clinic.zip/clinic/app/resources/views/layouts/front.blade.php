<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body>
    <div id="frontend" class="home">
        <!-- Navigation -->
        <nav class="main-nav navbar navbar-expand-lg navbar-light">
            <div class="container">
                <a class="navbar-brand" href="{{ route('homepage') }}">
                    <span class="logo-imgholder">
                        <img
                            class="logo-img" 
                            src="{{ asset('images/logo.jpg') }}" 
                        />
                    </span>
                    <span class="logo-text">PawHub</span>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('homepage') }}">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('homepage') }}#services">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('clinics') }}">Partners</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link cta" href="{{ route('make_appointment.create') }}">Make an Appointment</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- End Navigation -->

        @yield('content')

        <!-- Footer -->
        <div id="footer" class="footer section-container" style="background-color:#b95d2e">
            <div class="container section">
                <div class="footer__links text-center text-light mb-2">
                    <a href="{{ route('homepage') }}">Home</a> / 
                    <a href="{{ route('homepage') }}#services">Services</a> / 
                    <a href="{{ route('clinics') }}">Partners</a> / 
                    <a href="{{ route('make_appointment.create') }}">Appointment</a>
                </div>
                <div class="footer__copyright text-light text-center">
                    Copyright &copy; 2021 All rights reserved / 
                    {{-- <a class="text-light" href="/privacy-policy">Privacy Policy</a> /
                    <a class="text-light" href="/terms-and-conditions">Terms and Conditions</a> --}}
                    <a class="text-light" href="#">Privacy Policy</a> /
                    <a class="text-light" href="#">Terms and Conditions</a>
                </div>
            </div>
        </div>
        <!-- End Footer -->
    </div>
    @include('includes.footer')
</body>
</html>