<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="login">
    @include('includes.head')
    <body>
        <div class="container main-content d-flex flex-center h-100v">
            <div class="row w-100">
                <div class="col-md-4"></div>
                <div class="col-md-4">
                    <h3 class="text-center mb-4">VETERINARY CLINIC MANAGEMENT SYSTEM</h3>
                    @yield('content')
                </div>
            </div>
        </div>
        @include('includes.footer')
    </body>
</html>
