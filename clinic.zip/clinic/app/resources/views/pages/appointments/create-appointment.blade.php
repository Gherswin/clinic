@extends('layouts.app')

@section('content')
        <div id="make-an-appointment">
            <form action="" @submit.prevent="nextStep" class="w-100 max-w-800 mx-auto bg-white p-lg-5 py-3 border border-secondary-300 mb-4" method="POST">
                @csrf     
                <div class="form-group row">
                    <div class="col-md-12">
                        <h1 class="text-primary text-center" style="font-weight:600">Make an Appointment</h2>
                    </div>
                </div>
                <div class="form-group row" v-if="activeStep == 1" v-cloak>
                    <div class="col-md-12 mb-3" v-if="appointmentType != 'clinic'">
                        <label for="clinic">Select Clinic</label>
                        <vue-multiselect 
                            class="form-control-multiselect w-100"
                            v-model="formData.clinicID"
                            placeholder="Select Client"
                            track-by="id"
                            label="name"
                            open-direction="bottom"
                            :options="filteredClinics"
                            :searchable="true"
                            :show-pointer="false"
                            :show-labels="false"
                            :multiple="false"
                            :internal-search="true"
                            :close-on-select="true"
                            :options-limit="700"
                            :max-height="300"
                            :show-no-results="false"
                            @open="getClinics"
                            @search-change="getClinics"
                            @select="populateInfo"
                            />
                        </vue-multiselect>
                    </div>
                    <div class="col-md-12 mb-3" v-if="services.length">
                        <label for="services">Select Service(pick 1 or more)</label>
                        <div class="row">
                            <label class="service-item col-md-4" v-for="service in filteredServices">
                                <div class="service-item__inner">
                                    <input type="checkbox" name="services" v-model="formData.services" :value="service.id" class="mr-2">
                                    <h5 class="mb-0" v-html="service.title"></h5>
                                    <div v-html="service.formattedPrice"></div>
                                </div>
                            </label>
                        </div>
                    </div>
                </div> {{-- Select Clinic --}}

                {{-- <div class="form-group row" v-if="activeStep == 2" v-cloak>
                    <div class="col-md-12">
                        <h2>Personal Details</h2>
                        <p>
                            Please provide your personal information below so we can ensure the accuracy of your account and contact you in case of any issues.
                            if you already have an account please <a href="/login" class="text-primary">Login here</a>
                        </p>
                    </div>
                    <div class="col-md-6 pr-md-0 mb-3">
                        <label for="firstname">First Name</label>
                        <input type="text" name="firstname" id="firstname" class="form-control" v-model="formData.firstname" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="lastname">Last Name</label>
                        <input type="text" name="lastname" id="lastname" class="form-control" v-model="formData.lastname" required>
                    </div>
                    <div class="col-md-6 pr-md-0 mb-3">
                        <label for="contact_no">Contact No.</label>
                        <input type="text" name="contact_no" id="contact_no" class="form-control" v-model="formData.contactNo" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" class="form-control" v-model="formData.email" required>
                    </div>
                </div> --}} {{-- Personal Information --}}

                <div class="form-group row" v-if="activeStep === 2" v-cloak>
                    <div class="col-md-12 mb-3" v-if="appointmentType != 'client'">
                        <label for="petname">Select Client</label>
                        <vue-multiselect 
                            class="form-control-multiselect w-100"
                            v-model="formData.selectedPatient"
                            placeholder="Select Client"
                            track-by="name"
                            label="name"
                            open-direction="bottom"
                            :options="patients"
                            :searchable="true"
                            :show-pointer="false"
                            :show-labels="false"
                            :multiple="false"
                            :internal-search="true"
                            :close-on-select="true"
                            :options-limit="700"
                            :max-height="300"
                            :show-no-results="false"
                            @open="getPatients"
                            @search-change="getPatients"
                            @select="selectPatient"
                            />
                        </vue-multiselect>
                    </div>
                    <div class="pet-information d-flex flex-wrap" v-if="formData.patientID">
                        <div class="col-md-12">
                            <h2>Pet Details</h2>
                            <p>Enter your pet's information below to ensure we have all the necessary details to provide the best care for them during their stay with us.</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <button 
                                data-toggle="modal" 
                                data-target="#select-pet"
                                type="button" 
                                class="btn btn-outline-primary w-100"
                                @click="getPets()">
                                Select Existing Pet
                            </button>
                            <!-- Modal -->
                            <div class="modal fade" id="select-pet" tabindex="-1" aria-labelledby="select-pet-Label" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="select-pet-Label">Select Pet</h5>
                                            <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                <i class="fas fa-times"></i>
                                            </a>
                                        </div>
                                        <div class="modal-body">
                                            <table class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">#</th>
                                                        <th scope="col">Pet Name</th>
                                                        <th scope="col">Species</th>
                                                        <th scope="col">Breed</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr v-for="(pet, index) in pets"  @click="selectPet(pet)">
                                                        <td>@{{index + 1}}</td>
                                                        <td>@{{ pet.name }}</td>
                                                        <td>@{{ pet.species }}</td>
                                                        <td>@{{ pet.breed }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        {{-- <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        </div> --}}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="petname">Pet Name</label>
                            <input id="petname" type="text" class="form-control " name="petname" required autocomplete="petname" v-model="formData.selectedPet.name">
                        </div>
                        <div class="col-md-6 pr-md-0 mb-3">
                            <label for="species">Species</label>
                            <input id="species" type="text" class="form-control " name="species" required autocomplete="species"  v-model="formData.selectedPet.species">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="breed">Breed</label>
                            <input id="breed" type="text" class="form-control " name="breed" required autocomplete="breed"  v-model="formData.selectedPet.breed">
    
                        </div>
                        <div class="col-md-6 pr-md-0 mb-3">
                            <label for="gender">Gender</label>
                            <select id="gender" name="gender" class="form-control "  v-model="formData.selectedPet.gender">
                                <option value="male" selected="">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="color">Color</label>
                            <input id="color" type="text" class="form-control " name="color" autocomplete="color"  v-model="formData.selectedPet.color">
                        </div>
                        <div class="col-md-6 pr-md-0 mb-3">
                            <label for="weight">Weight</label>
                            <input id="weight" type="text" class="form-control " name="weight" utocomplete="weight" placeholder="Weight" v-model="formData.selectedPet.weight">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="brithdate">Birth Date</label>
                            <input id="birthdate" type="date" class="form-control " name="birthdate" autocomplete="birthdate"  v-model="formData.selectedPet.birthdate">
                        </div>
                    </div>
                </div> {{-- Pet Information --}}

                <div class="make-an-appointment__calendar form-group row" v-if="activeStep === 3">
                    <div class="col-md-12 mb-3">
                        <div class="col-md-12">
                            <h2>Select Date</h2>
                            <p>
                                Select a date and time that works best for you to schedule your appointment. We'll do our best to accommodate your request.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-12 mb-3">
                        <vue-cal 
                            class="" 
                            active-view="month"
                            hide-view-selector
                            :time="false"
                            :disable-views="['week','day']"
                            :min-date="new Date()"
                            :hide-weekdays="hideDays"
                            {{-- :selected-date="" --}}
                            {{-- :events="appointments"  --}}
                            events-on-month-view
                            {{-- @ready="fetchAppointments" 
                            @view-change="fetchAppointments" --}}
                            @cell-click="setAppointmentDate"
                            >
                            <template #event="{event, view}">
                                {{-- <a 
                                    href="#"
                                    class="appointment__title" 
                                    data-toggle="modal" 
                                    data-target="#appointment-detail"
                                    v-html="event.title"
                                    @click="selectAppointment(event)"
                                ></a> --}}
                            </template>
                        </vue-cal>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label>Select Time (Operating Hours: @{{ minTime.formatted }} - @{{ maxTime.formatted }})</label>
                        <select class="form-control" v-model="formData.time" required :disabled="!formData.date">
                            <option v-for="time in availableTime" :key="time.raw" :value="time.raw" v-html="time.formatted"></option>
                        </select>
                    </div>
                </div>

                <div class="make-an-appointment__footer form-group row">
                    <div class="col-md-4">
                        <button type="button" class="btn btn-outline-primary w-100" @click.prevent="prevStep" v-if="activeStep != 1">
                            Previous
                        </button>
                    </div>
                    <div class="col-md-4 offset-md-4">
                        <button type="submit" class="btn btn-primary w-100" v-if="activeStep != 3">
                            Next
                        </button>
                        <button type="submit" class="btn btn-primary w-100" v-if="activeStep == 3">
                            Submit
                        </button>
                    </div>
                </div>
            </form>
        </div>

@endsection

@section('footer_script')
    <script>
        var webInfo = {
            baseUrl: '{!! URL::to('/') !!}',
            params: {!! json_encode($params) !!},
            selectedClinic: '{!! $request->clinic !!}',
        } 
    </script>
    <script src="{{ asset('js/make-an-appointment.js') }}" defer></script>
@endsection