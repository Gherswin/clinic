@extends('layouts.app')
@section('content')
<div class="container-fluid appointments">
    <div class="row">
        <div class="form-header col-md-12 mb-3 px-0">
            <h1 class="form-title">Appointment Information</h1>
        </div>
        @if(session('success'))
        <div class="col-md-12 mb-3 px-0">
            <div class="alert alert-success block">
                <b><span class="oi oi-info"></span></b> {!! session('success') !!}
            </div>
        </div>
        @endif
        <div id="appointment__update" class="form d-flex flex-wrap w-100">
            {{-- Appointment Information --}}
            <div class="col-lg-7 pl-lg-0">
                <form 
                    id="update-appointment-form" 
                    method="POST" 
                    action="{{ route('appointments.update', $appointment->appointment_id) }}" 
                    class="bg-white p-lg-5 p-3 border border-secondary-300"
                    >
                    @csrf
                    @method('PUT')
                    <div class="form-group row">
                        {{-- Client Info --}}
                        @if(Auth::user()->role != 'clinic-client')
                            <div class="form-filter col-md-12 mb-3">
                                <h4>Client Information</h4>
                            </div>
                            <div class="col-md-6 pr-md-0 mb-3">
                                <input 
                                    id="name" 
                                    type="text" 
                                    class="form-control @error('firstname') is-invalid @enderror" 
                                    name="firstname" 
                                    v-model="formData.firstname"
                                    value="{{ isset($request->firstname) ? $request->firstname : '' }}{{ isset($appointment->firstname) ? $appointment->firstname : old('firstname') }}" 
                                    required 
                                    autocomplete="firstname" 
                                    autofocus 
                                    placeholder="First Name"
                                    readonly
                                />
                                @error('firstname')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="col-md-6 mb-3">
                                <input 
                                    id="lastname" 
                                    type="text" 
                                    class="form-control @error('lastname') is-invalid @enderror" 
                                    name="lastname"
                                    v-model="formData.lastname"
                                    value="{{ isset($appointment->lastname) ? $appointment->lastname : old('lastname') }}" 
                                    required
                                    autocomplete="lastname" 
                                    placeholder="Last Name"
                                    readonly
                                />
                        
                                @error('lastname')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="col-md-6 pr-md-0 mb-3">
                                <input 
                                    id="email" 
                                    type="email" 
                                    class="form-control @error('email') is-invalid @enderror" 
                                    name="email" 
                                    v-model="formData.email"
                                    value="{{ isset($appointment->email) ? $appointment->email : old('email') }}" 
                                    autocomplete="email" 
                                    autofocus 
                                    placeholder="Email Address"
                                    readonly
                                />
                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="col-md-6 mb-3">
                                <input 
                                    id="phone" 
                                    type="text" 
                                    class="form-control @error('contact_no') is-invalid @enderror" 
                                    name="phone"
                                    v-model="formData.phone"
                                    value="{{ isset($appointment->contact_no) ? $appointment->contact_no : old('contact_no') }}" 
                                    required
                                    autocomplete="phone" 
                                    placeholder="Phone"
                                    readonly
                                />
                        
                                @error('phone')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="col-md-12 mb-3">
                                <input 
                                    id="address" 
                                    type="text" 
                                    class="form-control @error('address') is-invalid @enderror" 
                                    name="address"
                                    v-model="formData.address"
                                    value="{{ isset($appointment->address) ? $appointment->address : old('address') }}" 
                                    required
                                    autocomplete="address" 
                                    placeholder="Address"
                                    readonly
                                />
                        
                                @error('address')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        @endif

                        @if(Auth::user()->role == 'clinic-client' || Auth::user()->role == 'admin')
                        <div class="form-filter col-md-12 mb-3 mt-3">
                            <h4>Clinic Information</h4>
                        </div>
                        <div class="col-md-12 mb-3">
                            <input 
                                id="clinic_id" 
                                type="text" 
                                class="form-control @error('clinic_id') is-invalid @enderror" 
                                name="clinic_id" 
                                v-model="formData.clinic_id"
                                value="{{ isset($appointment->clinic_name) ? $appointment->clinic_name : old('clinic_name') }}" 
                                required 
                                autocomplete="clinic_id" 
                                placeholder="Clinic"
                                readonly
                            />
                        </div>
                        @endif
                        {{-- Pet Info --}}
                        <div class="form-filter col-md-12 mb-3 mt-3">
                            <h4>Pet Information</h4>
                        </div>
                        <div class="col-md-12 mb-3">
                            <div class="d-flex">
                                <select name="pet_id" class="form-control" {!! $readOnly !!}>
                                    @if(count($pets))
                                        @foreach($pets as $pet)
                                            <option value="{{ $pet->id }}" {{$pet->id == $appointment->pet_id ? "selected" : ''}}>{{ $pet->name}} - {{ $pet->species }}</option>
                                        @endforeach
                                    @else
                                        <option>No Available Pet</option>
                                    @endif
                                </select>
                                @if(!count($pets))  
                                    <a href="{{ route('pets.create', ['patient_id' => $appointment->patient_id]) }}" class="btn btn-primary nowrap ml-2 px-3">New Pet</a>
                                @endif
                            </div>
                            @error('pet_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        {{-- Appointment Info --}}
                        <div class="form-filter col-md-12 mb-3 mt-3">
                            <h4>Appointment Details</h4>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="appointment_date" class="mb-0">Appointment Date</label>
                            <input 
                                id="appointment_date" 
                                type="date" 
                                class="form-control @error('appointment_date') is-invalid @enderror" 
                                name="appointment_date" 
                                v-model="formData.appointmentDate"
                                value="{{ isset($appointment->appointment_date) ? $appointment->appointment_date : old('appointment_date') }}" 
                                required 
                                autocomplete="appointment_date" 
                                placeholder="Appointment Date"
                                {!! $readOnly !!}
                            />
                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="appointment_time" class="mb-0">
                                Appointment Time 
                                {{-- <span style="font-size:12px">(Office Hour: 9am - 4pm only)</span> --}}
                            </label>
                            <input 
                                id="appointment_time" 
                                type="time" 
                                class="form-control @error('appointment_time') is-invalid @enderror" 
                                name="appointment_time"
                                v-model="formData.appointmentTimeEnd"
                                value="{{ isset($appointment->appointment_time) ? $appointment->appointment_time : old('appointment_time') }}" 
                                required
                                autocomplete="appointment_time" 
                                placeholder="Appointment Time"
                                {!! $readOnly !!}
                            />
                    
                            @error('appointment_time')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="appointment_time" class="mb-0">
                                End of Appointment
                            </label>
                            <input 
                                id="appointment_timeend" 
                                type="time" 
                                class="form-control @error('appointmeappointment_timeendnt_time') is-invalid @enderror" 
                                name="appointment_timeend"
                                value="{{ isset($appointment->appointment_timeend) ? $appointment->appointment_timeend : old('appointment_timeend') }}" 
                                required
                                {{-- min="09:00" 
                                max="17:00" --}}
                                autocomplete="appointment_timeend" 
                                placeholder="Appointment Time"
                                {!! $readOnly !!}
                            />
                    
                            @error('appointment_timeend')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        @if(count($services))
                            <div class="col-md-12 mb-3">
                                <label for="service_id" class="mb-0">
                                    Services
                                </label>

                                <div class="row">
                                    @php
                                        $appointmentServices = json_decode($appointment->services);
                                    @endphp
                                    @foreach($services as $service)
                                    <label class="service-item col-xl-4">
                                        <div class="service-item__inner">
                                            <input 
                                                type="checkbox" 
                                                name="services[]" 
                                                value="{!! $service->id !!}" 
                                                class="mr-2" 
                                                {!! in_array($service->id, $appointmentServices) ? 'checked' : '' !!}
                                                {!! $readOnly !!}
                                            />
                                            <h5 class="mb-0">{!! $service->title !!}</h5>
                                            <div>₱{!! number_format($service->price) !!}</div>
                                        </div>
                                    </label>
                                    @endforeach
                                </div>

                                {{-- <select id="service_id" name="service_id" class="form-control">
                                    @foreach($services as $service)
                                        <option value="{{ $service->id }}" {{ ($service->id === $appointment->service_id) ? 'selected' : '' }}>
                                            {{ $service->title }}
                                        </option>
                                    @endforeach
                                </select> --}}
                        
                                @error('service_id')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        @endif
                        <div class="col-md-12 mb-3">
                            <label for="status" class="mb-0">Status</label>
                            <select name="status" class="form-control" v-model="formData.status"  {!! $readOnly !!}>
                                <option value="approved" {{ (isset($appointment->status) && $appointment->status == 'approved') || old('status') == 'approved' ? 'selected' : '' }}>Approved</option>
                                <option value="pending" {{ (isset($appointment->status) && $appointment->status == 'pending') || old('status') == 'pending' ? 'selected' : '' }}>Pending</option>
                                <option value="cancelled" {{ (isset($appointment->status) && $appointment->status == 'cancelled') || old('status') == 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                                <option value="done" {{ (isset($appointment->status) && $appointment->status == 'done') || old('status') == 'done' ? 'selected' : '' }}>Done</option>
                            </select>
                        </div>
                        <div class="col-md-12 mb-3">
                            <textarea 
                                id="message"
                                name="message"
                                v-model="formData.message"
                                placeholder="Message"
                                style="min-height:200px"
                                class="form-control @error('message') is-invalid @enderror"
                                {!! $readOnly !!}
                            >{{ $appointment->message }}</textarea>
                    
                            @error('message')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>
                    @if(Auth::user()->role != 'clinic-client')
                    <div class="offset-md-8 col-md-4 px-0">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="far fa-save"></i> Update Appointment
                        </button>
                    </div>
                    @endif
                </form>
            </div>

            {{-- Findings Information --}}
            <div class="col-lg-5 mt-lg-0 mt-3 pr-lg-0">
                <div class="accordion px-0" id="reservation">
                    <div class="card">
                        <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="doctor-note-label">
                            <button 
                                class="btn text-light" 
                                type="button" 
                                data-toggle="collapse" 
                                data-target="#doctor-note" 
                                aria-expanded="true" 
                                aria-controls="collapseOne"
                                style="letter-spacing: 1px;"
                                >
                                <strong>Doctor's Note</strong>
                            </button>
                            <div class="d-flex">
                                {{-- <button type="button" class="btn btn-outline-light px-4 btn-print mr-2">Print</a> --}}
                                @if(Auth::user()->role != 'clinic-client')
                                <button type="submit" class="btn btn-secondary px-4" form="update-appointment-form">
                                    Save
                                </button>
                                @endif
                            </div>
                        </div>
                  
                        <div id="doctor-note" class="collapse show" aria-labelledby="doctor-note-label" data-parent="#doctor-note">
                            <div class="card-body">
                                <textarea 
                                    id="findings"
                                    name="findings" 
                                    class="form-control" 
                                    style="min-height: 300px"
                                    form="update-appointment-form"
                                    >{{$appointment->findings}}</textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<iframe name="print_frame" width="0" height="0" frameborder="0" src="about:blank"></iframe>
@endsection

@section('footer_script')
<script>
    var webInfo = {
        baseUrl: '{!! URL::to('/') !!}',
        action: 'update',
        appointmentInfo: {!! json_encode($appointment) !!},
    }
</script>
<script src="{{ asset('js/update-form.js') }}" defer></script>
@endsection