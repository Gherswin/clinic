@extends('layouts.app')

@section('content')
<div class="container staffs">
    <div id="appointments" class="appointments">
        <div class="form-header mb-4">
            <h1 class="form-title">Appointments</h1>
        </div>
        
        <div class="btns-container mb-4">
            <a href="{{route('appointments.create')}}" class="btn btn-primary w-100 max-w-200">Make An Appointment</a>
        </div>

        <div class="filters mb-4">
            <form id="" method="get" action="" class="row">
                <input type="hidden" name="date" :value="formData.date" />
                @if(Auth::user()->role == 'admin')
                <div class="col-lg-5 col-md-12 pr-lg-0 mb-lg-0 mb-3">
                    <input type="text" name="name" value="{{$request->name}}" class="form-control" placeholder="Client Name" autofocus />
                </div>
                @endif
                <div class="col-lg-3 col-md-6 pr-lg-0 mb-lg-0 mb-3">
                    <select name="status" class="form-control">
                        <option value="">All</option>
                        <option value="approved" {{($request->status == 'approved') ? 'selected' : ''}}>Approved</option>
                        <option value="pending" {{($request->status == 'pending') ? 'selected' : ''}}>Pending</option>
                        <option value="cancelled" {{($request->status == 'cancelled') ? 'selected' : ''}}>Cancelled</option>
                        <option value="done" {{($request->status == 'done') ? 'selected' : ''}}>Done</option>
                    </select>
                </div>
                {{-- <div class="col-lg-2 col-md-6 pr-lg-0 mb-lg-0 mb-3">
                    <input type="date" name="dateto" value="{{$request->dateto}}" class="form-control" placeholder="Date To" />
                </div> --}}
                <div class="col-lg-2 col-md-12 pr-lg-0 mb-lg-0 mb-3">
                    <a href="{{ route('appointments.index') }}" class="btn btn-outline-secondary d-block">Goto Today</a>
                </div>
                <div class="col-lg-2 col-md-12">
                    <button type="submit" class="btn btn-secondary w-100">
                        Search
                    </button>
                </div>
            </form>
        </div>
        @if(session('success'))
            <div class="alert alert-success block">
                <b><span class="oi oi-info"></span></b> {!! session('success') !!}
            </div>
        @endif
        <div class="appointments-ledger mb-4">
            <div class="appointments-ledger__item text-right" style="border: 0px;font-weight:600">
                Ledger:
            </div>
            <div class="appointments-ledger__item appointments-ledger__item--approved">
                Approved
            </div>
            <div class="appointments-ledger__item appointments-ledger__item--pending">
                Pending
            </div>
            <div class="appointments-ledger__item appointments-ledger__item--cancelled">
                Cancelled
            </div>
            <div class="appointments-ledger__item appointments-ledger__item--done">
                Done
            </div>
        </div>
        <div class="appointments-calendar">
            <vue-cal 
                class="" 
                {{-- active-view="month" --}}
                :selected-date="formData.date" 
                :events="appointments" 
                events-on-month-view
                @ready="fetchAppointments" 
                @view-change="fetchAppointments"
                >
                <template #event="{event, view}">
                    @if(Auth::user()->role != 'clinic-client')
                    <a 
                        href="#"
                        class="appointment__title" 
                        data-toggle="modal" 
                        data-target="#appointment-detail"
                        v-html="event.title"
                        @click="selectAppointment(event)"
                    ></a>
                    @else
                    <a 
                        class="appointment__title" 
                        :href="`/appointments/${selectedAppointment.appointment_id}/edit`" 
                        v-html="event.title"
                        @click="selectAppointment(event)"
                        class="btn btn-secondary"
                    ></a>
                    @endif
                </template>
            </vue-cal>

            @if(Auth::user()->role != 'clinic-client')
            <!-- Modal -->
            <div class="modal fade" id="appointment-detail" tabindex="-1" aria-labelledby="appointment-detail-Label" aria-hidden="true">
                <div class="modal-dialog">
                    <form method="POST" action="{{ route('appointments.quickupdate') }}" class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="appointment-detail-Label">Appointment Details</h5>
                            <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                <i class="fas fa-times"></i>
                            </a>
                        </div>
                        <div class="modal-body row">
                            @csrf
                            <input type="hidden" name="id" :value="selectedAppointment.appointment_id" />
                            <div class="col-md-12">
                                <label for="name" class="mb-0">Client Name</label>
                                <input id="name" type="text" name="name" value="" class="form-control " :value="`${selectedAppointment.firstname} ${selectedAppointment.lastname}`" readonly />
                            </div>
                            <div class="col-md-12">
                                <label for="appointment_date" class="mb-0">Date of Appointment</label>
                                <input id="appointment_date" type="date" name="appointment_date"v-model="selectedAppointment.appointment_date" class="form-control " />
                            </div>
                            <div class="col-md-12">
                                <label for="appointment_time" class="mb-0">Start of Appointment </label>
                                <input id="appointment_time" type="time" name="appointment_time" v-model="selectedAppointment.appointment_time" class="form-control " />
                            </div>
                            <div class="col-md-12">
                                <label for="appointment_timeend" class="mb-0">End of Appointment</label>
                                <input id="appointment_timeend" type="time" name="appointment_timeend" v-model="selectedAppointment.appointment_timeend" class="form-control " />
                            </div>
                            <div class="col-md-12">
                                <label for="name" class="mb-0">Status</label>
                                <select name="status" class="form-control" v-model="selectedAppointment.status">
                                    <option value="approved">Approved</option>
                                    <option value="pending">Pending</option>
                                    <option value="cancelled">Cancelled</option>
                                    <option value="done">Done</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <a :href="`/appointments/${selectedAppointment.appointment_id}/edit`" type="button" class="btn btn-secondary">See Full Details</a>
                            <button type="submit" class="btn btn-primary">Update Appointment</button>
                        </div>
                    </form>
                </div>
                @endif
            </div>
        </div>
        {{-- <div class="records">
            @if(session('success'))
                <div class="alert alert-success block">
                    <b><span class="oi oi-info"></span></b> {!! session('success') !!}
                </div>
            @endif
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col" class="nowrap">Client Name</th>
                            <th scope="col" class="nowrap">Email</th>
                            <th scope="col"> Date</th>
                            <th scope="col">Time</th>
                            <th scope="col">Status</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        @if(count($appointments)) 
                            @foreach($appointments as $appointment) 
                                <tr>
                                    <td scope="row">{{$appointment->appointment_id}}</td>
                                    <td class="nowrap">{{$appointment->firstname}} {{$appointment->lastname}}</td>
                                    <td class="nowrap">{{$appointment->email}}</td>
                                    <td class="nowrap">{{$appointment->appointment_date}}</td>
                                    <td class="nowrap">{!! date('h:i a', strtotime($appointment->appointment_time)) !!}</td>
                                    <td class="nowrap">
                                        <span class="{!! $appointment->status == 'approved' ? 'text-success' : '' !!} {!! $appointment->status == 'cancelled' ? 'text-danger' : '' !!}">
                                            {{$appointment->status}}
                                        </span>
                                    </td>
                                    <td class="text-center" style="width: 130px">
                                        <div class="nowrap">
                                            <a href="{{ route('appointments.edit', $appointment->appointment_id) }}" class="btn btn-primary btn-sm min-w-50" title="View Information">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <button type="button" class="btn btn-secondary btn-sm min-w-50" title="Delete" data-toggle="modal" data-target="#delete-{{ $appointment->appointment_id }}">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>

                                        <!-- Modal -->
                                        <div class="modal fade" id="delete-{{ $appointment->appointment_id }}" tabindex="-1" aria-labelledby="delete-{{ $appointment->appointment_id }}-Label" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <form method="POST" action="{{ route('appointments.destroy', $appointment->appointment_id)}}" class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="delete-{{ $appointment->appointment_id }}-Label">Delete Record</h5>
                                                        <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                            <i class="fas fa-times"></i>
                                                        </a>
                                                    </div>
                                                    <div class="modal-body">
                                                        @csrf
                                                        @method('DELETE')
                                                        <input type="hidden" name="id" value="{{ $appointment->appointment_id }}">
                                                        <div class="text-center mb-3">
                                                            <i class="far fa-question-circle text-primary" style="font-size: 60px;line-height: 1em;"></i>
                                                        </div>
                                                        <div class="max-w-400 m-auto">
                                                            Are you sure you want to permanetly delete the appointment record for <strong>{{$appointment->firstname}} {{ $appointment->lastname}}</strong>?
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-danger">Delete</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
            <div class="pagination">
                {!! $appointments->appends(Request::except('page'))->links() !!}
            </div>
        </div> --}}
    </div>
</div>
@endsection


@section('footer_script')
    <script>
        var webInfo = {
            baseUrl: '{!! URL::to('/') !!}',
            appointmentType: '{!! $appointmentType !!}',
            currentUser:  {
                id: '{!! auth()->user()->id !!}',
                clinic_id: '{!! auth()->user()->clinic_id !!}',
                firstname: '{!! auth()->user()->firstname !!}',
                lastname: '{!! auth()->user()->lastname !!}',
            },
            params: {
                name: '{{ $request->name }}',
                date: '{{ $request->date ?? date("Y-m-d") }}',
                status: '{{ $request->status }}',
            }
        } 
    </script>
    <script src="{{ asset('js/appointments.js') }}" defer></script>
@endsection