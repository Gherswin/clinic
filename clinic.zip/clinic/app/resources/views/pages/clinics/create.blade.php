@extends('layouts.app')

@section('content')
<div class="container-fluid clinics">
    <div class="row">
        <div class="col-md-12 pl-lg-0">
            <div class="form-header offset-md-2 col-md-8 mb-3 px-0">
                <h1 class="form-title">New Clinic Information</h1>
            </div>

            <form method="POST" action="{{ route('clinics.store') }}" enctype="multipart/form-data" class="col-lg-8 offset-lg-2 bg-white p-lg-5 py-3 border border-secondary-300 mb-4">
                @include('pages.clinics.form')
            </form>
        </div>
    </div>
</div>
@endsection
