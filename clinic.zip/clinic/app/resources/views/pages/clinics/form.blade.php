@csrf
<div class="form-group row">
    <div class="col-md-12 mb-3">
        <label for="image">Clinic Image</label>
        <input 
            id="image" 
            type="file" 
            class="form-control @error('image') is-invalid @enderror" 
            name="image" 
            accept="image/*"
        />
        @if(isset($clinic->image) && $clinic->image)
            <img 
                src="{{ asset('images/clinics/' . $clinic->image) }}" 
                class="form-image"
            />
        @endif
    </div>
    <div class="col-md-6 pr-md-0 mb-3">
        <label for="name">Main Contact</label>
        <select class="form-control" name="user_id">
            @if($clinicUsers && count($clinicUsers))
                <option value="" {{ !isset($clinic->user_id) || "" == $clinic->user_id  ? 'selected' : '' }}>--Select--</option>
                @foreach($clinicUsers as $user)
                    <option value="{{ $user->id }}" {{ isset($clinic->user_id) && $user->id === $clinic->user_id  ? 'selected' : '' }}> {{ $user->firstname }} {{ $user->lastname}}</option>
                @endforeach
            @endif
        </select>
        @error('user_id')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 mb-3">
        <label for="name">Name</label>
        <input 
            id="name" 
            type="text" 
            class="form-control @error('name') is-invalid @enderror" 
            name="name" 
            value="{{ isset($clinic->name) ? $clinic->name : old('name') }}" 
            required 
            autocomplete="name" 
            autofocus 
            placeholder="Company Name"
        />
        @error('name')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-12 mb-3">
        <label for="address">Address</label>
        <input 
            id="address" 
            type="text" 
            class="form-control @error('address') is-invalid @enderror" 
            name="address" 
            value="{{ isset($clinic->address) ? $clinic->address : old('address') }}" 
            required 
            autofocus 
            placeholder="Address"
        />
        @error('address')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 pr-md-0 mb-3">
        <label for="email">Email</label>
        <input 
            id="email" 
            type="text" 
            class="form-control @error('email') is-invalid @enderror" 
            name="email" 
            value="{{ isset($clinic->email) ? $clinic->email : old('email') }}" 
            required 
            autofocus 
            placeholder="Email Address"
        />
        @error('email')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 mb-3">
        <label for="phone">Phone</label>
        <input 
            id="contact_no" 
            type="text" 
            class="form-control @error('contact_no') is-invalid @enderror" 
            name="contact_no" 
            value="{{ isset($clinic->contact_no) ? $clinic->contact_no : old('contact_no') }}" 
            required 
            autofocus 
            placeholder="Contact Number"
        />
        @error('contact_no')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    {{-- <div class="col-md-12 mb-3">
        <label for="operating_hours">Operating Hours</label>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">Day</th>
                        <th scope="col" class="nowrap">Time Start</th>
                        <th scope="col" class="nowrap">Time End</th>
                    </tr>
                </thead>
                <tbody>
                    <tr valign="center">
                        <td style="vertical-align:middle">Monday</td>
                        <td>
                            <input type="time" name="mon_timestart" value="{{ isset($clinic->mon_timestart) ? $clinic->mon_timestart : '' }}" class="form-control">
                        </td>
                        <td>
                            <input type="time" name="mon_timeend" value="{{ isset($clinic->mon_timeend) ? $clinic->mon_timeend : '' }}" class="form-control">
                        </td>
                    </tr>   
                    <tr valign="center">
                        <td style="vertical-align:middle">Tuesday</td>
                        <td>
                            <input type="time" name="tue_timestart" value="{{ isset($clinic->tue_timestart) ? $clinic->tue_timestart : '' }}" class="form-control">
                        </td>
                        <td>
                            <input type="time" name="tue_timeend" value="{{ isset($clinic->tue_timeend) ? $clinic->tue_timeend : '' }}" class="form-control">
                        </td>
                    </tr>   
                    <tr valign="center">
                        <td style="vertical-align:middle">Wednesday</td>
                        <td>
                            <input type="time" name="wed_timestart" value="{{ isset($clinic->wed_timestart) ? $clinic->wed_timestart : '' }}" class="form-control">
                        </td>
                        <td>
                            <input type="time" name="wed_timeend" value="{{ isset($clinic->wed_timeend) ? $clinic->wed_timeend : '' }}" class="form-control">
                        </td>
                    </tr>   
                    <tr valign="center">
                        <td style="vertical-align:middle">Thursday</td>
                        <td>
                            <input type="time" name="thu_timestart" value="{{ isset($clinic->thu_timestart) ? $clinic->thu_timestart : '' }}" class="form-control">
                        </td>
                        <td>
                            <input type="time" name="thu_timeend" value="{{ isset($clinic->thu_timeend) ? $clinic->thu_timeend : '' }}" class="form-control">
                        </td>
                    </tr>   
                    <tr valign="center">
                        <td style="vertical-align:middle">Friday</td>
                        <td>
                            <input type="time" name="fri_timestart" value="{{ isset($clinic->fri_timestart) ? $clinic->fri_timestart : '' }}" class="form-control">
                        </td>
                        <td>
                            <input type="time" name="fri_timeend" value="{{ isset($clinic->fri_timeend) ? $clinic->fri_timeend : '' }}" class="form-control">
                        </td>
                    </tr>   
                    <tr valign="center">
                        <td style="vertical-align:middle">Saturday</td>
                        <td>
                            <input type="time" name="sat_timestart" value="{{ isset($clinic->sat_timestart) ? $clinic->sat_timestart : '' }}" class="form-control">
                        </td>
                        <td>
                            <input type="time" name="sat_timeend" value="{{ isset($clinic->sat_timeend) ? $clinic->sat_timeend : '' }}" class="form-control">
                        </td>
                    </tr>   
                    <tr valign="center">
                        <td style="vertical-align:middle">Sunday</td>
                        <td>
                            <input type="time" name="sun_timestart" value="{{ isset($clinic->sun_timestart) ? $clinic->sun_timestart : '' }}" class="form-control">
                        </td>
                        <td>
                            <input type="time" name="sun_timeend" value="{{ isset($clinic->sun_timestart) ? $clinic->sun_timestart : '' }}" class="form-control">
                        </td>
                    </tr>   
                </tbody>
            </table>
        </div>
    </div> --}}
</div>


<div class="offset-md-8 col-md-4 px-0">
    <button type="submit" class="btn btn-primary w-100">
        <i class="far fa-save"></i> Save
    </button>
</div>
  