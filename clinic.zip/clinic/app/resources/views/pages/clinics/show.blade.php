@extends('layouts.front')

@section('content')
    <!-- Hero -->
    <div id="home" class="hero hero__md section-container d-flex flex-center" style="background-image:url({{ asset('images/hero.jpg') }})">
        <div class="container w-100">
            @if($clinic->image)
            <div class="clinic-info__imgholder">
                <img 
                    src="{{ $clinic->image ? asset('images/clinics/' . $clinic->image) : asset('images/logo.jpg') }}"
                    class="clinic-info__img"
                />
            </div>
            @endif
            <h1 class="text-center text-primary font-weight-bold">{{$clinic->name}}</h1>
            <div class="hero__subheading text-center text-primary max-w-500 mx-auto">{{ $clinic->address }}</div>
            <div class="mt-4 text-center text-uppercase" style="letter-spacing:1.6px">
                <a href="/make-an-appointment" class=" btn btn-secondary btn-extra">Make An Appointment</a>
            </div>
        </div>
    </div>
    <!-- End Hero -->

    <div id="contact" class="about section-container" style="background-color:#fff">
        <div class="container section">
            <h2 class="text-center mb-4 text-primary font-weight-bold">Clinic Information</h2>
            <div class="contact__wrapper offset-md-1 col-md-10">
                <div class="contact__wrapper-inner">
                    <div class="contact__item">
                        <div class="contact__item-icon">
                            <i class="icon fas fa-phone-alt"></i>
                        </div>
                        <div class="contact__item-details">
                            <div class="contact__item-label">Phone:</div>
                            <div class="contact__item-text">{{ $clinic->contact_no }}</div>
                        </div>
                    </div>

                    <div class="contact__item">
                        <div class="contact__item-icon">
                            <i class="icon fas fa-envelope"></i>
                        </div>
                        <div class="contact__item-details">
                            <div class="contact__item-label">Email:</div>
                            <div class="contact__item-text">{{ $clinic->email }}</div>
                        </div>
                    </div>
                    
                    <div class="contact__item">
                        <div class="contact__item-icon">
                            <i class="icon fas fa-map-marked"></i>
                        </div>
                        <div class="contact__item-details">
                            <div class="contact__item-label">Address:</div>
                            <div class="contact__item-text">{{ $clinic->address }}</div>
                        </div>
                    </div>

                    <div class="contact__item contact__item__hours">
                        <div class="contact__item-icon">
                            <i class="icon fas fa-clock"></i>
                        </div>
                        <div class="contact__item-details">
                            <div class="contact__item-label">Operating Hours:</div>
                            <div class="contact__item-text">
                                @foreach(unserialize($clinic->operating_hours) as $time)
                                    <div class="clinic-card__hours__item">
                                        @if($time['day'] === 'mon')
                                            Monday
                                        @elseif($time['day'] === 'tue')
                                            Tuesday
                                        @elseif($time['day'] === 'wed')
                                            Wednesday
                                        @elseif($time['day'] === 'thu')
                                            Thursday
                                        @elseif($time['day'] === 'fri')
                                            Friday
                                        @elseif($time['day'] === 'sat')
                                            Saturday
                                        @elseif($time['day'] === 'sun')
                                            Sunday
                                        @endif
                                        {{ date("h:i a", strtotime($time['timestart'])) }} - {{date("h:i a", strtotime($time['timeend'])) }}
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {{-- <div class="contact__map offset-md-2 col-md-8">
                <iframe 
                    width="100%" 
                    height="400" 
                    id="gmap_canvas" 
                    src="https://maps.google.com/maps?q=MH%20Del%20Pilar%20St,%20Tarlac%20City,%202300%20Tarlac&t=&z=13&ie=UTF8&iwloc=&output=embed" 
                    frameborder="0" 
                    scrolling="no" 
                    marginheight="0"
                    marginwidth="0"
                    >
                </iframe>
            </div> --}}
        </div>
    </div> {{-- End Contact --}}

    @if(count($services))
        <div id="services" class="about section-container bg-primary">
            <div class="container section">
                <h2 class="text-center mb-4 text-white font-weight-bold">Our Services</h2>
                <div class="d-flex flex-wrap justify-content-center offset-md-1 col-md-10">
                    @foreach($services as $service)
                        <div class="service-card">
                            <div class="service-card__heading">
                                <div class="service-card__title">{{ $service->title }}</div>
                                <div class="service-card__price">
                                    Php. {{  number_format($service->price, 2) }}
                                </div>
                            </div>
                            <div class="service-card__body">
                                {{ $service->description }}
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div> 
    @endif {{-- End Services --}}

    {{-- <div id="make-an-appointment" class="appointment section-container" style="background-color:#f9ecd9">
        <div class="container section">
            <h2 class="text-center mb-5 text-primary font-weight-bold">Make an Appointment <br class="d-none d-md-block"> at {{ $clinic->name }}</h2>

            <div id="appointment__create" class="form row d-flex justify-content-center w-100">
                <form method="POST" action="{{ route('appointments.makeappointment') }}" class="appointment-form col-md-8">
                    @csrf

                    @if(session('success'))
                        <div class="alert alert-success block">
                            <b><span class="oi oi-info"></span></b> {!! session('success') !!}
                        </div>
                    @endif
                    <div class="form-group row">
                        <input type="hidden" name="clinic_id" value="{{ $clinic->id }}">
                        <input type="hidden" name="id" v-model="formData.id">
                        <div class="col-md-6 pr-md-0 mb-3">
                            <label for="firstname" class="mb-0">First Name</label>
                            <input 
                                id="firstname" 
                                type="text" 
                                class="form-control @error('firstname') is-invalid @enderror" 
                                name="firstname" 
                                value="{{ old('firstname') }}" 
                                required 
                                autocomplete="firstname" 
                                placeholder="First Name"
                            />
                            @error('firstname')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="lastname" class="mb-0">Last Name</label>
                            <input 
                                id="lastname" 
                                type="text" 
                                class="form-control @error('lastname') is-invalid @enderror" 
                                name="lastname"
                                value="{{ old('lastname') }}" 
                                required
                                autocomplete="lastname" 
                                placeholder="Last Name"
                            />
                    
                            @error('lastname')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-6 pr-md-0 mb-3">
                            <label for="email" class="mb-0">Email</label>
                            <input 
                                id="email" 
                                type="email" 
                                class="form-control @error('email') is-invalid @enderror" 
                                name="email" 
                                value="{{ old('email') }}" 
                                required 
                                autocomplete="email" 
                                placeholder="Email Address"
                            />
                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="phone" class="mb-0">Phone</label>
                            <input 
                                id="phone" 
                                type="text" 
                                class="form-control @error('phone') is-invalid @enderror" 
                                name="phone"
                                value="{{ old('phone') }}" 
                                required
                                autocomplete="phone" 
                                placeholder="Phone"
                            />
                    
                            @error('phone')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="address" class="mb-0">Address</label>
                            <input 
                                id="address" 
                                type="text" 
                                class="form-control @error('address') is-invalid @enderror" 
                                name="address"
                                value="{{ old('address') }}" 
                                autocomplete="address" 
                                placeholder="Address"
                            />
                    
                            @error('address')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-6 pr-md-0 mb-3">
                            <label for="appointment_date" class="mb-0">Appointment Date</label>
                            <input 
                                id="appointment_date" 
                                type="date" 
                                class="form-control @error('appointment_date') is-invalid @enderror" 
                                name="appointment_date" 
                                v-model="formData.appointmentDate"
                                value="{{ isset($appointment->appointment_date) ? $appointment->appointment_date : old('appointment_date') }}" 
                                required 
                                autocomplete="appointment_date" 
                                placeholder="Appointment Date"
                            />
                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="appointment_time" class="mb-0">Appointment Time</label>
                            <input 
                                id="appointment_time" 
                                type="time" 
                                class="form-control @error('appointment_time') is-invalid @enderror" 
                                name="appointment_time"
                                v-model="formData.appointmentTime"
                                value="{{ isset($appointment->appointment_time) ? $appointment->appointment_time : old('appointment_time') }}" 
                                required
                                autocomplete="appointment_time" 
                                placeholder="Appointment Time"
                            />
                    
                            @error('appointment_time')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        @if(count($services))
                        <div class="col-md-12 mb-3">
                            <label for="service_id" class="mb-0">About this appointment all about</label>
                            <select id="service_id" name="service_id" class="form-control">
                                @foreach($services as $service)
                                    <option value="{{ $service->id }}">{{ $service->title }}</option>
                                @endforeach
                            </select>
                    
                            @error('service_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        @endif
                        <div class="col-md-12 mb-3">
                            <label for="message" class="mb-0">Message</label>
                            <textarea 
                                id="message"
                                name="message"
                                v-model="formData.message"
                                placeholder="Message"
                                style="min-height:200px"
                                class="form-control @error('message') is-invalid @enderror"></textarea>
                    
                            @error('message')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-12 mb-3">
                            <input id="iagree" type="checkbox" value="i-agree" checked required>
                            <label for="iagree">I agree to the <a href="/terms-and-conditions" target="_blank">Terms and Conditions</a> and <a href="/privacy-policy" target="blank">Privacy Policy</a></label>
                        </div>
                    </div>
    
                    <div style="col-md-12 p-md-0">
                        <button type="submit" class="btn btn-primary w-100" style="max-width: 230px">
                                Make An Appointment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div> --}} {{-- End Appointment --}}
@endsection