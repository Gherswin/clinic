@extends('layouts.app')

@section('content')
<div class="container-fluid staffs">
    <div class="">
        <div class="form row">
            <div class="dashboard__btns offset-md-3 col-md-6 px-0 d-flex flex-wrap">
                <div class="dashboard__btns-item col-md-4">
                    <a href="{{ route('appointments.create') }}" class="dashboard__btns-item-link">
                       <span>
                            <i class="icon fas fa-calendar-check"></i> 
                            New Appointments
                       </span>
                    </a>
                </div>
                <div class="dashboard__btns-item col-md-4">
                    <a href="{{ route('appointments.index') }}" class="dashboard__btns-item-link">
                       <span>
                            <i class="icon fas fa-calendar"></i> 
                            My Appointments
                       </span>
                    </a>
                </div>
            </div>
            
            <div class="mt-4 offset-md-3 col-md-6">
                <div class="accordion " id="upcoming-appointments-container">
                    <div class="card">
                        <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="upcoming-appointments-header">
                            <button 
                                class="btn text-light" 
                                type="button" 
                                data-toggle="collapse" 
                                data-target="#upcoming-appointments" 
                                aria-expanded="true" 
                                aria-controls="upcoming-appointments-header"
                                style="letter-spacing: 1px;"
                                >
                                <strong>My Appointments</strong>
                            </button>
                        </div>
                
                        <div id="upcoming-appointments" class="collapse show" aria-labelledby="headingOne" data-parent="#upcoming-appointments-container">
                            <div class="card-body table-responsive">
                                @if(count($myAppointments))
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">Appointment</th>
                                                <th scope="col" style="width: 100px">Status</th>
                                                {{-- <th scope="col" style="width: 100px"></th> --}}
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($myAppointments as $key => $appointment) 
                                            <tr>
                                                {{-- <td scope="row">{{$appointment->firstname}} {{$appointment->lastname}}</td> --}}
                                                <td scope="row">{{$key + 1}}</td>
                                                <td class="nowrap">{{ $appointment->appointment_date }} - {!! date('H:i a', strtotime($appointment->appointment_time)) !!}</td>
                                                <td class="nowrap">{{ $appointment->status }}</td>
                                                {{-- <td class="nowrap text-right">
                                                    <a href="{{ route('appointments.edit', $appointment->appointment_id) }}" class="btn btn-secondary btn-sm min-w-50" title="Edit"><i class="far fa-edit"></i></a>
                                                </td> --}}
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                @else
                                    <div class="text-center py-5">
                                      No Appointment yet.
                                      <br/>
                                      <a href="{{ route('appointments.create') }}">Click here to create an appointment</a>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
