@extends('layouts.app')

@section('content')
<div class="container-fluid staffs">
    <div class="">
        <div class="form row">
            <div class="dashboard__btns col-lg-12 px-0 d-flex flex-wrap">
                <div class="dashboard__btns-item col-md-4">
                    <a href="{{ route('appointments.create') }}" class="dashboard__btns-item-link">
                       <span>
                            <i class="icon fas fa-calendar-check"></i> 
                            New Appointments
                       </span>
                    </a>
                </div>

                <div class="dashboard__btns-item col-md-4">
                    <a href="{{ route('patients.index') }}" class="dashboard__btns-item-link">
                       <span>
                            <i class="icon fas fa-user-injured"></i> 
                            New Client
                       </span>
                    </a>
                </div>

                <div class="dashboard__btns-item col-md-4">
                    <a href="{{ route('staffs.index') }}" class="dashboard__btns-item-link">
                       <span>
                            <i class="icon fas fa-users"></i> 
                            Staffs
                       </span>
                    </a>
                </div>

                {{-- <div class="dashboard__btns-item col-md-3">
                    <a href="#" class="dashboard__btns-item-link">
                       <span>
                            <i class="icon fas fa-file-alt"></i> 
                            View Report
                       </span>
                    </a>
                </div> --}}
            </div>
            
            <div class="mt-4 col-lg-6">
                <div class="accordion " id="upcoming-appointments-container">
                    <div class="card">
                        <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="upcoming-appointments-header">
                            <button 
                                class="btn text-light" 
                                type="button" 
                                data-toggle="collapse" 
                                data-target="#upcoming-appointments" 
                                aria-expanded="true" 
                                aria-controls="upcoming-appointments-header"
                                style="letter-spacing: 1px;"
                                >
                                <strong>This Week Appointments</strong>
                            </button>
                        </div>
                
                        <div id="upcoming-appointments" class="collapse show" aria-labelledby="headingOne" data-parent="#upcoming-appointments-container">
                            <div class="card-body table-responsive">
                                @if(count($thisWeekAppointments))
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">Name</th>
                                                <th scope="col">Appointment</th>
                                                <th scope="col" style="width: 100px">Status</th>
                                                <th scope="col" style="width: 100px"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($thisWeekAppointments as $appointment) 
                                            <tr>
                                                <td scope="row">{{$appointment->firstname}} {{$appointment->lastname}}</td>
                                                <td class="nowrap">{{ $appointment->appointment_date }} - {!! date('H:i a', strtotime($appointment->appointment_time)) !!}</td>
                                                <td class="nowrap">{{ $appointment->status }}</td>
                                                <td class="nowrap text-right">
                                                    <a href="{{ route('appointments.edit', $appointment->appointment_id) }}" class="btn btn-secondary btn-sm min-w-50" title="Edit"><i class="far fa-edit"></i></a>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                @else
                                    <div class="text-center py-5"> No Appointment for this week.</div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="mt-4 col-lg-6">
                <div class="accordion " id="new-appointments-container">
                    <div class="card">
                        <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="new-appointments-header">
                            <button 
                                class="btn text-light" 
                                type="button" 
                                data-toggle="collapse" 
                                data-target="#new-appointments" 
                                aria-expanded="true" 
                                aria-controls="new-appointments-header"
                                style="letter-spacing: 1px;"
                                >
                                <strong>Pending Appointments</strong>
                            </button>
                        </div>
                
                        <div id="new-appointments" class="collapse show" aria-labelledby="headingOne" data-parent="#new-appointments-container">
                            <div class="card-body table-responsive">
                                @if(count($pendingAppointments))
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">Name</th>
                                                <th scope="col">Appointment</th>
                                                <th scope="col" style="width: 100px">Status</th>
                                                <th scope="col" style="width: 100px"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($pendingAppointments as $appointment) 
                                            <tr>
                                                <td scope="row">{{$appointment->firstname}} {{$appointment->lastname}}</td>
                                                <td class="nowrap">{{ $appointment->appointment_date }} - {!! date('H:i a', strtotime($appointment->appointment_time)) !!}</td>
                                                <td class="nowrap">{{ $appointment->status }}</td>
                                                <td class="nowrap text-right">
                                                    <a href="{{ route('appointments.edit', $appointment->appointment_id) }}" class="btn btn-secondary btn-sm min-w-50" title="Edit"><i class="far fa-edit"></i></a>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                @else
                                    <div class="text-center py-5"> No Pending Appointments.</div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- <div class="mt-4 col-lg-6">
                <div class="accordion " id="low-stocks-container">
                    <div class="card">
                        <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="low-stocks-header">
                            <button 
                                class="btn text-light" 
                                type="button" 
                                data-toggle="collapse" 
                                data-target="#low-stocks" 
                                aria-expanded="true" 
                                aria-controls="low-stocks-header"
                                style="letter-spacing: 1px;"
                                >
                                <strong>Low In Stocks</strong>
                            </button>
                        </div>
                
                        <div id="low-stocks" class="collapse show" aria-labelledby="headingOne" data-parent="#low-stocks-container">
                            <div class="card-body table-responsive">
                                @if(count($medicines))
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">Name</th>
                                                <th scope="col" style="width: 150px">Remaining Stocks</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($medicines as $medicine) 
                                            <tr>
                                                <td scope="row">{{$medicine->item_name}}</td>
                                                <td class="nowrap text-center">{{number_format($medicine->total_qty - $medicine->total_purchase)}}</td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                @else
                                    <div class="text-center py-5"> No Medicine Has Low Stocks.</div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div> --}}

        </div>
    </div>
</div>
@endsection
