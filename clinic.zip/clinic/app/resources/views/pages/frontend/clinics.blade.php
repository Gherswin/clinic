@extends('layouts.front')

@section('content')
    <!-- Hero -->
    <div id="home" class="hero hero__md section-container d-flex flex-center" style="background-image:url({{ asset('images/hero.jpg') }})">
        <div class="container w-100">
            <h2 class="text-center mb-5 text-primary font-weight-bold">Find a Clinic Near You</h2>
            <div class="">
                <form method="GET" action="{{ route('clinics') }}" class="search-form">
                    <div class="search-form__body form-group">
                        <div class="search-form__input">
                            <input 
                                id="name" 
                                type="text" 
                                class="form-control @error('search') is-invalid @enderror" 
                                name="search" 
                                value="{{ $request->search }}" 
                                autocomplete="off" 
                                placeholder="Search Address/Clinic Name "
                            />
                            @error('search')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="search-form__submit">
                            <button type="submit" class="btn btn-primary">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End Hero -->
    
    <!-- Partners -->
    <div id="partners" class="about section-container" style="background-color:#f8fafc">
        <div class="container section">
            @if(count($clinics))
                @foreach($clinics as $clinic)
                    <div class="clinic-card d-flex">
                        <div class="clinic-card__imgholder">
                            <img 
                                src="{{ $clinic->image ? asset('images/clinics/' . $clinic->image) : asset('images/logo.jpg') }}"
                                class="clinic-card__img"
                            />
                        </div>
                        <div class="clinic-card__body">
                            <div class="clinic-card__header">
                                <div class="clinic-card__name">{{ $clinic->name }}</div>
                                <div class="clinic-card__address">{{ $clinic->address }}</div>
                            </div>
                            <div class="clinic-card__details">
                                <div class="clinic-card__contacts">
                                    @if($clinic->email)
                                        <div class="clinic-card__contacts__item">
                                            <div class="clinic-card__label">Email: </div>
                                            <a href=" mailto:{{ $clinic->email }}">{{ $clinic->email }}</a>
                                        </div>
                                    @endif
                                    @if($clinic->email)
                                        <div class="clinic-card__contacts__item">
                                            <div class="clinic-card__label">Phone: </div>
                                            <a href=" mailto:{{ $clinic->contact_no }}">{{ $clinic->contact_no }}</a>
                                        </div>
                                    @endif
                                </div>
                                @if (!empty($clinic->operating_hours))
                                    <div class="clinic-card__operaions">
                                        <div class="clinic-card__label">Operating Hours</div>
                                        <div class="clinic-card__hours">
                                            @foreach(unserialize($clinic->operating_hours) as $time)
                                                <div class="clinic-card__hours__item">
                                                    @if($time['day'] === 'mon')
                                                        Monday
                                                    @elseif($time['day'] === 'tue')
                                                        Tuesday
                                                    @elseif($time['day'] === 'wed')
                                                        Wednesday
                                                    @elseif($time['day'] === 'thu')
                                                        Thursday
                                                    @elseif($time['day'] === 'fri')
                                                        Friday
                                                    @elseif($time['day'] === 'sat')
                                                        Saturday
                                                    @elseif($time['day'] === 'sun')
                                                        Sunday
                                                    @endif
                                                    {{ date("h:i a", strtotime($time['timestart'])) }} - {{date("h:i a", strtotime($time['timeend'])) }}
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                @endif
                            </div>
                            <div class="clinic-card__footer mt-4">
                                <a href="{{ route('clinics.show', $clinic->id) }}" class=" btn btn-primary">View Details</a>
                                <a href="{{ route('signup.create', ['redirect' => rawurlencode('/appointments/create/?clinic=' . $clinic->id)]) }}" class=" btn btn-secondary">Make An Appointment</a>
                            </div>
                        </div>
                    </div>
                @endforeach
            @else
                <h2 class="text-center text-primary">No Record Found</h2>
            @endif

            <div class="clinics-pagination pagination">
                {!! $clinics->appends(Request::except('page'))->links() !!}
            </div>
        </div>
    </div>
    <!-- End Partners -->

@endsection
