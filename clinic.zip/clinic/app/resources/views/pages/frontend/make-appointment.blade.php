@extends('layouts.front')

@section('content')
    <!-- Hero -->
    <div id="make-an-appointment" class="hero section-container d-flex flex-center" style="background-image:url({{ asset('images/hero.jpg') }})">
        <div class="w-100" style="z-index: 10">       
          <div class="appointment-signup w-100 max-w-800 mx-auto bg-white p-lg-5 py-3 border border-secondary-300 mb-4">
            <h1 class="text-center max-w-600 mx-auto">
              Schedule your appointment with ease at 
              <span class="text-primary" style="font-weight:600">PawHub</span>
            </h1>
            <div class="text-primary fs-20 text-center mb-4" style="font-size: 24px">Choose an option to get started</div>

            <div class="max-w-600 mx-auto" style="gap:16px">
              <a href="/sign-up" class="btn btn-primary btn-lg w-100 mb-3 fs-18">
                Sign up for a new account
              </a>
              <a href="/login" class="btn btn-outline-primary btn-outline btn-lg w-100">
                Log in to your existing account
              </a>
            </div>
          </div> 
        </div>
    </div>
    <!-- End Hero -->
  @endsection
  
  @section('footer_script')
      <script>
          var webInfo = {
              baseUrl: '{!! URL::to('/') !!}',
          } 
      </script>
      <script src="{{ asset('js/make-an-appointment.js') }}" defer></script>
  @endsection