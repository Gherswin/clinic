@extends('layouts.front')

@section('content')
<!-- Hero -->
<div id="home" class="hero section-container d-flex flex-center">
    <div class="overlay-bg" style="background-image:url({{ asset('images/intro.jpg') }})"></div>
    <div class="container w-100 text-center" style="z-index:10">
        <div class="row">
            <div class="offset-md-3 col-md-6 bg-white p-md-5 px-3 py-5">
                <div class="mb-4">
                    <i class="fas fa-exclamation-circle text-secondary" style="font-size: 60px;"></i>
                </div>
                <h1 class="mb-4"><span class="text-primary font-weight-bold">THANK YOU!</span></h1>
                <p class="fs-20 max-w-400 m-auto" style="font-size: 18px">
                    Your Appointment has been sent. <br/>
                    We will contact you shortly about the status of your appointment
                </p>
            </div>
        </div>
    </div>
</div>
<!-- End Hero -->
@endsection