@extends('layouts.app')

@section('content')
<div class="container medicine">
    <div class="row">
        <div class="form-header offset-md-2 col-md-8 mb-3 px-0">
            <h1 class="form-title">New Medicine Information</h1>
        </div>
        
        <div class="form row d-flex justify-content-center w-100">
            <form method="POST" action="{{ route('medicines.store') }}" class="col-lg-8 bg-white p-lg-5 py-3 border border-secondary-300">
                @include('pages.medicines.form')
            </form>
        </div>
    </div>
</div>
@endsection
