@extends('layouts.app')

@section('content')
<div class="container-fluid medicine">
    <div class="row">
        <div class="form-header col-md-12 mb-3 px-0">
            <h1 class="form-title">
                {{-- <a href="{{ route('medicines.index') }}">Medicines</a>
                <i class="fas fa-chevron-left"></i> --}}
                Medicine Information
            </h1>
        </div>
        
        <div class="col-lg-4 pl-lg-0">
            <form method="POST" action="{{ route('medicines.update', $medicine->id) }}" class="bg-white p-3 border border-secondary-300">
                @method('PUT')
                @include('pages.medicines.form')
            </form>
        </div>

        <div class="col-lg-8 mt-lg-0 mt-3 pr-lg-0">
            <div class="accordion px-0" id="reservation">
                <div class="card">
                    <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="headingOne">
                        <button 
                            class="btn text-light" 
                            type="button" 
                            data-toggle="collapse" 
                            data-target="#stock-history" 
                            aria-expanded="true" 
                            aria-controls="collapseOne"
                            style="letter-spacing: 1px;"
                            >
                            <strong>STOCKS HISTORY</strong>
                        </button>
                    </div>
            
                    <div id="stock-history" class="collapse show" aria-labelledby="headingOne" data-parent="#reservation">
                        <div class="stocks-form col-md-12">
                            <form action="{{ route('stocks.store') }}" method="POST" class="row py-3" >
                                @csrf
                                <input type="hidden" name="item_id" value="{{ $medicine->id }}">
                                <div class="col-md-9 pr-md-0">
                                    <input 
                                        id="quantity" 
                                        type="number" 
                                        class="form-control @error('quantity') is-invalid @enderror" 
                                        name="quantity" 
                                        required 
                                        autocomplete="quantity" 
                                        placeholder="Add Stocks"
                                    />
                                    @error('quantity')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="col-md-3">
                                    <button type="button" class="btn btn-secondary nowrap w-100" data-toggle="modal" data-target="#confirm-add-stocks">
                                        Add Stocks
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="confirm-add-stocks" tabindex="-1" aria-labelledby="confirm-add-stocks-Label" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="confirm-add-stocks-Label">Add Stocks</h5>
                                                    <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                        <i class="fas fa-times"></i>
                                                    </a>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="text-center mb-3">
                                                        <i class="far fa-question-circle text-primary" style="font-size: 60px;line-height: 1em;"></i>
                                                    </div>
                                                    <div class="max-w-400 m-auto text-center">
                                                        <p>
                                                            Are you sure you want to add stocks for <strong>{{$medicine->id}} - {{ $medicine->item_name}}</strong>?
                                                        </p>
                                                        <p>
                                                            This will be permanetly added on the stocks record for this item.
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Add Stocks</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        @if(session('success'))
                            <div class="col-md-12">
                                <div class="alert alert-success block">
                                    <b><span class="oi oi-info"></span></b> {!! session('success') !!}
                                </div>
                            </div>
                        @endif
                        <div class="card-body table-responsive">
                            @if(count($stocks))
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Quantity</th>
                                            <th scope="col" style="width:200px">Date</th>
                                            {{-- <th scope="col"></th> --}}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($stocks as $stock) 
                                        <tr>
                                            <td scope="row">{{$stock->id}}</td>
                                            <td class="nowrap">{{number_format($stock->qty)}}</td>
                                            <td class="nowrap">{!! date('D d M, Y', strtotime($stock->created_at)) !!}</td>
                                            {{-- <td class="text-center" style="width: 130px">
                                                <div class="nowrap">
                                                    <button type="button" class="btn btn-secondary btn-sm min-w-50" title="Delete Record" data-toggle="modal" data-target="#delete-{{ $stock->id }}">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
        
                                                <!-- Modal -->
                                                <div class="modal fade" id="delete-{{ $stock->id }}" tabindex="-1" aria-labelledby="delete-{{ $stock->id }}-Label" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <form method="POST" action="{{ route('stocks.destroy', $stock->id)}}" class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="delete-{{ $stock->id }}-Label">Delete Record</h5>
                                                                <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                                    <i class="fas fa-times"></i>
                                                                </a>
                                                            </div>
                                                            <div class="modal-body">
                                                                @csrf
                                                                @method('DELETE')
                                                                <input type="hidden" name="id" value="{{ $stock->id }}">
                                                                <div class="text-center mb-3">
                                                                    <i class="far fa-question-circle text-primary" style="font-size: 60px;line-height: 1em;"></i>
                                                                </div>
                                                                <div class="max-w-400 m-auto">
                                                                    Are you sure you want to permanetly delete this record?
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-danger">Delete</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </td> --}}
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                <div class="pagination">
                                    {!! $stocks->appends(Request::except('page'))->links() !!}
                                </div>

                            @else
                                <div class="text-center py-5"> No stock found.</div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>

            <div class="accordion px-0 mt-4" id="purhcase-container">
                <div class="card">
                    <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="purhcase-history-header">
                        <button 
                            class="btn text-light" 
                            type="button" 
                            data-toggle="collapse" 
                            data-target="#purhcase-history" 
                            aria-expanded="true" 
                            aria-controls="purhcase-history-header"
                            style="letter-spacing: 1px;"
                            >
                            <strong>PURCHASE HISTORY</strong>
                        </button>
                    </div>
            
                    <div id="purhcase-history" class="collapse show" aria-labelledby="headingOne" data-parent="#purhcase-container">
                        <div class="card-body table-responsive">
                            @if(count($purchases))
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col" style="width:200px">Transaction No</th>
                                            <th scope="col">Quantity</th>
                                            <th scope="col" style="width:200px">Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($purchases as $purchase) 
                                        <tr>
                                            <td scope="row">{{$purchase->purchase_id}}</td>
                                            <td class="nowrap">{{number_format($purchase->qty)}}</td>
                                            <td class="nowrap">{!! date('D d M, Y', strtotime($purchase->created_at)) !!}</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                <div class="pagination">
                                    {!! $purchases->appends(Request::except('purchase-page'))->links() !!}
                                </div>

                            @else
                                <div class="text-center py-5"> No History.</div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
