@csrf
<div class="form-group row">
    <div class="col-md-6 pr-md-0 mb-3">
        <label>Item Code</label>
        <input 
            id="item_code" 
            type="text" 
            class="form-control @error('item_code') is-invalid @enderror" 
            name="item_code" 
            value="{{ isset($medicine->id) ? $medicine->id : old('item_code') }}" 
            required 
            autocomplete="item_code" 
            autofocus 
            placeholder="Item Code"
        />
        @error('item_code')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 mb-3">
        <label>Item Name</label>
        <input 
            id="item_name" 
            type="text" 
            class="form-control @error('item_name') is-invalid @enderror" 
            name="item_name" 
            value="{{ isset($medicine->item_name) ? $medicine->item_name : old('item_name') }}" 
            required 
            autocomplete="item_name" 
            placeholder="Item Name"
        />
        @error('item_name')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-12 mb-3">
        <label>Classification</label>
        <input 
            id="item_classification" 
            type="text" 
            class="form-control @error('item_classification') is-invalid @enderror" 
            name="item_classification"
            value="{{ isset($medicine->item_classification) ? $medicine->item_classification : old('item_classification') }}" 
            required
            autocomplete="item_classification" 
            placeholder="Classification"
        />

        @error('item_classification')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 pr-md-0 mb-3">
        <label>Original Price</label>
        <input 
            id="orig_price" 
            type="number" 
            class="form-control @error('orig_price') is-invalid @enderror" 
            name="orig_price" 
            value="{{ isset($medicine->orig_price) ? $medicine->orig_price : old('orig_price') }}" 
            required 
            autocomplete="orig_price" 
            placeholder="Original Price"
        />
        @error('orig_price')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 mb-3">
        <label>Retail Price</label>
        <input 
            id="retail_price" 
            type="number" 
            class="form-control @error('retail_price') is-invalid @enderror" 
            name="retail_price"
            value="{{ isset($medicine->retail_price) ? $medicine->retail_price : old('retail_price') }}" 
            required
            autocomplete="retail_price" 
            placeholder="Retail Price"
        />

        @error('retail_price')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    @if(Request::routeIs('medicines.edit'))
        <div class="col-md-12 mb-3">
            <label>Total Stocks</label>
            <input 
                id="item_code" 
                type="text" 
                class="form-control" 
                value="{{ isset($medicine->total_qty) ? number_format((int)$medicine->total_qty - (int)$medicine->total_purchase) : '' }}"
                readonly
            />
    </div>
    @endif
</div>
<div class="offset-md-8 col-md-4 px-0">
    <button type="submit" class="btn btn-primary w-100">
        <i class="far fa-save"></i> Save
    </button>
</div>
  