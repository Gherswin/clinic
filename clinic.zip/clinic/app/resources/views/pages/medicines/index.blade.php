@extends('layouts.app')

@section('content')
<div class="container medicines">
    <div class="">
        <div class="form-header mb-4">
            <h1 class="form-title">Medicines</h1>
        </div>
        
        <div class="btns-container mb-4">
            <a href="{{route('medicines.create')}}" class="btn btn-primary w-100 max-w-200">New Medicine</a>
        </div>

        <div class="filters mb-4">
            <form method="get" action="" class="row">
                <div class="col-lg-3 col-md-4 pr-md-0 mb-lg-0 mb-3">
                    <input type="text" name="item_code" value="{{$request->item_code}}" class="form-control" placeholder="Item Code" autofocus />
                </div>
                <div class="col-lg-3 col-md-4 pr-lg-0 mb-lg-0 mb-3">
                    <input type="text" name="item_name" value="{{$request->item_name}}" class="form-control" placeholder="Item Name" />
                </div>
                <div class="col-lg-4 col-md-4 pr-lg-0 mb-lg-0 mb-3">
                    <input type="text" name="item_classification" value="{{$request->item_classification}}" class="form-control" placeholder="Classification" />
                </div>
                <div class="col-lg-2 col-md-12">
                    <button type="submit" class="btn btn-secondary w-100">
                        Search
                    </button>
                </div>
            </form>
        </div>
        <div class="records">
            @if(session('success'))
                <div class="alert alert-success block">
                    <b><span class="oi oi-info"></span></b> {!! session('success') !!}
                </div>
            @endif
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Code</th>
                            <th scope="col">Item name</th>
                            <th scope="col">Classification</th>
                            <th scope="col">Orig Price</th>
                            <th scope="col">Retail Price</th>
                            <th scope="col">Stocks</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        @if($medicines) 
                            @foreach($medicines as $medicine) 
                                <tr>
                                    <th scope="row">{{$medicine->item_code}}</th>
                                    <td class="nowrap">{{$medicine->item_name}}</td>
                                    <td class="">{{$medicine->item_classification}}</td>
                                    <td class="nowrap">Php. {{number_format($medicine->orig_price, 2) }}</td>
                                    <td class="nowrap">Php. {{ number_format($medicine->retail_price, 2) }}</td>
                                    <td class="nowrap">
                                        {{ number_format((int)$medicine->total_qty - (int)$medicine->total_purchase) }}
                                    </td>
                                    <td class="text-center" style="width: 130px">
                                        <div class="nowrap">
                                            <a href="{{ route('medicines.edit', $medicine->id) }}" class="btn btn-primary btn-sm min-w-50" title="Edit"><i class="far fa-edit"></i></a>
                                            <button type="button" class="btn btn-secondary btn-sm min-w-50" title="Delete" data-toggle="modal" data-target="#delete-{{ $medicine->id }}">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>

                                        <!-- Modal -->
                                        <div class="modal fade" id="delete-{{ $medicine->id }}" tabindex="-1" aria-labelledby="delete-{{ $medicine->id }}-Label" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <form method="POST" action="{{ route('medicines.destroy', $medicine->id)}}" class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="delete-{{ $medicine->id }}-Label">Delete Record</h5>
                                                        <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                            <i class="fas fa-times"></i>
                                                        </a>
                                                    </div>
                                                    <div class="modal-body">
                                                        @csrf
                                                        @method('DELETE')
                                                        <input type="hidden" name="id" value="{{ $medicine->id }}">
                                                        <div class="text-center mb-3">
                                                            <i class="far fa-question-circle text-primary" style="font-size: 60px;line-height: 1em;"></i>
                                                        </div>
                                                        <div class="max-w-400 m-auto">
                                                            Are you sure you want to permanetly delete the record of <strong>{{$medicine->item_code}} - {{ $medicine->item_name}}</strong>?
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-danger">Delete</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
            <div class="pagination">
                {!! $medicines->appends(Request::except('page'))->links() !!}
            </div>
        </div>
    </div>
</div>
@endsection
