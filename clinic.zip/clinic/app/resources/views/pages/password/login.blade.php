@extends('layouts.login')

@section('content')
<div class="card">
    <div class="card-body">
        @if( count($errors) > 0 )
            @foreach($errors->all() as $error)
                <div class="alert alert-danger">
                    {{ $error }}
                </div>
            @endforeach
        @endif
        @if(session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif
        <form action="/login/post" method="POST">
            @csrf
            <input type="hidden" name="redirect" value="{!! $redirect !!}">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" class="form-control form-control-lg" placeholder="Username">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control form-control-lg" placeholder="Password">
            </div>
            <div>
                <button type="submit" class="btn btn-primary btn-lg btn-block">Login</button>
            </div>
            <div class="text-center mt-4">
                <a href="{{ route('password.update') }}" class="color-primary">Lost your password?</a>
            </div>
        </form>
    </div>
</div>
@endsection
