@extends('layouts.app')

@section('content')
<div class="container patients">
    <div class="row">
        <div class="form-header offset-md-2 col-md-8 mb-3 px-0">
            <h1 class="form-title">New Client Information</h1>
        </div>
        
        <div class="form row d-flex justify-content-center w-100">
            <div class="col-lg-8 px-0">
                <div class="alert alert-info">
                    <b><span class="oi oi-info"></span></b> 
                    When manually creating a patient account, kindly remind them to reset their password using the 'Forgot Password' 
                    feature for secure and effortless access to their account.
                </div>
            </div>
            <form method="POST" action="{{ route('patients.store') }}" class="col-lg-8 bg-white p-lg-5 py-3 border border-secondary-300">
                @include('pages.patients.form')
            </form>
        </div>
    </div>
</div>
@endsection
