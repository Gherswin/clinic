@csrf
<div class="form-group row">
    <div class="col-md-6 pr-md-0 mb-3">
        <label for="name">First Name</label>
        <input 
            id="name" 
            type="text" 
            class="form-control @error('firstname') is-invalid @enderror" 
            name="firstname" 
            value="{{ isset($patient->firstname) ? $patient->firstname : old('firstname') }}" 
            required 
            autocomplete="firstname" 
            autofocus 
            placeholder="First Name"
        />
        @error('firstname')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 mb-3">
        <label for="lastname">Last Name</label>
        <input 
            id="lastname" 
            type="text" 
            class="form-control @error('lastname') is-invalid @enderror" 
            name="lastname"
            value="{{ isset($patient->lastname) ? $patient->lastname : old('lastname') }}" 
            required
            autocomplete="lastname" 
            placeholder="Last Name"
        />

        @error('lastname')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 pr-md-0 mb-3">
        <label for="email">Email</label>
        <input 
            id="email" 
            type="email" 
            class="form-control @error('email') is-invalid @enderror" 
            name="email" 
            value="{{ isset($patient->email) ? $patient->email : old('email') }}" 
            required 
            autocomplete="email" 
            autofocus 
            placeholder="Email"
        />
        @error('email')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 mb-3">
        <label for="contact_no">Phone</label>
        <input 
            id="contact_no" 
            type="text" 
            class="form-control @error('contact_no') is-invalid @enderror" 
            name="contact_no"
            value="{{ isset($patient->contact_no) ? $patient->contact_no : old('contact_no') }}" 
            required
            autocomplete="contact_no" 
            placeholder="Phone"
        />

        @error('contact_no')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-12 mb-3">
        <label for="address">Address</label>
        <input 
            id="address" 
            type="text" 
            class="form-control @error('address') is-invalid @enderror" 
            name="address"
            value="{{ isset($patient->address) ? $patient->address : old('address') }}" 
            required
            autocomplete="address" 
            placeholder="Address"
        />

        @error('address')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
</div>
<div class="offset-md-8 col-md-4 px-0">
    <button type="submit" class="btn btn-primary w-100">
        <i class="far fa-save"></i> Save
    </button>
</div>
  