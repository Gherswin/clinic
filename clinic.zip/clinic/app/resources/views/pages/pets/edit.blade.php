@extends('layouts.app')

@section('content')
<div class="container-fluid pets">
    <div class="row">
        <div class="form-header col-md-12 mb-3 px-0">
            <h1 class="form-title">Pet Information</h1>
        </div>
        
        @if(session('success'))
        <div class="col-md-12 mb-3 px-0">
            <div class="alert alert-success block">
                <b><span class="oi oi-info"></span></b> {!! session('success') !!}
            </div>
        </div>
        @endif
        
        <div class="col-lg-5 pl-lg-0">
            <form method="POST" action="{{ route('pets.update', $pet->id) }}" class="bg-white px-3 py-5 border border-secondary-300">
                @method('PUT')
                @include('pages.pets.form')
            </form>
        </div>

        <div class="col-lg-7 mt-lg-0 mt-3 pr-lg-0">
            <div class="accordion px-0" id="reservation">
                <div class="card">
                    <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="headingOne">
                        <button 
                            class="btn text-light" 
                            type="button" 
                            data-toggle="collapse" 
                            data-target="#appointment-history" 
                            aria-expanded="true" 
                            aria-controls="collapseOne"
                            style="letter-spacing: 1px;"
                            >
                            <strong>APPOINTMENT HISTORY</strong>
                        </button>
                        {{-- <button type="button" id="btn-print-all" class="btn btn-secondary btn-small px-4">Print All</button> --}}
                    </div>
              
                    <div id="appointment-history" class="collapse show" aria-labelledby="headingOne" data-parent="#reservation">
                        <div class="card-body table-responsive">
                            @if(count($appointments))
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col"> Date</th>
                                        <th scope="col">Time</th>
                                        <th scope="col">Status</th>
                                        <th scope="col"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($appointments as $appointment) 
                                    <tr id="row-{{ $appointment->id }}">
                                        <td scope="row">{{$appointment->id}}</td>
                                        <td class="nowrap">{{$appointment->appointment_date}}</td>
                                        <td class="nowrap">{!! date('h:i a', strtotime($appointment->appointment_time)) !!}</td>
                                        <td class="nowrap">
                                            <span class="{!! $appointment->status == 'approved' ? 'text-success' : '' !!} {!! $appointment->status == 'cancelled' ? 'text-danger' : '' !!}">
                                                {{$appointment->status}}
                                            </span>
                                        </td>
                                        <td class="text-center" style="width: 130px">
                                            <div class="nowrap">
                                                <a href="{{ route('appointments.edit', $appointment->id) }}" class="btn btn-primary btn-sm min-w-50" title="View Appointment">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <button type="button" class="btn btn-primary btn-sm min-w-50" title="View Doctor's Note" data-toggle="modal" data-target="#findings-{{ $appointment->id }}">
                                                    <i class="fas fa-notes-medical"></i>
                                                </button>
                                                <button type="button" class="btn btn-secondary btn-sm min-w-50" title="Delete Appointment" data-toggle="modal" data-target="#delete-{{ $appointment->id }}">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>

                                            <!-- Findings Modal -->
                                            <div class="modal fade" id="findings-{{ $appointment->id }}" tabindex="-1" aria-labelledby="findings-{{ $appointment->id }}-Label" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="findings-{{ $appointment->id }}-Label">Doctor's Note</h5>
                                                            <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                                <i class="fas fa-times"></i>
                                                            </a>
                                                        </div>
                                                        <div class="modal-body">
                                                            <textarea class="form-control" style="min-height:250px" readonly>{{$appointment->findings}}</textarea>
                                                            {{-- <div class="offset-md-8 col-md-4 mt-4 px-0">
                                                                <a href="#" class="btn btn-secondary w-100 btn-print" data-parent="#row-{{ $appointment->id }}">Print</a>
                                                            </div> --}}
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
    
                                            <!-- Delete Modal -->
                                            <div class="modal fade" id="delete-{{ $appointment->id }}" tabindex="-1" aria-labelledby="delete-{{ $appointment->id }}-Label" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <form method="POST" action="{{ route('appointments.destroy', $appointment->id)}}" class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="delete-{{ $appointment->id }}-Label">Delete Record</h5>
                                                            <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                                <i class="fas fa-times"></i>
                                                            </a>
                                                        </div>
                                                        <div class="modal-body">
                                                            @csrf
                                                            @method('DELETE')
                                                            <input type="hidden" name="id" value="{{ $appointment->id }}">
                                                            <div class="text-center mb-3">
                                                                <i class="far fa-question-circle text-primary" style="font-size: 60px;line-height: 1em;"></i>
                                                            </div>
                                                            <div class="max-w-400 m-auto">
                                                                Are you sure you want to permanetly delete the appointment record for <strong>{{$pet->name}} {{ $pet->species}}</strong>?
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-danger">Delete</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            @else
                                <div class="text-center py-5"> No Appointment found.</div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<iframe name="print_frame" width="0" height="0" frameborder="0" src="about:blank"></iframe>
@endsection

@section('footer_script')
<script src="{{ asset('js/pets.js') }}" defer></script>
@endsection