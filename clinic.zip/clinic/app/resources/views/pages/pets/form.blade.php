@csrf
<div class="form-group row">
    <div class="col-md-12 mb-3">
        <label for="patient_id">Pet Owner</label>
        <select id="patient_id" name="patient_id" class="form-control @error('patient_id') is-invalid @enderror" autofocus>
            <option value="">--Select--</option>
            @if(count($patients))
                @foreach($patients as $patient)
                    <option value="{{ $patient->id }}" {!! ( (isset($request) && $request->patient_id == $patient->id) || (isset($pet) && $patient->id == $pet->patient_id) ? 'selected' : '') !!}>{{ $patient->firstname }} {{ $patient->lastname }}</option>
                @endforeach
            @endif
        </select>

        @error('patient_id')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-12 mb-3">
        <label for="name">Pet Name</label>
        <input 
            id="name" 
            type="text" 
            class="form-control @error('name') is-invalid @enderror" 
            name="name" 
            value="{{ isset($pet->name) ? $pet->name : old('name') }}" 
            required 
            autocomplete="name" 
            placeholder="Pet Name"
        />

        @error('name')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 pr-md-0 mb-3">
        <label for="species">Species</label>
        <input 
            id="species" 
            type="text" 
            class="form-control @error('species') is-invalid @enderror" 
            name="species" 
            value="{{ isset($pet->species) ? $pet->species : old('species') }}" 
            required 
            autocomplete="species" 
            placeholder="Species"
        />
        @error('species')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 mb-3">
        <label for="breed">Breed</label>
        <input 
            id="breed" 
            type="text" 
            class="form-control @error('breed') is-invalid @enderror" 
            name="breed"
            value="{{ isset($pet->breed) ? $pet->breed : old('breed') }}" 
            required
            autocomplete="breed" 
            placeholder="Breed"
        />

        @error('breed')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 pr-md-0 mb-3">
        <label for="gender">Gender</label>
        <select id="gender" name="gender" class="form-control @error('gender') is-invalid @enderror" autofocus>
            <option value="male" selected>Male</option>
            <option value="female">Female</option>
        </select>

        @error('gender')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 mb-3">
        <label for="color">Color</label>
        <input 
            id="color" 
            type="text" 
            class="form-control @error('color') is-invalid @enderror" 
            name="color"
            value="{{ isset($pet->color) ? $pet->color : old('color') }}" 
            autocomplete="color" 
            placeholder="Color"
        />

        @error('color')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 pr-md-0 mb-3">
        <label for="weight">Weight</label>
        <input 
            id="weight" 
            type="text" 
            class="form-control @error('weight') is-invalid @enderror" 
            name="weight"
            value="{{ isset($pet->weight) ? $pet->weight : old('weight') }}" 
            autocomplete="weight" 
            placeholder="Weight"
        />

        @error('weight')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 mb-3">
        <label for="brithdate">Birth Date</label>
        <input 
            id="birthdate" 
            type="date" 
            class="form-control @error('brithdate') is-invalid @enderror" 
            name="birthdate"
            value="{{ isset($pet->birthdate) ? $pet->birthdate : old('birthdate') }}" 
            autocomplete="birthdate" 
            placeholder="Birthdate"
        />

        @error('birthdate')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
</div>
<div class="offset-md-8 col-md-4 px-0">
    <button type="submit" class="btn btn-primary w-100">
        <i class="far fa-save"></i> Save
    </button>
</div>
  