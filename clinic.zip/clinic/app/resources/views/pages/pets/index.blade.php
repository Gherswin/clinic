@extends('layouts.app')

@section('content')
<div class="container pets">
    <div class="">
        <div class="form-header mb-4">
            <h1 class="form-title">Pets</h1>
        </div>
        
        <div class="btns-container mb-4">
            <a href="{{route('pets.create')}}" class="btn btn-primary w-100 max-w-200">New Pet</a>
        </div>

        <div class="filters mb-4">
            <form method="get" action="" class="row">
                <div class="col-lg-3 col-md-6 pr-md-0 mb-lg-0 mb-3">
                    <input type="text" name="owner" value="{{$request->owner}}" class="form-control" placeholder="Owner Name" autofocus />
                </div>
                <div class="col-lg-3 col-md-6 pr-lg-0 mb-lg-0 mb-3">
                    <input type="text" name="pet_name" value="{{$request->pet_name}}" class="form-control" placeholder="Pet Name" />
                </div>
                <div class="col-lg-2 col-md-6 pr-lg-0 mb-lg-0 mb-3">
                    <input type="text" name="species" value="{{$request->species}}" class="form-control" placeholder="Species" />
                </div>
                <div class="col-lg-2 col-md-6 pr-lg-0 mb-lg-0 mb-3">
                    <input type="text" name="breed" value="{{$request->breed}}" class="form-control" placeholder="Breed" />
                </div>
                <div class="col-lg-2 col-md-12">
                    <button type="submit" class="btn btn-secondary w-100">
                        Search
                    </button>
                </div>
            </form>
        </div>
        <div class="records">
            @if(session('success'))
                <div class="alert alert-success block">
                    <b><span class="oi oi-info"></span></b> {!! session('success') !!}
                </div>
            @endif
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Owner</th>
                            <th scope="col">Pet Name</th>
                            <th scope="col">Species</th>
                            <th scope="col">Breed</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        @if($pets) 
                            @foreach($pets as $pet) 
                                <tr>
                                    <th scope="row">{{$pet->pet_id}}</th>
                                    <td class="nowrap">{{$pet->firstname}} {{ $pet->lastname}}</td>
                                    <td class="nowrap">{{$pet->name}}</td>
                                    <td class="nowrap">{{$pet->species}}</td>
                                    <td class="nowrap">{{$pet->breed}}</td>
                                    <td class="text-center" style="width: 130px">
                                        <div class="nowrap">
                                            <a href="{{ route('pets.edit', $pet->pet_id) }}" class="btn btn-primary btn-sm min-w-50" title="View Details"><i class="fas fa-eye"></i></a>
                                            <button type="button" class="btn btn-secondary btn-sm min-w-50" title="Delete" data-toggle="modal" data-target="#delete-{{ $pet->pet_id }}">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>

                                        <!-- Modal -->
                                        <div class="modal fade" id="delete-{{ $pet->pet_id }}" tabindex="-1" aria-labelledby="delete-{{ $pet->pet_id }}-Label" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <form method="POST" action="{{ route('pets.destroy', $pet->pet_id)}}" class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="delete-{{ $pet->pet_id }}-Label">Delete Record</h5>
                                                        <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                            <i class="fas fa-times"></i>
                                                        </a>
                                                    </div>
                                                    <div class="modal-body">
                                                        @csrf
                                                        @method('DELETE')
                                                        <input type="hidden" name="id" value="{{ $pet->pet_id }}">
                                                        <div class="text-center mb-3">
                                                            <i class="far fa-question-circle text-primary" style="font-size: 60px;line-height: 1em;"></i>
                                                        </div>
                                                        <div class="max-w-400 m-auto">
                                                            Are you sure you want to permanetly delete the record of <strong>{{$pet->name}} - {{ $pet->species}}</strong>?
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-danger">Delete</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
            <div class="pagination">
                {!! $pets->appends(Request::except('page'))->links() !!}
            </div>
        </div>
    </div>
</div>
@endsection
