@extends('layouts.app')

@section('content')
<div class="container staffs">
    <div class="">
        <div class="form row d-flex justify-content-center">
            @if(session('success'))
                <div class="col-md-8 mb-2">
                    <div class="alert alert-success block">
                        <b><span class="oi oi-info"></span></b> {!! session('success') !!}
                    </div>
                </div>
            @endif
            <form method="POST" action="{{ route('profile.update') }}" class="col-lg-8 bg-white p-lg-5 py-3 border border-secondary-300 mb-4">
                {{-- @method('PUT') --}}
                @csrf

                <div class="form-group row">
                    <div class="col-md-12 mb-4">
                        <div class="form-header">
                            <h1 class="form-title">Personal Information</h1>
                        </div>
                    </div>
                    
                    <div class="col-md-6 pr-md-0 mb-3">
                        <label for="firstname">First Name</label>
                        <input 
                            id="firstname" 
                            type="text" 
                            class="form-control @error('firstname') is-invalid @enderror" 
                            name="firstname" 
                            value="{{ isset($staff->firstname) ? $staff->firstname : old('firstname') }}" 
                            required 
                            autocomplete="firstname" 
                            autofocus 
                            placeholder="First Name"
                        />
                        @error('firstname')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="lastname">Last Name</label>
                        <input 
                            id="lastname" 
                            type="text" 
                            class="form-control @error('lastname') is-invalid @enderror" 
                            name="lastname"
                            value="{{ isset($staff->lastname) ? $staff->lastname : old('lastname') }}" 
                            required
                            autocomplete="lastname" 
                            placeholder="Last Name"
                        />
                
                        @error('lastname')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="email">Email Address</label>
                        <input 
                            id="email" 
                            type="email" 
                            class="form-control @error('email') is-invalid @enderror" 
                            name="email" 
                            value="{{ isset($staff->email) ? $staff->email : old('email') }}" 
                            required 
                            autocomplete="email" 
                            Placeholder="Email Address"   
                            readonly
                        />
                
                        @error('email')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    {{-- <div class="col-md-12 mb-3">
                        <label for="username">Username</label>
                        <input 
                            id="username" 
                            type="text" 
                            class="form-control @error('username') is-invalid @enderror" 
                            name="username" 
                            value="{{ isset($staff->username) ? $staff->username : old('username') }}" 
                            required 
                            autocomplete="username" 
                            placeholder="Username"
                            readonly
                        />
                
                        @error('username')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div> --}}

                    <div class="col-md-5">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="far fa-save"></i> Update Profile
                        </button>
                    </div>
                </div>
            </form>
            <form method="POST" action="{{ route('profile.update-password') }}" class="col-lg-8 bg-white p-lg-5 py-3 border border-secondary-300">
                @csrf
                <div class="form-group row">
                    <div class="col-md-12 mb-4">
                        <div class="form-header">
                            <h3 class="form-title">Set New Password</h3>
                        </div>
                    </div>

                    <div class="col-md-6 pr-md-0 mb-3">
                        <label for="password">New Password</label>
                        <input 
                            id="password" 
                            type="password" 
                            class="form-control @error('password') is-invalid @enderror" 
                            name="password" 
                            required 
                            autocomplete="new-password" 
                            placeholder="Set New Password"
                        />
                
                        @error('password')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="password-confirm">Confirm New Password</label>
                        <input 
                            id="password-confirm" 
                            type="password" 
                            class="form-control" 
                            name="password_confirmation" 
                            required 
                            autocomplete="new-password" 
                            placeholder="Confirm New Password"
                        />
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="old-password">Confirm Old Password</label>
                        <input 
                            id="old-password" 
                            type="password" 
                            class="form-control @error('old_password') is-invalid @enderror" 
                            name="old_password" 
                            required 
                            autocomplete="old-password" 
                            placeholder="Confirm Old Password"
                        />

                        @error('old_password')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="col-md-5">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="far fa-save"></i> Change Password
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
