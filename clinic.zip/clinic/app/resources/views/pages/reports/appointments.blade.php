@extends('layouts.app')

@section('content')
<div class="container products">
    <div class="">
        <div class="header mb-4 text-center">
            <h1 class="form-title">Appointments Report</h1>
        </div>
        <div class="records">
            <div class="filters mb-4">
                <form method="get" action="" class="row">
                    <div class="col-lg-9 col-md-6 pr-md-0 mb-lg-0 mb-3">
                        <select class="form-control" name="month_back">
                            <option value="12" {{ ($request->month_back == 12) ? "selected" : '' }}>Last 12 months</option>
                            <option value="11" {{ ($request->month_back == 11)? "selected" : '' }}>Last 11 months</option>
                            <option value="10"{{ ($request->month_back == 10)? "selected" : '' }}>Last 10 months</option>
                            <option value="9" {{ ($request->month_back == 9)? "selected" : '' }}>Last 9 months</option>
                            <option value="8" {{ ($request->month_back == 8)? "selected" : '' }}>Last 8 months</option>
                            <option value="7" {{ ($request->month_back == 7)? "selected" : '' }}>Last 7 months</option>
                            <option value="6" {{ ($request->month_back == 6 || empty($request->month_back))? "selected" : '' }}>Last 6 months</option>
                            <option value="5" {{ ($request->month_back == 5)? "selected" : '' }}>Last 5 months</option>
                            <option value="4" {{ ($request->month_back == 4)? "selected" : '' }}>Last 4 months</option>
                            <option value="3" {{ ($request->month_back == 3)? "selected" : '' }}>Last 3 months</option>
                        </select>
                    </div>
                    <div class="col-lg-3 col-md-12">
                        <button type="submit" class="btn btn-secondary w-100">
                            Submit
                        </button>
                    </div>
                </form>
            </div>
            <canvas id="appointmentsChart" style="width:100%;height:400px"></canvas>
        </div>
    </div>
</div>
@endsection

@section('footer_script')
    <script>
        var webInfo = {
            baseUrl: '{!! URL::to('/') !!}',
            currentUser:  {
                id: '{!! auth()->user()->id !!}',
                firstname: '{!! auth()->user()->firstname !!}',
                lastname: '{!! auth()->user()->lastname !!}',
            },
            data: {!! json_encode($report) !!}
        } 
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
    <script src="{{ asset('js/appointments-report.js') }}" defer></script>
@endsection
