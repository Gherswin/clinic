@extends('layouts.app')

@section('content')
<div class="container staffs">
    <div class="row">
        <div class="form-header offset-md-2 col-md-8 mb-3 px-0">
            <h1 class="form-title">Staff Information</h1>
        </div>
        
        <div class="form row d-flex justify-content-center">
            <form method="POST" action="{{ route('staffs.update', $staff->id) }}" class="col-lg-8 bg-white p-lg-5 py-3 border border-secondary-300">
                @method('PUT')
                @include('pages.staffs.form')
            </form>
        </div>
    </div>
</div>
@endsection
