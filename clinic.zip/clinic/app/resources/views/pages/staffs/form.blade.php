@csrf
<div class="form-group row">
    <div class="col-md-6 pr-md-0 mb-3">
        <input 
            id="name" 
            type="text" 
            class="form-control @error('firstname') is-invalid @enderror" 
            name="firstname" 
            value="{{ isset($staff->firstname) ? $staff->firstname : old('firstname') }}" 
            required 
            autocomplete="firstname" 
            autofocus 
            placeholder="First Name"
        />
        @error('firstname')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 mb-3">
        <input 
            id="lastname" 
            type="text" 
            class="form-control @error('lastname') is-invalid @enderror" 
            name="lastname"
            value="{{ isset($staff->lastname) ? $staff->lastname : old('lastname') }}" 
            required
            autocomplete="lastname" 
            placeholder="Last Name"
        />

        @error('lastname')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 pr-md-0 mb-3">
        <select name="role" class="form-control" @error('role') is-invalid @enderror">
            @if(Auth::user()->role == 'admin')
            <option value="admin" {{ (isset($staff->role) && $staff->role == 'admin') || old('role') == 'admin' ? 'selected' : '' }}>Super Administrator</option>
            @endif
            <option value="clinic-admin" {{ (isset($staff->role) && $staff->role == 'clinic-admin') || old('role') == 'clinic-admin' ? 'selected' : '' }}>Administrator</option>
            <option value="clinic-staff" {{ (isset($staff->role) && $staff->role == 'clinic-staff') || old('role') == 'clinic-staff' ? 'selected' : '' }}>Staff</option>
        </select>
        @error('role')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 mb-3">
        <select name="status" class="form-control">
            <option value="active" {{ (isset($staff->status) && $staff->status == 'active') || old('status') == 'active' ? 'selected' : '' }}>Active</option>
            <option value="blocked" {{ (isset($staff->status) && $staff->status == 'blocked') || old('status') == 'blocked' ? 'selected' : '' }}>Blocked</option>
        </select>
    </div>
    <div class="col-md-6 pr-md-0 mb-3">
        <input 
            id="email" 
            type="email" 
            class="form-control @error('email') is-invalid @enderror" 
            name="email" 
            value="{{ isset($staff->email) ? $staff->email : old('email') }}" 
            required 
            autocomplete="email" 
            Placeholder="Email Address"   
            {{ Request::routeIs('staffs.edit') ? 'readonly' : '' }}
        />

        @error('email')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 mb-3">
        <input 
            id="username" 
            type="text" 
            class="form-control @error('username') is-invalid @enderror" 
            name="username" 
            value="{{ isset($staff->username) ? $staff->username : old('username') }}" 
            required 
            autocomplete="username" 
            placeholder="Username"
            {{ Request::routeIs('staffs.edit') ? 'readonly' : '' }}
        />

        @error('username')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    @if(!Request::routeIs('staffs.edit'))
    <div class="col-md-6 pr-md-0 mb-3">
        <input 
            id="password" 
            type="password" 
            class="form-control @error('password') is-invalid @enderror" 
            name="password" 
            required 
            autocomplete="new-password" 
            placeholder="Password"
        />

        @error('password')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>
    <div class="col-md-6 mb-3">
        <input 
            id="password-confirm" 
            type="password" 
            class="form-control" 
            name="password_confirmation" 
            required 
            autocomplete="new-password" 
            placeholder="Confirm Password"
        />
    </div>
    @endif
</div>
<div>
    <button type="submit" class="btn btn-primary btn-lg w-100">
        <i class="far fa-save"></i> Save
    </button>
</div>
  