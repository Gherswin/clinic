@extends('layouts.app')

@section('content')
<div class="container staffs">
    <div class="">
        <div class="form-header mb-4">
            <h1 class="form-title">Staffs</h1>
        </div>
        
        <div class="btns-container mb-4">
            <a href="{{route('staffs.create')}}" class="btn btn-primary w-100 max-w-200">New Staff</a>
        </div>

        <div class="filters mb-4">
            <form method="get" action="" class="row">
                <div class="col-lg-3 col-md-6 pr-md-0 mb-lg-0 mb-3">
                    <input type="text" name="firstname" value="{{$request->firstname}}" class="form-control" placeholder="First Name" autofocus />
                </div>
                <div class="col-lg-3 col-md-6 pr-lg-0 mb-lg-0 mb-3">
                    <input type="text" name="lastname" value="{{$request->lastname}}" class="form-control" placeholder="Last Name" />
                </div>
                <div class="col-lg-2 col-md-6 pr-md-0 mb-lg-0 mb-3">
                    <select name="role" class="form-control">
                        <option value=""}>All</option>
                        @if(Auth::user()->role == 'admin')
                        <option value="admin" {{($request->role == 'admin') ? 'selected' : ''}}>Super Administrator</option>
                        @endif
                        <option value="clinic-admin" {{($request->role == 'clinic-admin') ? 'selected' : ''}}>Administrator</option>
                        <option value="clinic-staff" {{($request->role == 'clinic-staff') ? 'selected' : ''}}>Staff</option>
                    </select>
                </div>
                <div class="col-lg-2 col-md-6 pr-lg-0 mb-lg-0 mb-3">
                    <select name="status" class="form-control">
                        <option value=""}>All</option>
                        <option value="active" {{($request->status == 'active') ? 'selected' : ''}}>Active</option>
                        <option value="blocked" {{($request->status == 'blocked') ? 'selected' : ''}}>Blocked</option>
                    </select>
                </div>
                <div class="col-lg-2 col-md-12">
                    <button type="submit" class="btn btn-secondary w-100">
                        Search
                    </button>
                </div>
            </form>
        </div>
        <div class="records">
            @if(session('success'))
                <div class="alert alert-success block">
                    <b><span class="oi oi-info"></span></b> {!! session('success') !!}
                </div>
            @endif
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Username</th>
                            <th scope="col">Role</th>
                            <th scope="col">Status</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        @if($staffs) 
                            @foreach($staffs as $staff) 
                                <tr>
                                    <th scope="row">{{$staff->id}}</th>
                                    <td class="nowrap">{{$staff->firstname}} {{$staff->lastname}}</td>
                                    <td class="nowrap">{{$staff->username}}</td>
                                    <td class="nowrap">
                                        @if ($staff->role == 'clinic-admin')
                                            Administrator
                                        @elseif($staff->role == 'clinic-staff')
                                            Staff
                                        @endif
                                    </td>
                                    <td class="nowrap">
                                        <span class="{!! $staff->status == 'active' ? 'text-success' : '' !!} {!! $staff->status == 'blocked' ? 'text-danger' : '' !!}">
                                            {{$staff->status}}
                                        </span>
                                    </td>
                                    <td class="text-center" style="width: 130px">
                                        <div class="nowrap">
                                            <a href="{{ route('staffs.edit', $staff->id) }}" class="btn btn-primary btn-sm min-w-50" title="Edit"><i class="far fa-edit"></i></a>
                                            <button type="button" class="btn btn-secondary btn-sm min-w-50" title="Delete" data-toggle="modal" data-target="#delete-{{ $staff->id }}">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>

                                        <!-- Modal -->
                                        <div class="modal fade" id="delete-{{ $staff->id }}" tabindex="-1" aria-labelledby="delete-{{ $staff->id }}-Label" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <form method="POST" action="{{ route('staffs.destroy', $staff->id)}}" class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="delete-{{ $staff->id }}-Label">Delete Record</h5>
                                                        <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                            <i class="fas fa-times"></i>
                                                        </a>
                                                    </div>
                                                    <div class="modal-body">
                                                        @csrf
                                                        @method('DELETE')
                                                        <input type="hidden" name="id" value="{{ $staff->id }}">
                                                        <div class="text-center mb-3">
                                                            <i class="far fa-question-circle text-primary" style="font-size: 60px;line-height: 1em;"></i>
                                                        </div>
                                                        <div class="max-w-400 m-auto">
                                                            Are you sure you want to permanetly delete the record of <strong>{{$staff->firstname}} {{ $staff->lastname}}</strong>?
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-danger">Delete</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
            <div class="pagination">
                {!! $staffs->appends(Request::except('page'))->links() !!}
            </div>
        </div>
    </div>
</div>
@endsection
