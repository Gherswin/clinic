<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\PetController;
use App\Http\Controllers\MedicineController;
use App\Http\Controllers\StockController;
use App\Http\Controllers\PosController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ClinicController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\RegisterController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('pages.frontend.index');
// })->name('homepage');
Route::get('/', [HomeController::class, 'homepage'])->name('homepage');
Route::get('/thankyou', function () {
    return view('pages.frontend.thankyou');
})->name('thankyou');
Route::get('/privacy-policy', function () {
    return view('pages.frontend.privacy-policy');
})->name('privacy-policy');
Route::get('/terms-and-conditions', function () {
    return view('pages.frontend.terms-conditions');
})->name('terms-and-conditions');
Route::get('/search-clinics', [ClinicController::class, 'getClinics'])->name('clinics');

Route::get('/home', function() {
    return redirect('/dashboard');
});

// Route::get('/login', [LoginController::class, 'loginForm'])->name('login');
Auth::routes();
Route::post('/login/post', [LoginController::class, 'submit'])->name('submit');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');


Route::get('/dashboard', [HomeController::class, 'index'])->name('dashboard');
Route::get('/profile', [ProfileController::class, 'profile'])->name('profile');
Route::post('/profile/update', [ProfileController::class, 'submit'])->name('profile.update');
Route::post('/profile/change-password', [ProfileController::class, 'changePassword'])->name('profile.update-password');
Route::resource('staffs', StaffController::class);
Route::resource('appointments', AppointmentController::class);
Route::post('/appointments/merge', [AppointmentController::class, 'mergeRecord'])->name('appointments.merge');
Route::post('/appointments/make-appointment', [AppointmentController::class, 'makeAppointment'])->name('appointments.makeappointment');
Route::post('/appointments/quick-update', [AppointmentController::class, 'quickUpdate'])->name('appointments.quickupdate');
Route::resource('patients', PatientController::class);
Route::resource('pets', PetController::class);
Route::resource('medicines', MedicineController::class);
Route::resource('stocks', StockController::class);
Route::resource('sales-counter', PosController::class);
Route::resource('clinics', ClinicController::class);
Route::resource('clinicservices', ServiceController::class);

Route::get('/reports/medicines', [ReportController::class, 'productsReport'])->name('reports.products');
Route::get('/reports/appointments', [ReportController::class, 'appointmentsReport'])->name('reports.appointments');
Route::get('/make-an-appointment', [RegisterController::class, 'makeAppointment'])->name('make_appointment.create');
Route::get('/sign-up', [RegisterController::class, 'signUp'])->name('signup.create');
Route::post('/sign-up/store', [RegisterController::class, 'submitSignUp'])->name('signup.store');