

<?php $__env->startSection('content'); ?>
    <!-- Hero -->
    <div id="home" class="hero hero__md section-container d-flex flex-center" style="background-image:url(<?php echo e(asset('images/hero.jpg')); ?>)">
        <div class="container w-100">
            <?php if($clinic->image): ?>
            <div class="clinic-info__imgholder">
                <img 
                    src="<?php echo e($clinic->image ? asset('images/clinics/' . $clinic->image) : asset('images/logo.jpg')); ?>"
                    class="clinic-info__img"
                />
            </div>
            <?php endif; ?>
            <h1 class="text-center text-primary font-weight-bold"><?php echo e($clinic->name); ?></h1>
            <div class="hero__subheading text-center text-primary max-w-500 mx-auto"><?php echo e($clinic->address); ?></div>
            <div class="mt-4 text-center text-uppercase" style="letter-spacing:1.6px">
                <a href="#make-an-appointment" class=" btn btn-secondary btn-extra">Make An Appointment</a>
            </div>
        </div>
    </div>
    <!-- End Hero -->

    <div id="contact" class="about section-container" style="background-color:#fff">
        <div class="container section">
            <h2 class="text-center mb-4 text-primary font-weight-bold">Clinic Information</h2>
            <div class="contact__wrapper offset-md-1 col-md-10">
                <div class="contact__wrapper-inner">
                    <div class="contact__item">
                        <div class="contact__item-icon">
                            <i class="icon fas fa-phone-alt"></i>
                        </div>
                        <div class="contact__item-details">
                            <div class="contact__item-label">Phone:</div>
                            <div class="contact__item-text"><?php echo e($clinic->contact_no); ?></div>
                        </div>
                    </div>

                    <div class="contact__item">
                        <div class="contact__item-icon">
                            <i class="icon fas fa-envelope"></i>
                        </div>
                        <div class="contact__item-details">
                            <div class="contact__item-label">Email:</div>
                            <div class="contact__item-text"><?php echo e($clinic->email); ?></div>
                        </div>
                    </div>
                    
                    <div class="contact__item">
                        <div class="contact__item-icon">
                            <i class="icon fas fa-map-marked"></i>
                        </div>
                        <div class="contact__item-details">
                            <div class="contact__item-label">Address:</div>
                            <div class="contact__item-text"><?php echo e($clinic->address); ?></div>
                        </div>
                    </div>

                    <div class="contact__item contact__item__hours">
                        <div class="contact__item-icon">
                            <i class="icon fas fa-clock"></i>
                        </div>
                        <div class="contact__item-details">
                            <div class="contact__item-label">Operating Hours:</div>
                            <div class="contact__item-text">
                                <?php $__currentLoopData = unserialize($clinic->operating_hours); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="clinic-card__hours__item">
                                        <?php if($time['day'] === 'mon'): ?>
                                            Monday
                                        <?php elseif($time['day'] === 'tue'): ?>
                                            Tuesday
                                        <?php elseif($time['day'] === 'wed'): ?>
                                            Wednesday
                                        <?php elseif($time['day'] === 'thu'): ?>
                                            Thursday
                                        <?php elseif($time['day'] === 'fri'): ?>
                                            Friday
                                        <?php elseif($time['day'] === 'sat'): ?>
                                            Saturday
                                        <?php elseif($time['day'] === 'sun'): ?>
                                            Sunday
                                        <?php endif; ?>
                                        <?php echo e(date("h:i a", strtotime($time['timestart']))); ?> - <?php echo e(date("h:i a", strtotime($time['timeend']))); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div> 

    <?php if(count($services)): ?>
        <div id="services" class="about section-container bg-primary">
            <div class="container section">
                <h2 class="text-center mb-4 text-white font-weight-bold">Our Services</h2>
                <div class="d-flex flex-wrap justify-content-center offset-md-1 col-md-10">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="service-card">
                            <div class="service-card__heading">
                                <div class="service-card__title"><?php echo e($service->title); ?></div>
                                <div class="service-card__price">
                                    Php. <?php echo e(number_format($service->price, 2)); ?>

                                </div>
                            </div>
                            <div class="service-card__body">
                                <?php echo e($service->description); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div> 
    <?php endif; ?> 

    <div id="make-an-appointment" class="appointment section-container" style="background-color:#f9ecd9">
        <div class="container section">
            <h2 class="text-center mb-5 text-primary font-weight-bold">Make an Appointment <br class="d-none d-md-block"> at <?php echo e($clinic->name); ?></h2>

            <div id="appointment__create" class="form row d-flex justify-content-center w-100">
                <form method="POST" action="<?php echo e(route('appointments.makeappointment')); ?>" class="appointment-form col-md-8">
                    <?php echo csrf_field(); ?>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success block">
                            <b><span class="oi oi-info"></span></b> <?php echo session('success'); ?>

                        </div>
                    <?php endif; ?>
                    <div class="form-group row">
                        <input type="hidden" name="clinic_id" value="<?php echo e($clinic->id); ?>">
                        <input type="hidden" name="id" v-model="formData.id">
                        <div class="col-md-6 pr-md-0 mb-3">
                            <label for="firstname" class="mb-0">First Name</label>
                            <input 
                                id="firstname" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="firstname" 
                                value="<?php echo e(old('firstname')); ?>" 
                                required 
                                autocomplete="firstname" 
                                placeholder="First Name"
                            />
                            <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="lastname" class="mb-0">Last Name</label>
                            <input 
                                id="lastname" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="lastname"
                                value="<?php echo e(old('lastname')); ?>" 
                                required
                                autocomplete="lastname" 
                                placeholder="Last Name"
                            />
                    
                            <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 pr-md-0 mb-3">
                            <label for="email" class="mb-0">Email</label>
                            <input 
                                id="email" 
                                type="email" 
                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="email" 
                                value="<?php echo e(old('email')); ?>" 
                                required 
                                autocomplete="email" 
                                placeholder="Email Address"
                            />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="phone" class="mb-0">Phone</label>
                            <input 
                                id="phone" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="phone"
                                value="<?php echo e(old('phone')); ?>" 
                                required
                                autocomplete="phone" 
                                placeholder="Phone"
                            />
                    
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="address" class="mb-0">Address</label>
                            <input 
                                id="address" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="address"
                                value="<?php echo e(old('address')); ?>" 
                                autocomplete="address" 
                                placeholder="Address"
                            />
                    
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 pr-md-0 mb-3">
                            <label for="appointment_date" class="mb-0">Appointment Date</label>
                            <input 
                                id="appointment_date" 
                                type="date" 
                                class="form-control <?php $__errorArgs = ['appointment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="appointment_date" 
                                v-model="formData.appointmentDate"
                                value="<?php echo e(isset($appointment->appointment_date) ? $appointment->appointment_date : old('appointment_date')); ?>" 
                                required 
                                autocomplete="appointment_date" 
                                placeholder="Appointment Date"
                            />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="appointment_time" class="mb-0">Appointment Time</label>
                            <input 
                                id="appointment_time" 
                                type="time" 
                                class="form-control <?php $__errorArgs = ['appointment_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="appointment_time"
                                v-model="formData.appointmentTime"
                                value="<?php echo e(isset($appointment->appointment_time) ? $appointment->appointment_time : old('appointment_time')); ?>" 
                                required
                                autocomplete="appointment_time" 
                                placeholder="Appointment Time"
                            />
                    
                            <?php $__errorArgs = ['appointment_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if(count($services)): ?>
                        <div class="col-md-12 mb-3">
                            <label for="service_id" class="mb-0">About this appointment all about</label>
                            <select id="service_id" name="service_id" class="form-control">
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($service->id); ?>"><?php echo e($service->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    
                            <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php endif; ?>
                        <div class="col-md-12 mb-3">
                            <label for="message" class="mb-0">Message</label>
                            <textarea 
                                id="message"
                                name="message"
                                v-model="formData.message"
                                placeholder="Message"
                                style="min-height:200px"
                                class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                    
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                            <input id="iagree" type="checkbox" value="i-agree" checked required>
                            <label for="iagree">I agree to the <a href="/terms-and-conditions" target="_blank">Terms and Conditions</a> and <a href="/privacy-policy" target="blank">Privacy Policy</a></label>
                        </div>
                    </div>
    
                    <div style="col-md-12 p-md-0">
                        <button type="submit" class="btn btn-primary w-100" style="max-width: 230px">
                                Make An Appointment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinic\app\resources\views/pages/clinics/show.blade.php ENDPATH**/ ?>