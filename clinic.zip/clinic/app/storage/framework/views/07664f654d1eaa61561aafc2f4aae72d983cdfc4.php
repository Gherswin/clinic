

<?php $__env->startSection('content'); ?>
<div class="container staffs">
    <div class="">
        <div class="form-header mb-4">
            <h1 class="form-title">Staffs</h1>
        </div>
        
        <div class="btns-container mb-4">
            <a href="<?php echo e(route('staffs.create')); ?>" class="btn btn-primary w-100 max-w-200">New Staff</a>
        </div>

        <div class="filters mb-4">
            <form method="get" action="" class="row">
                <div class="col-lg-3 col-md-6 pr-md-0 mb-lg-0 mb-3">
                    <input type="text" name="firstname" value="<?php echo e($request->firstname); ?>" class="form-control" placeholder="First Name" autofocus />
                </div>
                <div class="col-lg-3 col-md-6 pr-lg-0 mb-lg-0 mb-3">
                    <input type="text" name="lastname" value="<?php echo e($request->lastname); ?>" class="form-control" placeholder="Last Name" />
                </div>
                <div class="col-lg-2 col-md-6 pr-md-0 mb-lg-0 mb-3">
                    <select name="role" class="form-control">
                        <option value=""}>All</option>
                        <option value="admin" <?php echo e(($request->role == 'admin') ? 'selected' : ''); ?>>Administrator</option>
                        <option value="staff" <?php echo e(($request->role == 'staff') ? 'selected' : ''); ?>>Staff</option>
                    </select>
                </div>
                <div class="col-lg-2 col-md-6 pr-lg-0 mb-lg-0 mb-3">
                    <select name="status" class="form-control">
                        <option value=""}>All</option>
                        <option value="active" <?php echo e(($request->status == 'active') ? 'selected' : ''); ?>>Active</option>
                        <option value="blocked" <?php echo e(($request->status == 'blocked') ? 'selected' : ''); ?>>Blocked</option>
                    </select>
                </div>
                <div class="col-lg-2 col-md-12">
                    <button type="submit" class="btn btn-secondary w-100">
                        Search
                    </button>
                </div>
            </form>
        </div>
        <div class="records">
            <?php if(session('success')): ?>
                <div class="alert alert-success block">
                    <b><span class="oi oi-info"></span></b> <?php echo session('success'); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Username</th>
                            <th scope="col">Role</th>
                            <th scope="col">Status</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($staffs): ?> 
                            <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr>
                                    <th scope="row"><?php echo e($staff->id); ?></th>
                                    <td class="nowrap"><?php echo e($staff->firstname); ?> <?php echo e($staff->lastname); ?></td>
                                    <td class="nowrap"><?php echo e($staff->username); ?></td>
                                    <td class="nowrap"><?php echo e($staff->role); ?></td>
                                    <td class="nowrap">
                                        <span class="<?php echo $staff->status == 'active' ? 'text-success' : ''; ?> <?php echo $staff->status == 'blocked' ? 'text-danger' : ''; ?>">
                                            <?php echo e($staff->status); ?>

                                        </span>
                                    </td>
                                    <td class="text-center" style="width: 130px">
                                        <div class="nowrap">
                                            <a href="<?php echo e(route('staffs.edit', $staff->id)); ?>" class="btn btn-primary btn-sm min-w-50" title="Edit"><i class="far fa-edit"></i></a>
                                            <button type="button" class="btn btn-secondary btn-sm min-w-50" title="Delete" data-toggle="modal" data-target="#delete-<?php echo e($staff->id); ?>">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>

                                        <!-- Modal -->
                                        <div class="modal fade" id="delete-<?php echo e($staff->id); ?>" tabindex="-1" aria-labelledby="delete-<?php echo e($staff->id); ?>-Label" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <form method="POST" action="<?php echo e(route('staffs.destroy', $staff->id)); ?>" class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="delete-<?php echo e($staff->id); ?>-Label">Delete Record</h5>
                                                        <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                            <i class="fas fa-times"></i>
                                                        </a>
                                                    </div>
                                                    <div class="modal-body">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <input type="hidden" name="id" value="<?php echo e($staff->id); ?>">
                                                        <div class="text-center mb-3">
                                                            <i class="far fa-question-circle text-primary" style="font-size: 60px;line-height: 1em;"></i>
                                                        </div>
                                                        <div class="max-w-400 m-auto">
                                                            Are you sure you want to permanetly delete the record of <strong><?php echo e($staff->firstname); ?> <?php echo e($staff->lastname); ?></strong>?
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-danger">Delete</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="pagination">
                <?php echo $staffs->appends(Request::except('page'))->links(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinic\app\resources\views/pages/staffs/index.blade.php ENDPATH**/ ?>