

<?php $__env->startSection('content'); ?>
<div id="pos" class="container pos">
    <div class="">
        <div class="form-header mb-4">
            <h1 class="form-title">Sales Counter</h1>
        </div>
        <div class="pos__container">
            <div class="pos__user d-flex align-items-center w-100 max-w-600 justify-content-between mb-4">
                <div class="pos__user-name">
                    <span class="font-weight-bold">Cashier: </span> <?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->lastname); ?>

                </div>
                <div class="pos__user-time">
                    <span class="font-weight-bold">Date/Time: </span> <?php echo date('D d M, Y'); ?> | <span id="date-time" v-html="time.time"></span>
                </div>
            </div>
            <div class="pos__add row mb-5">
                <div class="col-md-4 pr-md-0 mb-md-0 mb-3">
                    <vue-multiselect 
                        class="form-control-multiselect w-100"
                        v-model="formData.patient"
                        placeholder="Select Client"
                        track-by="name"
                        label="name"
                        open-direction="bottom"
                        :options="filteredPatients"
                        :searchable="true"
                        :show-pointer="false"
                        :show-labels="false"
                        :multiple="false"
                        :internal-search="true"
                        :close-on-select="true"
                        :options-limit="700"
                        :max-height="300"
                        :show-no-results="false"
                        @open="getPatients"
                        @search-change="getPatients"
                        @select="populateInfo"
                        />
                    </vue-multiselect>
                </div>
                <div class="pos__add-item col-md-6 pr-md-0 mb-md-0 mb-3">
                    <input 
                        type="text" 
                        name="item_code"
                        class="form-control"
                        placeholder="Enter Product Code or Product Name"
                        accesskey="i"
                        autocomplete="off"
                        v-model="filter.itemCode"
                    />
                    <div class="pos__add-item-suggestion" v-if="show.itemSuggestion">
                        <div class="pos__add-item-suggestion-item disabled" v-if="items.isLoading">
                            <i class="fas fa-spinner loader"></i>
                        </div>
                        <div class="pos__add-item-suggestion-item disabled" v-if="!items.isLoading && !items.data.length">
                            No Record Found
                        </div>
                        <div 
                            class="pos__add-item-suggestion-item" 
                            v-if="!items.isLoading && items.data.length" 
                            v-for="item in items.data" 
                            :key="item.id"
                            @click="addItem(item, filter.qty)"
                            >
                           <span v-html="item.item_code + ' - ' + item.item_name"></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <input 
                        type="number" 
                        name="item_qty"
                        class="form-control mr-sm-3 text-center"
                        value="1"
                        accesskey="q"
                        autocomplete="off"
                        v-model="filter.qty"
                    />
                </div>
                
            </div>
            <div class="pos__details row">
                <div class="col-lg-3 mb-3">
                    <button 
                        class="btn btn-info btn-lg text-light w-100 mb-3"
                        data-toggle="modal" 
                        data-target="#inventory"
                        @click="getInventory()"
                        >
                        Invetory
                    </button>
                    <button 
                        class="btn btn-danger btn-lg w-100" 
                        data-toggle="modal" 
                        data-target="#clear-form"
                        :disabled="!formData.items.length"
                        >
                        Clear All Items
                    </button>

                    <!-- Modal -->
                    <div class="modal fade" id="clear-form" tabindex="-1" aria-labelledby="clear-form-Label" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="clear-form-Label">Delete Record</h5>
                                    <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                                <div class="modal-body">
                                    <div class="text-center mb-3">
                                        <i class="far fa-question-circle text-primary" style="font-size: 60px;line-height: 1em;"></i>
                                    </div>
                                    <div class="max-w-400 m-auto">
                                        Are you sure you want to Clear all items, the data cannot be retreive?
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-danger" data-dismiss="modal" @click="resetFields()">Clear All Items</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">Product Name</th>
                                    <th scope="col" class="nowrap">Qty</th>
                                    <th scope="col" class="nowrap">Price</th>
                                    <th scope="col">Total</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr style="font-size: 12px" v-if="formData.items.length" v-for="(item, index) in formData.items">
                                    <td v-html="item.item_name"></td>
                                    <td v-html="item.qty"></td>
                                    <td v-html="formatNumber(item.price)"></td>
                                    <td v-html="formatNumber(item.total)"></td>
                                    <td><a href="#" class="text-danger" @click.prevent="removeItem(index)">REMOVE</a></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end">
                        <div class="d-flex align-items-center">
                            <span class="font-weight-bold mr-3" style="font-size:20px">TOTAL</span>
                            <span 
                                class="font-weight-bold " 
                                style="font-size:40px" 
                                v-html="formatNumber(formData.totalPrice)"
                                >
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="mb-3">
                        <input 
                            type="number" 
                            id="amount_paid"
                            name="amount_paid" 
                            class="form-control form-control-lg text-center" 
                            placeholder="Payment Received"
                            accesskey="p"
                            v-model="formData.amountPaid"
                        />
                    </div>
                    <div class="mb-3">
                        <input 
                            type="number" 
                            name="amount_change" 
                            class="form-control form-control-lg text-center" 
                            placeholder="Change"
                            v-model="formData.changeLabel"
                            readonly
                        />
                    </div>
                    <div class="mb-3">
                        <button 
                            class="btn btn-primary btn-lg w-100 mb-3" 
                            style="border-radius: 0px!important"
                            :disabled="show.isPayDisabled"
                            @click.prevent="submitTransaction"
                            >
                            Pay
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="complete-transaction" tabindex="-1" aria-labelledby="complete-transaction-Label" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="complete-transaction-Label">Transaction Completed</h5>
                    <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                        <i class="fas fa-times"></i>
                    </a>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-thumbs-up text-primary" style="font-size: 60px;line-height: 1em;"></i>
                    </div>
                    <div class="max-w-400 m-auto text-center">
                        <div style="font-size: 22px">Transaction Completed</div>
                        <p>Close this modal to proceed to new transaction</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Inventory -->
    <div class="modal fade" id="inventory" tabindex="-1" aria-labelledby="inventory-Label" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="inventory-Label">Medicines</h5>
                    <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                        <i class="fas fa-times"></i>
                    </a>
                </div>
                <div class="modal-body">
                    <div class="filters mb-4">
                        <div class="row">
                            <div class="col-lg-3 col-md-4 pr-md-0 mb-lg-0 mb-3">
                                <input type="text" name="item_code" class="form-control" v-model="inventory.filter.item_code" placeholder="Item Code" autofocus />
                            </div>
                            <div class="col-lg-3 col-md-4 pr-lg-0 mb-lg-0 mb-3">
                                <input type="text" name="item_name" class="form-control" v-model="inventory.filter.item_name" placeholder="Item Name" />
                            </div>
                            <div class="col-lg-4 col-md-4 pr-lg-0 mb-lg-0 mb-3">
                                <input type="text" name="item_classification" class="form-control" v-model="inventory.filter.item_classification" placeholder="Classification" />
                            </div>
                            <div class="col-lg-2 col-md-12">
                                <button type="button" class="btn btn-secondary w-100" @click="getInventory()">
                                    Search
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">Code</th>
                                    <th scope="col">Item name</th>
                                    <th scope="col">Classification</th>
                                    <th scope="col">Retail Price</th>
                                    <th scope="col">Stocks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr if="inventory.data.length" v-for="(item, index) in inventory.data">
                                    <td v-html="item.item_code"></td>
                                    <td v-html="item.item_name"></td>
                                    <td v-html="item.item_classification"></td>
                                    <td v-html="'Php.' + formatNumber(item.retail_price)"></td>
                                    <td v-html="item.total_qty - item.total_purchase"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer_script'); ?>
    <script>
        var webInfo = {
            baseUrl: '<?php echo URL::to('/'); ?>',
            currentUser:  {
                id: '<?php echo auth()->user()->id; ?>',
                firstname: '<?php echo auth()->user()->firstname; ?>',
                lastname: '<?php echo auth()->user()->lastname; ?>',
            },
        } 
    </script>
    <script src="<?php echo e(asset('js/pos.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinic\app\resources\views/pages/pos/index.blade.php ENDPATH**/ ?>