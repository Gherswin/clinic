

<?php $__env->startSection('content'); ?>
<div class="container staffs">
    <div class="row">
        <div class="form-header offset-md-2 col-md-8 mb-3 px-0">
            <h1 class="form-title">New Staff</h1>
        </div>
        
        <div class="form row d-flex justify-content-center">
            <form method="POST" action="<?php echo e(route('staffs.store')); ?>" class="col-lg-8 bg-white p-lg-5 py-3 border border-secondary-300">
                <?php echo $__env->make('pages.staffs.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinic\app\resources\views/pages/staffs/create.blade.php ENDPATH**/ ?>