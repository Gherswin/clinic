

<?php $__env->startSection('content'); ?>
<div class="container-fluid clinics">
    <div class="row">
        <div class="col-md-12 pl-lg-0">
            <div class="form-header offset-md-2 col-md-8 mb-3 px-0">
                <h1 class="form-title">New Clinic Information</h1>
            </div>

            <form method="POST" action="<?php echo e(route('clinics.store')); ?>" enctype="multipart/form-data" class="col-lg-8 offset-lg-2 bg-white p-lg-5 py-3 border border-secondary-300 mb-4">
                <?php echo $__env->make('pages.clinics.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinic\app\resources\views/pages/clinics/create.blade.php ENDPATH**/ ?>