<?php echo $__env->yieldContent('footer_script'); ?>
<?php /**PATH D:\laragon\www\clinic\app\resources\views/includes/footer.blade.php ENDPATH**/ ?>