

<?php $__env->startSection('content'); ?>
<div class="container appointments">
    <div class="row">
        <div class="form-header offset-md-2 col-md-8 mb-3 px-0">
            <h1 class="form-title">New Appointment</h1>
        </div>
        
        <div id="appointment__create" class="form row d-flex justify-content-center w-100">
            <form method="POST" action="<?php echo e(route('appointments.store')); ?>" class="col-lg-8 bg-white p-lg-5 py-3 border border-secondary-300">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <div class="form-filter col-md-12">
                        <div class="form-filter__inner d-flex align-items-center">
                            <label for="" class="nowrap mr-3 mb-0 d-md-block d-none" style="min-width:90px">Select Client</label>
                            <div class="w-100">
                                <vue-multiselect 
                                    class="form-control-multiselect w-100"
                                    v-model="selected.patientInfo"
                                    placeholder="Select Client"
                                    track-by="name"
                                    label="name"
                                    open-direction="bottom"
                                    :options="filteredPatients"
                                    :searchable="true"
                                    :show-pointer="false"
                                    :show-labels="false"
                                    :multiple="false"
                                    :internal-search="true"
                                    :close-on-select="true"
                                    :options-limit="700"
                                    :max-height="300"
                                    :show-no-results="false"
                                    @open="getPatients"
                                    @search-change="getPatients"
                                    @select="populateInfo"
                                    />
                                </vue-multiselect>
                            </div>
                            <div class="w-100 ml-3" style="max-width: 150px">
                                <a href="<?php echo e(route('patients.create')); ?>" class="btn btn-primary w-100">New Client</a>
                            </div>
                        </div>
                    </div>

                    <div class="form-filter col-md-12">
                        <div class="form-filter__inner d-flex align-items-center">
                            <label for="" class="nowrap mr-3 mb-0 d-md-block d-none" style="min-width:90px">Select Pet</label>
                            <div class="w-100">
                                <vue-multiselect 
                                    class="form-control-multiselect w-100"
                                    v-model="selected.petInfo"
                                    placeholder="Select Pet"
                                    track-by="name"
                                    label="name"
                                    open-direction="bottom"
                                    :options="filteredPets"
                                    :searchable="true"
                                    :show-pointer="false"
                                    :show-labels="false"
                                    :multiple="false"
                                    :internal-search="true"
                                    :close-on-select="true"
                                    :options-limit="700"
                                    :max-height="300"
                                    :show-no-results="false"
                                    @open="getPets"
                                    @search-change="getPets"
                                    @select="populatePetInfo"
                                    />
                                </vue-multiselect>
                            </div>
                            <div class="w-100 ml-3" style="max-width: 150px">
                                <a href="<?php echo e(route('pets.create')); ?>" class="btn btn-primary w-100">New Pet</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <input type="hidden" name="id" v-model="formData.id">
                    <input type="hidden" name="pet_id" v-model="formData.pet_id">
                    <div class="col-md-6 pr-md-0 mb-3">
                        <input 
                            id="name" 
                            type="text" 
                            class="form-control <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="firstname" 
                            v-model="formData.firstname"
                            value="<?php echo e(isset($appointment->firstname) ? $appointment->firstname : old('firstname')); ?>" 
                            required 
                            autocomplete="firstname" 
                            autofocus 
                            placeholder="First Name"
                            readonly
                        />
                        <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <input 
                            id="lastname" 
                            type="text" 
                            class="form-control <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="lastname"
                            v-model="formData.lastname"
                            value="<?php echo e(isset($appointment->lastname) ? $appointment->lastname : old('lastname')); ?>" 
                            required
                            autocomplete="lastname" 
                            placeholder="Last Name"
                            readonly
                        />
                
                        <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 pr-md-0 mb-3">
                        <input 
                            id="email" 
                            type="email" 
                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="email" 
                            v-model="formData.email"
                            value="<?php echo e(isset($appointment->email) ? $appointment->email : old('email')); ?>" 
                            required 
                            autocomplete="email" 
                            autofocus 
                            placeholder="Email Address"
                            readonly
                        />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <input 
                            id="phone" 
                            type="text" 
                            class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="phone"
                            v-model="formData.phone"
                            value="<?php echo e(isset($appointment->phone) ? $appointment->phone : old('phone')); ?>" 
                            required
                            autocomplete="phone" 
                            placeholder="Phone"
                            readonly
                        />
                
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-12 mb-3">
                        <input 
                            id="address" 
                            type="text" 
                            class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="address"
                            v-model="formData.address"
                            value="<?php echo e(isset($appointment->address) ? $appointment->address : old('address')); ?>" 
                            required
                            autocomplete="address" 
                            placeholder="Address"
                            readonly
                        />
                
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="appointment_date" class="mb-0">Appointment Date</label>
                        <input 
                            id="appointment_date" 
                            type="date" 
                            class="form-control <?php $__errorArgs = ['appointment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="appointment_date" 
                            v-model="formData.appointmentDate"
                            value="<?php echo e(isset($appointment->appointment_date) ? $appointment->appointment_date : old('appointment_date')); ?>" 
                            required 
                            autocomplete="appointment_date" 
                            min="<?php echo date('Y-m-d'); ?>"
                            placeholder="Appointment Date"
                        />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="appointment_time" class="mb-0">
                            Appointment Time 
                            <span style="font-size:12px">(Office Hour: 9am - 4pm only)</span>
                        </label>
                        <input 
                            id="appointment_time" 
                            type="time" 
                            class="form-control <?php $__errorArgs = ['appointment_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="appointment_time"
                            v-model="formData.appointmentTime"
                            value="<?php echo e(isset($appointment->appointment_time) ? $appointment->appointment_time : old('appointment_time')); ?>" 
                            required
                            min="09:00" 
                            max="16:00"
                            autocomplete="appointment_time" 
                            placeholder="Appointment Time"
                        />
                
                        <?php $__errorArgs = ['appointment_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="status" class="mb-0">Status</label>
                        <select name="status" class="form-control" v-model="formData.status">
                            <option value="approved" <?php echo e((isset($appointment->status) && $appointment->status == 'approved') || old('status') == 'approved' ? 'selected' : ''); ?>>Approved</option>
                            <option value="pending" <?php echo e((isset($appointment->status) && $appointment->status == 'pending') || old('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="cancelled" <?php echo e((isset($appointment->status) && $appointment->status == 'cancelled') || old('status') == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                            <option value="done" <?php echo e((isset($appointment->status) && $appointment->status == 'done') || old('status') == 'done' ? 'selected' : ''); ?>>Done</option>
                        </select>
                    </div>
                    <div class="col-md-12 mb-3">
                        <textarea 
                            id="message"
                            name="message"
                            v-model="formData.message"
                            placeholder="Message"
                            style="min-height:200px"
                            class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div>
                    <button type="submit" class="btn btn-primary btn-lg w-100">
                        <i class="far fa-save"></i> Save
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>
    <script>
        var webInfo = {
            baseUrl: '<?php echo URL::to('/'); ?>',
            action: 'add',
            params: {
                patient: '<?php echo $request->patient; ?>',
            },
        } 
    </script>
    <script src="<?php echo e(asset('js/form.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinic\app\resources\views/pages/appointments/create.blade.php ENDPATH**/ ?>