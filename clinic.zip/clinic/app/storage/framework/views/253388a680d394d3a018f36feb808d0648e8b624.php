

<?php $__env->startSection('content'); ?>
<div class="container-fluid appointments">
    <div class="row">
        <div class="form-header col-md-12 mb-3 px-0">
            <h1 class="form-title">Appointment Information</h1>
        </div>
        <?php if(session('success')): ?>
        <div class="col-md-12 mb-3 px-0">
            <div class="alert alert-success block">
                <b><span class="oi oi-info"></span></b> <?php echo session('success'); ?>

            </div>
        </div>
        <?php endif; ?>
        <div id="appointment__update" class="form d-flex flex-wrap w-100">
            
            <div class="col-lg-7 pl-lg-0">
                <?php if(count($sameInfo)): ?>
                    <div id="accordion" class="p-0 mb-3">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center bg-secondary" id="headingOne">
                                <h5 class="mb-0 text-light">There might be a duplicate client info on your record</h5>
                                <button class="btn btn-sm text-light" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    show
                                </button>
                            </div>
                            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                                <div class="card-body sameinfo__inner">
                                    <?php $__currentLoopData = $sameInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="sameinfo__item alert alert-success">
                                            <div class="sameinfo__item-content row mb-2">
                                                <div class="col-md-5 mb-2">
                                                    <strong>Name:</strong> <?php echo e($info->firstname); ?> <?php echo e($info->lastname); ?>

                                                </div>
                                                
                                                <div class="col-md-7 mb-2">
                                                    <strong>Address:</strong> <?php echo e($info->address); ?> 
                                                </div>
                                                <div class="col-md-5 mb-2">
                                                    <strong>Phone:</strong> <?php echo e($info->phone); ?>

                                                </div>
                                                <div class="col-md-7 mb-2">
                                                    <strong>Email:</strong> <?php echo e($info->email); ?>

                                                </div>
                                            </div>
                                            <div class="sameinfo__item-action row">
                                                <div class="col-md-6 mb-2">
                                                    <form method="POST" action="<?php echo e(route('appointments.merge')); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="appointment_id" value="<?php echo e($appointment->appointment_id); ?>">
                                                        <input type="hidden" name="parent" value="<?php echo e($appointment->patient_id); ?>">
                                                        <input type="hidden" name="child" value="<?php echo e($info->id); ?>">
                                                        <button type="submit" class="btn btn-sm btn-primary w-100 mb-2">Merge this record on this client info</a>
                                                    </form>
                                                </div>
                                                <div class="col-md-6 mb-2">
                                                    <form method="POST" action="<?php echo e(route('appointments.merge')); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="appointment_id" value="<?php echo e($appointment->appointment_id); ?>">
                                                        <input type="hidden" name="parent" value="<?php echo e($info->id); ?>">
                                                        <input type="hidden" name="child" value="<?php echo e($appointment->patient_id); ?>">
                                                        <button type="submit" class="btn btn-sm btn-primary w-100 mb-2">Merge this info for this record</a>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <form 
                    id="update-appointment-form" 
                    method="POST" 
                    action="<?php echo e(route('appointments.update', $appointment->appointment_id)); ?>" 
                    class="bg-white p-lg-5 py-3 border border-secondary-300"
                    >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group row">
                        
                        <div class="form-filter col-md-12 mb-3">
                            <h4>Client Information</h4>
                        </div>
                        <div class="col-md-6 pr-md-0 mb-3">
                            <input 
                                id="name" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="firstname" 
                                v-model="formData.firstname"
                                value="<?php echo e(isset($request->firstname) ? $request->firstname : ''); ?><?php echo e(isset($appointment->firstname) ? $appointment->firstname : old('firstname')); ?>" 
                                required 
                                autocomplete="firstname" 
                                autofocus 
                                placeholder="First Name"
                                readonly
                            />
                            <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <input 
                                id="lastname" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="lastname"
                                v-model="formData.lastname"
                                value="<?php echo e(isset($appointment->lastname) ? $appointment->lastname : old('lastname')); ?>" 
                                required
                                autocomplete="lastname" 
                                placeholder="Last Name"
                                readonly
                            />
                    
                            <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 pr-md-0 mb-3">
                            <input 
                                id="email" 
                                type="email" 
                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="email" 
                                v-model="formData.email"
                                value="<?php echo e(isset($appointment->email) ? $appointment->email : old('email')); ?>" 
                                required 
                                autocomplete="email" 
                                autofocus 
                                placeholder="Email Address"
                                readonly
                            />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <input 
                                id="phone" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="phone"
                                v-model="formData.phone"
                                value="<?php echo e(isset($appointment->phone) ? $appointment->phone : old('phone')); ?>" 
                                required
                                autocomplete="phone" 
                                placeholder="Phone"
                                readonly
                            />
                    
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                            <input 
                                id="address" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="address"
                                v-model="formData.address"
                                value="<?php echo e(isset($appointment->address) ? $appointment->address : old('address')); ?>" 
                                required
                                autocomplete="address" 
                                placeholder="Address"
                                readonly
                            />
                    
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-filter col-md-12 mb-3 mt-3">
                            <h4>Pet Information</h4>
                        </div>
                        <div class="col-md-12 mb-3">
                            <div class="d-flex">
                                <select name="pet_id" class="form-control">
                                    <?php if(count($pets)): ?>
                                        <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($pet->id); ?>" <?php echo e($pet->id == $appointment->pet_id ? "selected" : ''); ?>><?php echo e($pet->name); ?> - <?php echo e($pet->species); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option>No Available Pet</option>
                                    <?php endif; ?>
                                </select>
                                <?php if(!count($pets)): ?>  
                                    <a href="<?php echo e(route('pets.create', ['patient_id' => $appointment->patient_id])); ?>" class="btn btn-primary nowrap ml-2 px-3">New Pet</a>
                                <?php endif; ?>
                            </div>
                            <?php $__errorArgs = ['pet_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        

                        
                        <div class="form-filter col-md-12 mb-3 mt-3">
                            <h4>Appintment Details</h4>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="appointment_date" class="mb-0">Appointment Date</label>
                            <input 
                                id="appointment_date" 
                                type="date" 
                                class="form-control <?php $__errorArgs = ['appointment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="appointment_date" 
                                v-model="formData.appointmentDate"
                                value="<?php echo e(isset($appointment->appointment_date) ? $appointment->appointment_date : old('appointment_date')); ?>" 
                                required 
                                autocomplete="appointment_date" 
                                placeholder="Appointment Date"
                            />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="appointment_time" class="mb-0">
                                Appointment Time 
                                
                            </label>
                            <input 
                                id="appointment_time" 
                                type="time" 
                                class="form-control <?php $__errorArgs = ['appointment_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="appointment_time"
                                v-model="formData.appointmentTime"
                                value="<?php echo e(isset($appointment->appointment_time) ? $appointment->appointment_time : old('appointment_time')); ?>" 
                                required
                                
                                autocomplete="appointment_time" 
                                placeholder="Appointment Time"
                            />
                    
                            <?php $__errorArgs = ['appointment_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if(count($services)): ?>
                            <div class="col-md-12 mb-3">
                                <label for="service_id" class="mb-0">
                                    About this appointment all about
                                </label>

                                <select id="service_id" name="service_id" class="form-control">
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($service->id); ?>" <?php echo e(($service->id === $appointment->service_id) ? 'selected' : ''); ?>>
                                            <?php echo e($service->title); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                        
                                <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endif; ?>
                        <div class="col-md-12 mb-3">
                            <label for="status" class="mb-0">Status</label>
                            <select name="status" class="form-control" v-model="formData.status">
                                <option value="approved" <?php echo e((isset($appointment->status) && $appointment->status == 'approved') || old('status') == 'approved' ? 'selected' : ''); ?>>Approved</option>
                                <option value="pending" <?php echo e((isset($appointment->status) && $appointment->status == 'pending') || old('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="cancelled" <?php echo e((isset($appointment->status) && $appointment->status == 'cancelled') || old('status') == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                                <option value="done" <?php echo e((isset($appointment->status) && $appointment->status == 'done') || old('status') == 'done' ? 'selected' : ''); ?>>Done</option>
                            </select>
                        </div>
                        <div class="col-md-12 mb-3">
                            <textarea 
                                id="message"
                                name="message"
                                v-model="formData.message"
                                placeholder="Message"
                                style="min-height:200px"
                                class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e($appointment->message); ?></textarea>
                    
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="offset-md-8 col-md-4 px-0">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="far fa-save"></i> Update Appointment
                        </button>
                    </div>
                </form>
            </div>

            
            <div class="col-lg-5 mt-lg-0 mt-3 pr-lg-0">
                <div class="accordion px-0" id="reservation">
                    <div class="card">
                        <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="doctor-note-label">
                            <button 
                                class="btn text-light" 
                                type="button" 
                                data-toggle="collapse" 
                                data-target="#doctor-note" 
                                aria-expanded="true" 
                                aria-controls="collapseOne"
                                style="letter-spacing: 1px;"
                                >
                                <strong>Doctor's Note</strong>
                            </button>
                            <div class="d-flex">
                                
                                <button type="submit" class="btn btn-secondary px-4" form="update-appointment-form">
                                    Save
                                </button>
                            </div>
                        </div>
                  
                        <div id="doctor-note" class="collapse show" aria-labelledby="doctor-note-label" data-parent="#doctor-note">
                            <div class="card-body">
                                <textarea 
                                    id="findings"
                                    name="findings" 
                                    class="form-control" 
                                    style="min-height: 300px"
                                    form="update-appointment-form"
                                    ><?php echo e($appointment->findings); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<iframe name="print_frame" width="0" height="0" frameborder="0" src="about:blank"></iframe>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>
<script>
    var webInfo = {
        baseUrl: '<?php echo URL::to('/'); ?>',
        action: 'update',
        appointmentInfo: <?php echo json_encode($appointment); ?>,
    }
</script>
<script src="<?php echo e(asset('js/update-form.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinic\app\resources\views/pages/appointments/edit.blade.php ENDPATH**/ ?>