

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php if( count($errors) > 0 ): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger">
                    <?php echo e($error); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <form action="/login/post" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="redirect" value="<?php echo $redirect; ?>">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" class="form-control form-control-lg" placeholder="Username">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control form-control-lg" placeholder="Password">
            </div>
            <div>
                <button type="submit" class="btn btn-primary btn-lg btn-block">Login</button>
            </div>
            <div class="text-center mt-4">
                <a href="<?php echo e(route('password.update')); ?>" class="color-primary">Lost your password?</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\clinic\app\resources\views/pages/password/login.blade.php ENDPATH**/ ?>