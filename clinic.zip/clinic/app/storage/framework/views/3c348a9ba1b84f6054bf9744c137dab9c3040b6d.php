

<?php $__env->startSection('content'); ?>
<div class="container-fluid pets">
    <div class="row">
        <div class="form-header col-md-12 mb-3 px-0">
            <h1 class="form-title">Pet Information</h1>
        </div>
        
        <?php if(session('success')): ?>
        <div class="col-md-12 mb-3 px-0">
            <div class="alert alert-success block">
                <b><span class="oi oi-info"></span></b> <?php echo session('success'); ?>

            </div>
        </div>
        <?php endif; ?>
        
        <div class="col-lg-5 pl-lg-0">
            <form method="POST" action="<?php echo e(route('pets.update', $pet->id)); ?>" class="bg-white px-3 py-5 border border-secondary-300">
                <?php echo method_field('PUT'); ?>
                <?php echo $__env->make('pages.pets.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>

        <div class="col-lg-7 mt-lg-0 mt-3 pr-lg-0">
            <div class="accordion px-0" id="reservation">
                <div class="card">
                    <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="headingOne">
                        <button 
                            class="btn text-light" 
                            type="button" 
                            data-toggle="collapse" 
                            data-target="#appointment-history" 
                            aria-expanded="true" 
                            aria-controls="collapseOne"
                            style="letter-spacing: 1px;"
                            >
                            <strong>APPOINTMENT HISTORY</strong>
                        </button>
                        
                    </div>
              
                    <div id="appointment-history" class="collapse show" aria-labelledby="headingOne" data-parent="#reservation">
                        <div class="card-body table-responsive">
                            <?php if(count($appointments)): ?>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col"> Date</th>
                                        <th scope="col">Time</th>
                                        <th scope="col">Status</th>
                                        <th scope="col"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <tr id="row-<?php echo e($appointment->id); ?>">
                                        <td scope="row"><?php echo e($appointment->id); ?></td>
                                        <td class="nowrap"><?php echo e($appointment->appointment_date); ?></td>
                                        <td class="nowrap"><?php echo date('h:i a', strtotime($appointment->appointment_time)); ?></td>
                                        <td class="nowrap">
                                            <span class="<?php echo $appointment->status == 'approved' ? 'text-success' : ''; ?> <?php echo $appointment->status == 'cancelled' ? 'text-danger' : ''; ?>">
                                                <?php echo e($appointment->status); ?>

                                            </span>
                                        </td>
                                        <td class="text-center" style="width: 130px">
                                            <div class="nowrap">
                                                <a href="<?php echo e(route('appointments.edit', $appointment->id)); ?>" class="btn btn-primary btn-sm min-w-50" title="View Appointment">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <button type="button" class="btn btn-primary btn-sm min-w-50" title="View Doctor's Note" data-toggle="modal" data-target="#findings-<?php echo e($appointment->id); ?>">
                                                    <i class="fas fa-notes-medical"></i>
                                                </button>
                                                <button type="button" class="btn btn-secondary btn-sm min-w-50" title="Delete Appointment" data-toggle="modal" data-target="#delete-<?php echo e($appointment->id); ?>">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>

                                            <!-- Findings Modal -->
                                            <div class="modal fade" id="findings-<?php echo e($appointment->id); ?>" tabindex="-1" aria-labelledby="findings-<?php echo e($appointment->id); ?>-Label" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="findings-<?php echo e($appointment->id); ?>-Label">Doctor's Note</h5>
                                                            <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                                <i class="fas fa-times"></i>
                                                            </a>
                                                        </div>
                                                        <div class="modal-body">
                                                            <textarea class="form-control" style="min-height:250px" readonly><?php echo e($appointment->findings); ?></textarea>
                                                            
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
    
                                            <!-- Delete Modal -->
                                            <div class="modal fade" id="delete-<?php echo e($appointment->id); ?>" tabindex="-1" aria-labelledby="delete-<?php echo e($appointment->id); ?>-Label" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <form method="POST" action="<?php echo e(route('appointments.destroy', $appointment->id)); ?>" class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="delete-<?php echo e($appointment->id); ?>-Label">Delete Record</h5>
                                                            <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                                <i class="fas fa-times"></i>
                                                            </a>
                                                        </div>
                                                        <div class="modal-body">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <input type="hidden" name="id" value="<?php echo e($appointment->id); ?>">
                                                            <div class="text-center mb-3">
                                                                <i class="far fa-question-circle text-primary" style="font-size: 60px;line-height: 1em;"></i>
                                                            </div>
                                                            <div class="max-w-400 m-auto">
                                                                Are you sure you want to permanetly delete the appointment record for <strong><?php echo e($pet->name); ?> <?php echo e($pet->species); ?></strong>?
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-danger">Delete</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php else: ?>
                                <div class="text-center py-5"> No Appointment found.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<iframe name="print_frame" width="0" height="0" frameborder="0" src="about:blank"></iframe>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>
<script src="<?php echo e(asset('js/pets.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinic\app\resources\views/pages/pets/edit.blade.php ENDPATH**/ ?>