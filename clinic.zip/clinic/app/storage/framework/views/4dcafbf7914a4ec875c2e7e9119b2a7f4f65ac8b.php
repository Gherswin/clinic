

<?php $__env->startSection('content'); ?>
<div class="container-fluid clinics">
    <div class="row">
        <div class="form-header col-md-12 mb-3 px-0">
            <h1 class="form-title">Clinic Information</h1>
        </div>

        <div class="col-lg-5 pl-lg-0">
            <form id="clinic-form" method="POST" action="<?php echo e(route('clinics.update', $clinic->id)); ?>" enctype="multipart/form-data" class="bg-white px-3 py-5 border border-secondary-300">
                <?php echo method_field('PUT'); ?>
                <?php echo $__env->make('pages.clinics.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
        <div class="col-lg-7 mt-lg-0 mt-3 pr-lg-0">
            <div class="accordion px-0 mb-4" id="operating">
                <div class="card">
                    <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="headingOne">
                        <button 
                            class="btn text-light" 
                            type="button" 
                            data-toggle="collapse" 
                            data-target="#operating-hours" 
                            aria-expanded="true" 
                            aria-controls="collapseOne"
                            style="letter-spacing: 1px;"
                            >
                            <strong>Operating Hours</strong>
                        </button>
                    </div>
              
                    <div id="operating-hours" class="collapse show" aria-labelledby="headingOne" data-parent="#operating">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">Day</th>
                                        <th scope="col" class="nowrap">Time Start</th>
                                        <th scope="col" class="nowrap">Time End</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr valign="center">
                                        <td style="vertical-align:middle">Monday</td>
                                        <td>
                                            <input form="clinic-form" type="time" name="mon_timestart" value="<?php echo e(isset($clinic->mon_timestart) ? $clinic->mon_timestart : ''); ?>" class="form-control">
                                        </td>
                                        <td>
                                            <input form="clinic-form" type="time" name="mon_timeend" value="<?php echo e(isset($clinic->mon_timeend) ? $clinic->mon_timeend : ''); ?>" class="form-control">
                                        </td>
                                    </tr>   
                                    <tr valign="center">
                                        <td style="vertical-align:middle">Tuesday</td>
                                        <td>
                                            <input form="clinic-form" type="time" name="tue_timestart" value="<?php echo e(isset($clinic->tue_timestart) ? $clinic->tue_timestart : ''); ?>" class="form-control">
                                        </td>
                                        <td>
                                            <input form="clinic-form" type="time" name="tue_timeend" value="<?php echo e(isset($clinic->tue_timeend) ? $clinic->tue_timeend : ''); ?>" class="form-control">
                                        </td>
                                    </tr>   
                                    <tr valign="center">
                                        <td style="vertical-align:middle">Wednesday</td>
                                        <td>
                                            <input form="clinic-form" type="time" name="wed_timestart" value="<?php echo e(isset($clinic->wed_timestart) ? $clinic->wed_timestart : ''); ?>" class="form-control">
                                        </td>
                                        <td>
                                            <input form="clinic-form" type="time" name="wed_timeend" value="<?php echo e(isset($clinic->wed_timeend) ? $clinic->wed_timeend : ''); ?>" class="form-control">
                                        </td>
                                    </tr>   
                                    <tr valign="center">
                                        <td style="vertical-align:middle">Thursday</td>
                                        <td>
                                            <input form="clinic-form" type="time" name="thu_timestart" value="<?php echo e(isset($clinic->thu_timestart) ? $clinic->thu_timestart : ''); ?>" class="form-control">
                                        </td>
                                        <td>
                                            <input form="clinic-form" type="time" name="thu_timeend" value="<?php echo e(isset($clinic->thu_timeend) ? $clinic->thu_timeend : ''); ?>" class="form-control">
                                        </td>
                                    </tr>   
                                    <tr valign="center">
                                        <td style="vertical-align:middle">Friday</td>
                                        <td>
                                            <input form="clinic-form" type="time" name="fri_timestart" value="<?php echo e(isset($clinic->fri_timestart) ? $clinic->fri_timestart : ''); ?>" class="form-control">
                                        </td>
                                        <td>
                                            <input form="clinic-form" type="time" name="fri_timeend" value="<?php echo e(isset($clinic->fri_timeend) ? $clinic->fri_timeend : ''); ?>" class="form-control">
                                        </td>
                                    </tr>   
                                    <tr valign="center">
                                        <td style="vertical-align:middle">Saturday</td>
                                        <td>
                                            <input form="clinic-form" type="time" name="sat_timestart" value="<?php echo e(isset($clinic->sat_timestart) ? $clinic->sat_timestart : ''); ?>" class="form-control">
                                        </td>
                                        <td>
                                            <input form="clinic-form" type="time" name="sat_timeend" value="<?php echo e(isset($clinic->sat_timeend) ? $clinic->sat_timeend : ''); ?>" class="form-control">
                                        </td>
                                    </tr>   
                                    <tr valign="center">
                                        <td style="vertical-align:middle">Sunday</td>
                                        <td>
                                            <input form="clinic-form" type="time" name="sun_timestart" value="<?php echo e(isset($clinic->sun_timestart) ? $clinic->sun_timestart : ''); ?>" class="form-control">
                                        </td>
                                        <td>
                                            <input form="clinic-form" type="time" name="sun_timeend" value="<?php echo e(isset($clinic->sun_timestart) ? $clinic->sun_timestart : ''); ?>" class="form-control">
                                        </td>
                                    </tr>   
                                </tbody>
                            </table>
                        </div>
                        <div class="offset-md-8 col-md-4 pt-0 pr-3 pl-3 pb-3 ">
                            <button form="clinic-form" type="submit" class="btn btn-primary w-100">
                                <i class="far fa-save"></i> Save
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="accordion px-0" id="services">
                <div class="card">
                    <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="headingOne">
                        <button 
                            class="btn text-light" 
                            type="button" 
                            data-toggle="collapse" 
                            data-target="#services-body" 
                            aria-expanded="true" 
                            aria-controls="collapseOne"
                            style="letter-spacing: 1px;"
                            >
                            <strong>Services</strong>
                        </button>
                        <button class="btn btn-secondary" data-toggle="modal" data-target="#new-service">
                            Add Service
                        </button>
                    </div>
              
                    <div id="services-body" class="collapse show" aria-labelledby="headingOne" data-parent="#services">
                        <div class="table-responsive">
                            <?php if(count($services)): ?>
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col" class="nowrap">Details</th>
                                            <th scope="col" class="nowrap">Price</th>
                                            <th scope="col"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr valign="center">
                                            <td style="vertical-align:middle"><?php echo e($service->id); ?></td>
                                            <td>
                                                <strong><?php echo e($service->title); ?></strong><br />
                                                <?php echo e(Str::limit($service->description, 150)); ?>

                                            </td>
                                            <td class="nowrap">
                                                Php. <?php echo e(number_format($service->price, 2)); ?>

                                            </td>
                                            <td class="nowrap">
                                                <button type="button" href="#" class="btn btn-primary btn-sm min-w-50" title="View Details" data-toggle="modal" data-target="#edit-service-<?php echo e($service->id); ?>">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button type="button" class="btn btn-secondary btn-sm min-w-50" title="Delete" data-toggle="modal" data-target="#delete-service-<?php echo e($service->id); ?>">
                                                    <i class="fas fa-trash"></i>
                                                </button>

                                                <!-- Edit Modal -->
                                                <div class="modal fade" id="edit-service-<?php echo e($service->id); ?>" tabindex="-1" aria-labelledby="edit-service-<?php echo e($service->id); ?>-Label" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <form method="POST" action="<?php echo e(route('clinicservices.update', $service->id)); ?>" class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="edit-service-<?php echo e($service->id); ?>-Label">Update Services</h5>
                                                                <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                                    <i class="fas fa-times"></i>
                                                                </a>
                                                            </div>
                                                            <div class="modal-body">
                                                                <?php echo method_field('PUT'); ?>
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="clinic_id" value="<?php echo e($clinic->id); ?>">
                                                                <div class="col-md-12 mb-3">
                                                                    <label for="title" class="mb-0">Title</label>
                                                                    <input 
                                                                        id="title" 
                                                                        type="text" 
                                                                        class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                                        name="title" 
                                                                        value="<?php echo e($service->title); ?>"
                                                                        required 
                                                                        autofocus 
                                                                        placeholder="Title"
                                                                    />
                                                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="invalid-feedback" role="alert">
                                                                            <strong><?php echo e($message); ?></strong>
                                                                        </span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                                <div class="col-md-12 mb-3">
                                                                    <label for="description" class="mb-0">Description</label>
                                                                    <textarea 
                                                                        id="description"
                                                                        name="description"
                                                                        placeholder="Description"
                                                                        style="min-height:200px"
                                                                        class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                    ><?php echo e($service->description); ?></textarea>
                                                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="invalid-feedback" role="alert">
                                                                            <strong><?php echo e($message); ?></strong>
                                                                        </span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                                <div class="col-md-12 mb-3">
                                                                    <label for="price" class="mb-0">Price</label>
                                                                    <input 
                                                                        id="price" 
                                                                        type="number" 
                                                                        class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                                        name="price" 
                                                                        value="<?php echo e($service->price); ?>"
                                                                        placeholder="Price"
                                                                    />
                                                                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="invalid-feedback" role="alert">
                                                                            <strong><?php echo e($message); ?></strong>
                                                                        </span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-primary">Update</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>

                                                <!-- Modal -->
                                                <div class="modal fade" id="delete-service-<?php echo e($service->id); ?>" tabindex="-1" aria-labelledby="delete-service-<?php echo e($service->id); ?>-Label" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <form method="POST" action="<?php echo e(route('clinicservices.destroy', $service->id)); ?>" class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="delete-service-<?php echo e($service->id); ?>-Label">Delete Record</h5>
                                                                <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                                    <i class="fas fa-times"></i>
                                                                </a>
                                                            </div>
                                                            <div class="modal-body">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <input type="hidden" name="clinic_id" value="<?php echo e($clinic->id); ?>">
                                                                <input type="hidden" name="id" value="<?php echo e($service->id); ?>">
                                                                <div class="text-center mb-3">
                                                                    <i class="far fa-question-circle text-primary" style="font-size: 60px;line-height: 1em;"></i>
                                                                </div>
                                                                <div class="max-w-400 m-auto">
                                                                    Are you sure you want to permanetly delete the record of <strong><?php echo e($service->title); ?></strong>?
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-danger">Delete</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>  
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                    </tbody>
                                </table>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Modal -->
        <div class="modal fade" id="new-service" tabindex="-1" aria-labelledby="new-service-Label" aria-hidden="true">
            <div class="modal-dialog">
                <form method="POST" action="<?php echo e(route('clinicservices.store')); ?>" class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="new-service-Label">New Services</h5>
                        <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                            <i class="fas fa-times"></i>
                        </a>
                    </div>
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="clinic_id" value="<?php echo e($clinic->id); ?>">
                        <div class="col-md-12 mb-3">
                            <label for="title" class="mb-0">Title</label>
                            <input 
                                id="title" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="title" 
                                required 
                                autofocus 
                                placeholder="Title"
                            />
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="description" class="mb-0">Description</label>
                            <textarea 
                                id="description"
                                name="description"
                                placeholder="Description"
                                style="min-height:200px"
                                class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            ></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="price" class="mb-0">Price</label>
                            <input 
                                id="price" 
                                type="number" 
                                class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="price" 
                                placeholder="Price"
                            />
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\clinic\app\resources\views/pages/clinics/edit.blade.php ENDPATH**/ ?>