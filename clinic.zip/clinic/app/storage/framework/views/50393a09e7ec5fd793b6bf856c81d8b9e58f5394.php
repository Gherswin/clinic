<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="login">
    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body>
        <div class="container main-content d-flex flex-center h-100v">
            <div class="row w-100">
                <div class="col-md-4"></div>
                <div class="col-md-4">
                    <h3 class="text-center mb-4">VETERINARY CLINIC MANAGEMENT SYSTEM</h3>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\laragon\www\clinic\app\resources\views/layouts/login.blade.php ENDPATH**/ ?>