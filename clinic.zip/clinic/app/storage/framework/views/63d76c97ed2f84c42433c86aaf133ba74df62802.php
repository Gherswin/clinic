

<?php $__env->startSection('content'); ?>
<div class="container staffs">
    <div class="">
        <div class="form row d-flex justify-content-center">
            <?php if(session('success')): ?>
                <div class="col-md-8 mb-2">
                    <div class="alert alert-success block">
                        <b><span class="oi oi-info"></span></b> <?php echo session('success'); ?>

                    </div>
                </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('profile.update')); ?>" class="col-lg-8 bg-white p-lg-5 py-3 border border-secondary-300 mb-4">
                
                <?php echo csrf_field(); ?>

                <div class="form-group row">
                    <div class="col-md-12 mb-4">
                        <div class="form-header">
                            <h1 class="form-title">Personal Information</h1>
                        </div>
                    </div>
                    
                    <div class="col-md-6 pr-md-0 mb-3">
                        <label for="firstname">First Name</label>
                        <input 
                            id="firstname" 
                            type="text" 
                            class="form-control <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="firstname" 
                            value="<?php echo e(isset($staff->firstname) ? $staff->firstname : old('firstname')); ?>" 
                            required 
                            autocomplete="firstname" 
                            autofocus 
                            placeholder="First Name"
                        />
                        <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="lastname">Last Name</label>
                        <input 
                            id="lastname" 
                            type="text" 
                            class="form-control <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="lastname"
                            value="<?php echo e(isset($staff->lastname) ? $staff->lastname : old('lastname')); ?>" 
                            required
                            autocomplete="lastname" 
                            placeholder="Last Name"
                        />
                
                        <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="email">Email Address</label>
                        <input 
                            id="email" 
                            type="email" 
                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="email" 
                            value="<?php echo e(isset($staff->email) ? $staff->email : old('email')); ?>" 
                            required 
                            autocomplete="email" 
                            Placeholder="Email Address"   
                            readonly
                        />
                
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="username">Username</label>
                        <input 
                            id="username" 
                            type="text" 
                            class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="username" 
                            value="<?php echo e(isset($staff->username) ? $staff->username : old('username')); ?>" 
                            required 
                            autocomplete="username" 
                            placeholder="Username"
                            readonly
                        />
                
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-5">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="far fa-save"></i> Update Profile
                        </button>
                    </div>
                </div>
            </form>
            <form method="POST" action="<?php echo e(route('profile.update-password')); ?>" class="col-lg-8 bg-white p-lg-5 py-3 border border-secondary-300">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <div class="col-md-12 mb-4">
                        <div class="form-header">
                            <h3 class="form-title">Set New Password</h3>
                        </div>
                    </div>

                    <div class="col-md-6 pr-md-0 mb-3">
                        <label for="password">New Password</label>
                        <input 
                            id="password" 
                            type="password" 
                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="password" 
                            required 
                            autocomplete="new-password" 
                            placeholder="Set New Password"
                        />
                
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="password-confirm">Confirm New Password</label>
                        <input 
                            id="password-confirm" 
                            type="password" 
                            class="form-control" 
                            name="password_confirmation" 
                            required 
                            autocomplete="new-password" 
                            placeholder="Confirm New Password"
                        />
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="old-password">Confirm Old Password</label>
                        <input 
                            id="old-password" 
                            type="password" 
                            class="form-control <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="old_password" 
                            required 
                            autocomplete="old-password" 
                            placeholder="Confirm Old Password"
                        />

                        <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-5">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="far fa-save"></i> Change Password
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinic\app\resources\views/pages/profile/profile.blade.php ENDPATH**/ ?>