

<?php $__env->startSection('content'); ?>
<div class="container products">
    <div class="">
        <div class="header mb-4 text-center">
            <h1 class="form-title">Medcine Sales Report</h1>
        </div>
        <div class="records">
            <div class="filters mb-4">
                <form method="get" action="" class="row">
                    <div class="col-lg-5 col-md-6 pr-md-0 mb-lg-0 mb-3">
                        <select class="form-control" name="month_back">
                            <option value="12" <?php echo e(($request->month_back == 12) ? "selected" : ''); ?>>Last 12 months</option>
                            <option value="11" <?php echo e(($request->month_back == 11)? "selected" : ''); ?>>Last 11 months</option>
                            <option value="10"<?php echo e(($request->month_back == 10)? "selected" : ''); ?>>Last 10 months</option>
                            <option value="9" <?php echo e(($request->month_back == 9)? "selected" : ''); ?>>Last 9 months</option>
                            <option value="8" <?php echo e(($request->month_back == 8)? "selected" : ''); ?>>Last 8 months</option>
                            <option value="7" <?php echo e(($request->month_back == 7)? "selected" : ''); ?>>Last 7 months</option>
                            <option value="6" <?php echo e(($request->month_back == 6 || empty($request->month_back))? "selected" : ''); ?>>Last 6 months</option>
                            <option value="5" <?php echo e(($request->month_back == 5)? "selected" : ''); ?>>Last 5 months</option>
                            <option value="4" <?php echo e(($request->month_back == 4)? "selected" : ''); ?>>Last 4 months</option>
                            <option value="3" <?php echo e(($request->month_back == 3)? "selected" : ''); ?>>Last 3 months</option>
                        </select>
                    </div>
                    <div class="col-lg-5 col-md-6 pr-lg-0 mb-lg-0 mb-3">
                        <select class="form-control" name="medicine">
                            <?php if($medicines): ?>
                            <option value="" <?php echo e(empty($request->medicine) ? "selected" : ''); ?>>All</option>
                                <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e(($request->medicine == $item->id) ? "selected" : ''); ?>><?php echo e($item->item_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option>No Medicine Available</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-lg-2 col-md-12">
                        <button type="submit" class="btn btn-secondary w-100">
                            Submit
                        </button>
                    </div>
                </form>
            </div>
            <canvas id="myChart" style="width:100%;height:400px"></canvas>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>
    <script>
        var webInfo = {
            baseUrl: '<?php echo URL::to('/'); ?>',
            currentUser:  {
                id: '<?php echo auth()->user()->id; ?>',
                firstname: '<?php echo auth()->user()->firstname; ?>',
                lastname: '<?php echo auth()->user()->lastname; ?>',
            },
            data: <?php echo json_encode($report); ?>

        } 
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
    <script src="<?php echo e(asset('js/medicine-report.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinic\app\resources\views/pages/reports/products.blade.php ENDPATH**/ ?>