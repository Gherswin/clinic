

<?php $__env->startSection('content'); ?>
    <!-- Hero -->
    <div id="sign-up" class="hero section-container d-flex flex-center" style="background-image:url(<?php echo e(asset('images/hero.jpg')); ?>)">
        <div class="w-100" style="z-index: 10">       
          <div class="appointment-signup w-100 max-w-800 mx-auto bg-white p-lg-5 py-3 border border-secondary-300 mb-4">
            <h1 class="text-center max-w-600 mx-auto">
              Take Control of Your Pet's Health
            </h1>
            <div class="text-primary fs-20 text-center mb-4" style="font-size: 24px">
              Sign up now and simplify the appointment process for your furry friend
            </div>

            <div class="text-center mb-4">
              Already have an account? <a href="<?php echo e(route('login', ['redirect' => $redirect])); ?>" class="text-primary">Login here</a>
            </div>

            <?php if($errors->any()): ?>
              <?php echo implode('', $errors->all('<div class="alert alert-danger">
                :message
              </div>')); ?>

            <?php endif; ?>
            <form action="<?php echo e(route('signup.store')); ?>" method="POST" class="max-w-600 mx-auto">
              <div class="form-group row">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="redirect" value="<?php echo $redirect; ?>">
                <div class="col-md-6 pr-md-0 mb-3">
                  <label for="firstname">First Name</label>
                  <input type="text" name="firstname" id="firstname" class="form-control" required>
                  <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                    </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 mb-3">
                  <label for="lastname">Last Name</label>
                  <input type="text" name="lastname" id="lastname" class="form-control" required>
                  <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                    </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 pr-md-0 mb-3">
                  <label for="contact_no">Contact No.</label>
                  <input type="text" name="contact_no" id="contact_no" class="form-control" required>
                  <?php $__errorArgs = ['contact_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                    </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 mb-3">
                  <label for="email">Email</label>
                  <input type="email" name="email" id="email" class="form-control" required>
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                    </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-12 mb-3">
                  <label for="address">Address</label>
                  <input type="text" name="address" id="address" class="form-control">
                </div>
                <div class="col-md-6 pr-md-0 mb-3">
                  <label for="password">Password</label>
                  <input type="password" name="password" id="password" class="form-control" autocomplete="new-password"  required>
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                    </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 mb-3">
                  <label for="password_confirmation">Conifirm Password</label>
                  <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" autocomplete="new-password"  required>
                </div>
                <div class="col-md-5 offset-md-7 mb-3">
                  <button type="submit" class="btn btn-primary w-100">
                    Submit
                  </button>
                </div>
              </div>
            </form>
          </div> 
        </div>
    </div>
    <!-- End Hero -->
  <?php $__env->stopSection(); ?>
  
  
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\clinic\app\resources\views/pages/frontend/sign-up.blade.php ENDPATH**/ ?>