<?php echo csrf_field(); ?>
<div class="form-group row">
    <div class="col-md-6 pr-md-0 mb-3">
        <input 
            id="name" 
            type="text" 
            class="form-control <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
            name="firstname" 
            value="<?php echo e(isset($staff->firstname) ? $staff->firstname : old('firstname')); ?>" 
            required 
            autocomplete="firstname" 
            autofocus 
            placeholder="First Name"
        />
        <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6 mb-3">
        <input 
            id="lastname" 
            type="text" 
            class="form-control <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
            name="lastname"
            value="<?php echo e(isset($staff->lastname) ? $staff->lastname : old('lastname')); ?>" 
            required
            autocomplete="lastname" 
            placeholder="Last Name"
        />

        <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6 pr-md-0 mb-3">
        <select name="role" class="form-control" <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <option value="admin" <?php echo e((isset($staff->role) && $staff->role == 'admin') || old('role') == 'admin' ? 'selected' : ''); ?>>Administrator</option>
            <option value="staff" <?php echo e((isset($staff->role) && $staff->role == 'staff') || old('role') == 'staff' ? 'selected' : ''); ?>>Staff</option>
        </select>
        <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6 mb-3">
        <select name="status" class="form-control">
            <option value="active" <?php echo e((isset($staff->status) && $staff->status == 'active') || old('status') == 'active' ? 'selected' : ''); ?>>Active</option>
            <option value="blocked" <?php echo e((isset($staff->status) && $staff->status == 'blocked') || old('status') == 'blocked' ? 'selected' : ''); ?>>Blocked</option>
        </select>
    </div>
    <div class="col-md-6 pr-md-0 mb-3">
        <input 
            id="email" 
            type="email" 
            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
            name="email" 
            value="<?php echo e(isset($staff->email) ? $staff->email : old('email')); ?>" 
            required 
            autocomplete="email" 
            Placeholder="Email Address"   
            <?php echo e(Request::routeIs('staffs.edit') ? 'readonly' : ''); ?>

        />

        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6 mb-3">
        <input 
            id="username" 
            type="text" 
            class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
            name="username" 
            value="<?php echo e(isset($staff->username) ? $staff->username : old('username')); ?>" 
            required 
            autocomplete="username" 
            placeholder="Username"
            <?php echo e(Request::routeIs('staffs.edit') ? 'readonly' : ''); ?>

        />

        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <?php if(!Request::routeIs('staffs.edit')): ?>
    <div class="col-md-6 pr-md-0 mb-3">
        <input 
            id="password" 
            type="password" 
            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
            name="password" 
            required 
            autocomplete="new-password" 
            placeholder="Password"
        />

        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6 mb-3">
        <input 
            id="password-confirm" 
            type="password" 
            class="form-control" 
            name="password_confirmation" 
            required 
            autocomplete="new-password" 
            placeholder="Confirm Password"
        />
    </div>
    <?php endif; ?>
</div>
<div>
    <button type="submit" class="btn btn-primary btn-lg w-100">
        <i class="far fa-save"></i> Save
    </button>
</div>
  <?php /**PATH D:\laragon\www\clinic\app\resources\views/pages/staffs/form.blade.php ENDPATH**/ ?>