<div class="admin-sidebar">
    <div class="admin-sidebar__inner">
        <div class="sidebar__items ">
            <a href="<?php echo e(route('dashboard')); ?>" class="sidebar__items-link <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>">
                <i class="icon fas fa-tachometer-alt mr-2"></i> Dashboard
            </a>
        </div>
        <div class="sidebar__items">
            <a href="<?php echo e(route('appointments.index')); ?>" class="sidebar__items-link <?php echo e(Request::routeIs('appointments.*') ? 'active' : ''); ?>">
                <i class="icon fas fa-calendar-check mr-2"></i> Appointments
            </a>
        </div>
        <?php if(Auth::user()->role == 'admin'): ?>
            <div class="sidebar__items">
                <a href="<?php echo e(route('patients.index')); ?>" class="sidebar__items-link <?php echo e(Request::routeIs('patients.*') ? 'active' : ''); ?>">
                    <i class="icon fas fa-user-injured mr-2"></i>Clients 
                </a>
            </div>
        <?php endif; ?>
        <?php if(Auth::user()->role == 'admin'): ?>
            <div class="sidebar__items">
                <a href="<?php echo e(route('clinics.index')); ?>" class="sidebar__items-link <?php echo e(Request::routeIs('clinics.*') ? 'active' : ''); ?>">
                    <i class="icon fas fa-clinic-medical mr-2"></i>Clinics 
                </a>
            </div>
        <?php endif; ?>

        <div class="sidebar__items">
            <a href="<?php echo e(route('pets.index')); ?>" class="sidebar__items-link <?php echo e(Request::routeIs('pets.*') ? 'active' : ''); ?>">
                <i class="icon fas fa-paw mr-2"></i>Pets 
            </a>
        </div>
        
        <?php if(Auth::user()->role == 'admin' || Auth::user()->role == 'clinic-admin'): ?>
            <div class="sidebar__items">
                <a href="<?php echo e(route('staffs.index')); ?>" class="sidebar__items-link <?php echo e(Request::routeIs('staffs.*') ? 'active' : ''); ?>">
                    <i class="icon fas fa-users mr-2"></i> Staffs
                </a>
            </div>
        <?php endif; ?>
        <?php if(Auth::user()->role == 'clinic-admin'): ?>
            <div class="sidebar__items">
                <a href="<?php echo e(route('clinics.edit', Auth::user()->clinic_id)); ?>" class="sidebar__items-link <?php echo e(Request::routeIs('clinics.*') ? 'active' : ''); ?>">
                    <i class="icon fas fa-clinic-medical mr-2"></i> Clinic Information
                </a>
            </div>
        <?php endif; ?>

        <div class="sidebar__items">
            <a href="<?php echo e(route('profile')); ?>" class="sidebar__items-link <?php echo e(Request::routeIs('profile') ? 'active' : ''); ?>">
                <i class="fas fa-user-alt mr-2"></i> Profile
            </a>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\clinic\app\resources\views/includes/admin-sidebar.blade.php ENDPATH**/ ?>