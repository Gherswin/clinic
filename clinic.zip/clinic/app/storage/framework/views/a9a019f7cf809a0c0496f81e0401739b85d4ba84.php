

<?php $__env->startSection('content'); ?>
<div class="container-fluid staffs">
    <div class="">
        <div class="form row">
            <div class="dashboard__btns col-lg-12 px-0 d-flex flex-wrap">
                <div class="dashboard__btns-item col-md-4">
                    <a href="<?php echo e(route('appointments.create')); ?>" class="dashboard__btns-item-link">
                       <span>
                            <i class="icon fas fa-calendar-check"></i> 
                            New Appointments
                       </span>
                    </a>
                </div>

                <div class="dashboard__btns-item col-md-4">
                    <a href="<?php echo e(route('patients.index')); ?>" class="dashboard__btns-item-link">
                       <span>
                            <i class="icon fas fa-user-injured"></i> 
                            New Client
                       </span>
                    </a>
                </div>

                <div class="dashboard__btns-item col-md-4">
                    <a href="<?php echo e(route('staffs.index')); ?>" class="dashboard__btns-item-link">
                       <span>
                            <i class="icon fas fa-users"></i> 
                            Staffs
                       </span>
                    </a>
                </div>

                
            </div>
            
            <div class="mt-4 col-lg-6">
                <div class="accordion " id="upcoming-appointments-container">
                    <div class="card">
                        <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="upcoming-appointments-header">
                            <button 
                                class="btn text-light" 
                                type="button" 
                                data-toggle="collapse" 
                                data-target="#upcoming-appointments" 
                                aria-expanded="true" 
                                aria-controls="upcoming-appointments-header"
                                style="letter-spacing: 1px;"
                                >
                                <strong>This Week Appointments</strong>
                            </button>
                        </div>
                
                        <div id="upcoming-appointments" class="collapse show" aria-labelledby="headingOne" data-parent="#upcoming-appointments-container">
                            <div class="card-body table-responsive">
                                <?php if(count($thisWeekAppointments)): ?>
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">Name</th>
                                                <th scope="col">Appointment</th>
                                                <th scope="col" style="width: 100px">Status</th>
                                                <th scope="col" style="width: 100px"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $thisWeekAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <tr>
                                                <td scope="row"><?php echo e($appointment->firstname); ?> <?php echo e($appointment->lastname); ?></td>
                                                <td class="nowrap"><?php echo e($appointment->appointment_date); ?> - <?php echo date('H:i a', strtotime($appointment->appointment_time)); ?></td>
                                                <td class="nowrap"><?php echo e($appointment->status); ?></td>
                                                <td class="nowrap text-right">
                                                    <a href="<?php echo e(route('appointments.edit', $appointment->appointment_id)); ?>" class="btn btn-secondary btn-sm min-w-50" title="Edit"><i class="far fa-edit"></i></a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="text-center py-5"> No Appointment for this week.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="mt-4 col-lg-6">
                <div class="accordion " id="new-appointments-container">
                    <div class="card">
                        <div class="card-header bg-primary d-flex justify-content-between align-items-center" id="new-appointments-header">
                            <button 
                                class="btn text-light" 
                                type="button" 
                                data-toggle="collapse" 
                                data-target="#new-appointments" 
                                aria-expanded="true" 
                                aria-controls="new-appointments-header"
                                style="letter-spacing: 1px;"
                                >
                                <strong>Pending Appointments</strong>
                            </button>
                        </div>
                
                        <div id="new-appointments" class="collapse show" aria-labelledby="headingOne" data-parent="#new-appointments-container">
                            <div class="card-body table-responsive">
                                <?php if(count($pendingAppointments)): ?>
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">Name</th>
                                                <th scope="col">Appointment</th>
                                                <th scope="col" style="width: 100px">Status</th>
                                                <th scope="col" style="width: 100px"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $pendingAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <tr>
                                                <td scope="row"><?php echo e($appointment->firstname); ?> <?php echo e($appointment->lastname); ?></td>
                                                <td class="nowrap"><?php echo e($appointment->appointment_date); ?> - <?php echo date('H:i a', strtotime($appointment->appointment_time)); ?></td>
                                                <td class="nowrap"><?php echo e($appointment->status); ?></td>
                                                <td class="nowrap text-right">
                                                    <a href="<?php echo e(route('appointments.edit', $appointment->appointment_id)); ?>" class="btn btn-secondary btn-sm min-w-50" title="Edit"><i class="far fa-edit"></i></a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="text-center py-5"> No Pending Appointments.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\clinic\app\resources\views/pages/dashboard/index.blade.php ENDPATH**/ ?>