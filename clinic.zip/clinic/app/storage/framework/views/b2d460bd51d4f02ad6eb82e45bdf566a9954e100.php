<?php echo $__env->yieldContent('footer_script'); ?>
<?php /**PATH C:\laragon\www\clinic\app\resources\views/includes/footer.blade.php ENDPATH**/ ?>