

<?php $__env->startSection('content'); ?>
    <!-- Hero -->
    <div id="home" class="hero section-container d-flex flex-center" style="background-image:url(<?php echo e(asset('images/hero.jpg')); ?>)">
        <div class="container w-100">
            <h1 class="">Welcome to <span class="text-primary" style="font-weight:600">PawHub</span></h1>
            <h5 class="text-primary fs-20">Onsectetur adipiscing elit, sed do eiusmod tempor incididunt </h5>
        </div>
    </div>
    <!-- End Hero -->
    
    <!-- Partners -->
    <div id="partners" class="about section-container" style="background-color:#FFF">
        <div class="container section">
            <h2 class="text-center mb-5 text-primary font-weight-bold">Find a Clinic Near You</h2>
            <div class="">
                <form method="GET" action="<?php echo e(route('clinics')); ?>" class="search-form">
                    
                    <div class="search-form__body form-group">
                        <div class="search-form__input">
                            <input 
                                id="name" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="search" 
                                value="<?php echo e(old('search')); ?>" 
                                required 
                                autocomplete="search" 
                                placeholder="Search Address/Clinic Name "
                            />
                            <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="search-form__submit">
                            <button type="submit" class="btn btn-primary">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End Partners -->

    <!-- about -->
    <div id="about" class="about section-container">
        <div class="container section">
            <div class=" d-flex align-items-center row">
                <div class="col-md-6">
                    <img 
                        class="about__img"
                        src="<?php echo e(asset('images/intro.jpg')); ?>" 
                    />
                </div>
                <div class="col-md-6 about__content">
                    <h2 class="mb-4 font-weight-bold">We Are <span class="text-primary">Pet Hub Care</span> <br class="d-md-block d-none" />
                        A Medical Clinic</h2>
                    <div class="about__content-text mb-5">
                        A small river named Duden flows by their place and supplies it with the necessary regelialia. 
                        It is a paradisematic country, in which roasted parts of sentences fly into your mouth. 
                        It is a paradisematic country, in which roasted parts of sentences fly into your mouth.
                    </div>
                    <div class="about__ctas">
                        <a href="#make-an-appointment" class="btn btn-primary px-4 mx-2">
                            Make an Appointment
                        </a>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End about -->

    <!-- Services -->
    <div id="services" class="about section-container" style="background-color:#b95d2e">
        <div class="container section">
            <h2 class="text-center mb-5 text-white font-weight-bold">Our Services</h2>
            <div class="d-flex flex-wrap flex-center">
                <div class="services__item">
                    <img 
                        class="services__item-img"
                        src="<?php echo e(asset('images/services1.jpg')); ?>" 
                    />
                    <div class="services__item-details">
                        <h3 class="services__item-title">Emergency Services</h3>
                        <div class="services__item-content">
                            A small river named Duden flows by their place and supplies it with the necessary regelialia.
                        </div>
                    </div>
                </div>

                <div class="services__item">
                    <img 
                        class="services__item-img"
                        src="<?php echo e(asset('images/services2.jpg')); ?>" 
                    />
                    <div class="services__item-details">
                        <h3 class="services__item-title">Check Ups</h3>
                        <div class="services__item-content">
                            A small river named Duden flows by their place and supplies it with the necessary regelialia.
                        </div>
                    </div>
                </div>

                <div class="services__item">
                    <img 
                        class="services__item-img"
                        src="https://vcahospitals.com/-/media/vca/images/lifelearn-images-foldered/4988/dog_at_vet.png?la=en&hash=906EF6FDB83116F99EA8ECBA703D4AC6" 
                    />
                    <div class="services__item-details">
                        <h3 class="services__item-title">Pet Groom</h3>
                        <div class="services__item-content">
                            A small river named Duden flows by their place and supplies it with the necessary regelialia.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Services -->

    <!-- Make An Appointment -->
    <div id="make-an-appointment" class="appointment section-container" style="background-color:#f9ecd9">
        <div class="container section">
            <h2 class="text-center mb-5 text-primary font-weight-bold">Make An Appointment</h2>

            <div id="appointment__create" class="form row d-flex justify-content-center w-100">
                <form method="POST" action="<?php echo e(route('appointments.makeappointment')); ?>" class="appointment-form col-md-8">
                    <?php echo csrf_field(); ?>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success block">
                            <b><span class="oi oi-info"></span></b> <?php echo session('success'); ?>

                        </div>
                    <?php endif; ?>
                    <div class="form-group row">
                        <input type="hidden" name="id" v-model="formData.id">
                        <div class="col-md-12 mb-3">
                            <select name="clinic_id" class="form-control">
                                <option value="">Select Clinic</option>
                                <?php if($clinics): ?>
                                    <?php $__currentLoopData = $clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($clinic->id); ?>"><?php echo e($clinic->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="col-md-6 pr-md-0 mb-3">
                            <input 
                                id="name" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="firstname" 
                                value="<?php echo e(old('firstname')); ?>" 
                                required 
                                autocomplete="firstname" 
                                placeholder="First Name"
                            />
                            <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <input 
                                id="lastname" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="lastname"
                                value="<?php echo e(old('lastname')); ?>" 
                                required
                                autocomplete="lastname" 
                                placeholder="Last Name"
                            />
                    
                            <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 pr-md-0 mb-3">
                            <input 
                                id="email" 
                                type="email" 
                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="email" 
                                value="<?php echo e(old('email')); ?>" 
                                required 
                                autocomplete="email" 
                                placeholder="Email Address"
                            />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <input 
                                id="phone" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="phone"
                                value="<?php echo e(old('phone')); ?>" 
                                required
                                autocomplete="phone" 
                                placeholder="Phone"
                            />
                    
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                            <input 
                                id="address" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="address"
                                value="<?php echo e(old('address')); ?>" 
                                autocomplete="address" 
                                placeholder="Address"
                            />
                    
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 pr-md-0 mb-3">
                            <label for="appointment_date" class="mb-0">Appointment Date</label>
                            <input 
                                id="appointment_date" 
                                type="date" 
                                class="form-control <?php $__errorArgs = ['appointment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="appointment_date" 
                                v-model="formData.appointmentDate"
                                value="<?php echo e(isset($appointment->appointment_date) ? $appointment->appointment_date : old('appointment_date')); ?>" 
                                required 
                                autocomplete="appointment_date" 
                                placeholder="Appointment Date"
                            />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="appointment_time" class="mb-0">Appointment Time</label>
                            <input 
                                id="appointment_time" 
                                type="time" 
                                class="form-control <?php $__errorArgs = ['appointment_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="appointment_time"
                                v-model="formData.appointmentTime"
                                value="<?php echo e(isset($appointment->appointment_time) ? $appointment->appointment_time : old('appointment_time')); ?>" 
                                required
                                autocomplete="appointment_time" 
                                placeholder="Appointment Time"
                            />
                    
                            <?php $__errorArgs = ['appointment_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                            <textarea 
                                id="message"
                                name="message"
                                v-model="formData.message"
                                placeholder="Message"
                                style="min-height:200px"
                                class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                    
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                            <input id="iagree" type="checkbox" value="i-agree" checked required>
                            <label for="iagree">I agree to the <a href="/terms-and-conditions" target="_blank">Terms and Conditions</a> and <a href="/privacy-policy" target="blank">Privacy Policy</a></label>
                        </div>
                    </div>
    
                    <div style="col-md-12 p-md-0">
                        <button type="submit" class="btn btn-primary w-100" style="max-width: 230px">
                                Make An Appointment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End Make An Appointment -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinic\app\resources\views/pages/frontend/index.blade.php ENDPATH**/ ?>