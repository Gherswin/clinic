

<?php $__env->startSection('content'); ?>
<div class="container staffs">
    <div id="appointments" class="appointments">
        <div class="form-header mb-4">
            <h1 class="form-title">Appointments</h1>
        </div>
        
        <div class="btns-container mb-4">
            <a href="<?php echo e(route('appointments.create')); ?>" class="btn btn-primary w-100 max-w-200">Make An Appointment</a>
        </div>

        <div class="filters mb-4">
            <form id="" method="get" action="" class="row">
                <input type="hidden" name="date" :value="formData.date" />
                <?php if(Auth::user()->role == 'admin'): ?>
                <div class="col-lg-5 col-md-12 pr-lg-0 mb-lg-0 mb-3">
                    <input type="text" name="name" value="<?php echo e($request->name); ?>" class="form-control" placeholder="Client Name" autofocus />
                </div>
                <?php endif; ?>
                <div class="col-lg-3 col-md-6 pr-lg-0 mb-lg-0 mb-3">
                    <select name="status" class="form-control">
                        <option value="">All</option>
                        <option value="approved" <?php echo e(($request->status == 'approved') ? 'selected' : ''); ?>>Approved</option>
                        <option value="pending" <?php echo e(($request->status == 'pending') ? 'selected' : ''); ?>>Pending</option>
                        <option value="cancelled" <?php echo e(($request->status == 'cancelled') ? 'selected' : ''); ?>>Cancelled</option>
                        <option value="done" <?php echo e(($request->status == 'done') ? 'selected' : ''); ?>>Done</option>
                    </select>
                </div>
                
                <div class="col-lg-2 col-md-12 pr-lg-0 mb-lg-0 mb-3">
                    <a href="<?php echo e(route('appointments.index')); ?>" class="btn btn-outline-secondary d-block">Goto Today</a>
                </div>
                <div class="col-lg-2 col-md-12">
                    <button type="submit" class="btn btn-secondary w-100">
                        Search
                    </button>
                </div>
            </form>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success block">
                <b><span class="oi oi-info"></span></b> <?php echo session('success'); ?>

            </div>
        <?php endif; ?>
        <div class="appointments-ledger mb-4">
            <div class="appointments-ledger__item text-right" style="border: 0px;font-weight:600">
                Ledger:
            </div>
            <div class="appointments-ledger__item appointments-ledger__item--approved">
                Approved
            </div>
            <div class="appointments-ledger__item appointments-ledger__item--pending">
                Pending
            </div>
            <div class="appointments-ledger__item appointments-ledger__item--cancelled">
                Cancelled
            </div>
            <div class="appointments-ledger__item appointments-ledger__item--done">
                Done
            </div>
        </div>
        <div class="appointments-calendar">
            <vue-cal 
                class="" 
                
                :selected-date="formData.date" 
                :events="appointments" 
                events-on-month-view
                @ready="fetchAppointments" 
                @view-change="fetchAppointments"
                >
                <template #event="{event, view}">
                    <?php if(Auth::user()->role != 'clinic-client'): ?>
                    <a 
                        href="#"
                        class="appointment__title" 
                        data-toggle="modal" 
                        data-target="#appointment-detail"
                        v-html="event.title"
                        @click="selectAppointment(event)"
                    ></a>
                    <?php else: ?>
                    <a 
                        class="appointment__title" 
                        :href="`/appointments/${selectedAppointment.appointment_id}/edit`" 
                        v-html="event.title"
                        @click="selectAppointment(event)"
                        class="btn btn-secondary"
                    ></a>
                    <?php endif; ?>
                </template>
            </vue-cal>

            <?php if(Auth::user()->role != 'clinic-client'): ?>
            <!-- Modal -->
            <div class="modal fade" id="appointment-detail" tabindex="-1" aria-labelledby="appointment-detail-Label" aria-hidden="true">
                <div class="modal-dialog">
                    <form method="POST" action="<?php echo e(route('appointments.quickupdate')); ?>" class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="appointment-detail-Label">Appointment Details</h5>
                            <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                <i class="fas fa-times"></i>
                            </a>
                        </div>
                        <div class="modal-body row">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" :value="selectedAppointment.appointment_id" />
                            <div class="col-md-12">
                                <label for="name" class="mb-0">Client Name</label>
                                <input id="name" type="text" name="name" value="" class="form-control " :value="`${selectedAppointment.firstname} ${selectedAppointment.lastname}`" readonly />
                            </div>
                            <div class="col-md-12">
                                <label for="appointment_date" class="mb-0">Date of Appointment</label>
                                <input id="appointment_date" type="date" name="appointment_date"v-model="selectedAppointment.appointment_date" class="form-control " />
                            </div>
                            <div class="col-md-12">
                                <label for="appointment_time" class="mb-0">Start of Appointment </label>
                                <input id="appointment_time" type="time" name="appointment_time" v-model="selectedAppointment.appointment_time" class="form-control " />
                            </div>
                            <div class="col-md-12">
                                <label for="appointment_timeend" class="mb-0">End of Appointment</label>
                                <input id="appointment_timeend" type="time" name="appointment_timeend" v-model="selectedAppointment.appointment_timeend" class="form-control " />
                            </div>
                            <div class="col-md-12">
                                <label for="name" class="mb-0">Status</label>
                                <select name="status" class="form-control" v-model="selectedAppointment.status">
                                    <option value="approved">Approved</option>
                                    <option value="pending">Pending</option>
                                    <option value="cancelled">Cancelled</option>
                                    <option value="done">Done</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <a :href="`/appointments/${selectedAppointment.appointment_id}/edit`" type="button" class="btn btn-secondary">See Full Details</a>
                            <button type="submit" class="btn btn-primary">Update Appointment</button>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer_script'); ?>
    <script>
        var webInfo = {
            baseUrl: '<?php echo URL::to('/'); ?>',
            appointmentType: '<?php echo $appointmentType; ?>',
            currentUser:  {
                id: '<?php echo auth()->user()->id; ?>',
                clinic_id: '<?php echo auth()->user()->clinic_id; ?>',
                firstname: '<?php echo auth()->user()->firstname; ?>',
                lastname: '<?php echo auth()->user()->lastname; ?>',
            },
            params: {
                name: '<?php echo e($request->name); ?>',
                date: '<?php echo e($request->date ?? date("Y-m-d")); ?>',
                status: '<?php echo e($request->status); ?>',
            }
        } 
    </script>
    <script src="<?php echo e(asset('js/appointments.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\clinic\app\resources\views/pages/appointments/index.blade.php ENDPATH**/ ?>