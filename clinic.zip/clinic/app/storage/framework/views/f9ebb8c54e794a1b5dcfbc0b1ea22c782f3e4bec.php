

<?php $__env->startSection('content'); ?>
    <!-- Hero -->
    <div id="home" class="hero hero__md section-container d-flex flex-center" style="background-image:url(<?php echo e(asset('images/hero.jpg')); ?>)">
        <div class="container w-100">
            <h2 class="text-center mb-5 text-primary font-weight-bold">Find a Clinic Near You</h2>
            <div class="">
                <form method="GET" action="<?php echo e(route('clinics')); ?>" class="search-form">
                    <div class="search-form__body form-group">
                        <div class="search-form__input">
                            <input 
                                id="name" 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="search" 
                                value="<?php echo e($request->search); ?>" 
                                autocomplete="off" 
                                placeholder="Search Address/Clinic Name "
                            />
                            <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="search-form__submit">
                            <button type="submit" class="btn btn-primary">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End Hero -->
    
    <!-- Partners -->
    <div id="partners" class="about section-container" style="background-color:#f8fafc">
        <div class="container section">
            <?php if(count($clinics)): ?>
                <?php $__currentLoopData = $clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="clinic-card d-flex">
                        <div class="clinic-card__imgholder">
                            <img 
                                src="<?php echo e($clinic->image ? asset('images/clinics/' . $clinic->image) : asset('images/logo.jpg')); ?>"
                                class="clinic-card__img"
                            />
                        </div>
                        <div class="clinic-card__body">
                            <div class="clinic-card__header">
                                <div class="clinic-card__name"><?php echo e($clinic->name); ?></div>
                                <div class="clinic-card__address"><?php echo e($clinic->address); ?></div>
                            </div>
                            <div class="clinic-card__details">
                                <div class="clinic-card__contacts">
                                    <?php if($clinic->email): ?>
                                        <div class="clinic-card__contacts__item">
                                            <div class="clinic-card__label">Email: </div>
                                            <a href=" mailto:<?php echo e($clinic->email); ?>"><?php echo e($clinic->email); ?></a>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($clinic->email): ?>
                                        <div class="clinic-card__contacts__item">
                                            <div class="clinic-card__label">Phone: </div>
                                            <a href=" mailto:<?php echo e($clinic->contact_no); ?>"><?php echo e($clinic->contact_no); ?></a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php if(!empty($clinic->operating_hours)): ?>
                                    <div class="clinic-card__operaions">
                                        <div class="clinic-card__label">Operating Hours</div>
                                        <div class="clinic-card__hours">
                                            <?php $__currentLoopData = unserialize($clinic->operating_hours); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="clinic-card__hours__item">
                                                    <?php if($time['day'] === 'mon'): ?>
                                                        Monday
                                                    <?php elseif($time['day'] === 'tue'): ?>
                                                        Tuesday
                                                    <?php elseif($time['day'] === 'wed'): ?>
                                                        Wednesday
                                                    <?php elseif($time['day'] === 'thu'): ?>
                                                        Thursday
                                                    <?php elseif($time['day'] === 'fri'): ?>
                                                        Friday
                                                    <?php elseif($time['day'] === 'sat'): ?>
                                                        Saturday
                                                    <?php elseif($time['day'] === 'sun'): ?>
                                                        Sunday
                                                    <?php endif; ?>
                                                    <?php echo e(date("h:i a", strtotime($time['timestart']))); ?> - <?php echo e(date("h:i a", strtotime($time['timeend']))); ?>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="clinic-card__footer mt-4">
                                <a href="<?php echo e(route('clinics.show', $clinic->id)); ?>" class=" btn btn-primary">View Details</a>
                                <a href="<?php echo e(route('clinics.show', $clinic->id)); ?>/#make-an-appointment" class=" btn btn-secondary">Make An Appointment</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h2 class="text-center text-primary">No Record Found</h2>
            <?php endif; ?>

            <div class="clinics-pagination pagination">
                <?php echo $clinics->appends(Request::except('page'))->links(); ?>

            </div>
        </div>
    </div>
    <!-- End Partners -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinic\app\resources\views/pages/frontend/clinics.blade.php ENDPATH**/ ?>