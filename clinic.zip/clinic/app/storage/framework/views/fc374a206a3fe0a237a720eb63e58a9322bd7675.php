

<?php $__env->startSection('content'); ?>
<div class="container clinics">
    <div class="">
        <div class="form-header mb-4">
            <h1 class="form-title">Partners Information</h1>
        </div>
        
        <div class="btns-container mb-4">
            <a href="<?php echo e(route('clinics.create')); ?>" class="btn btn-primary w-100 max-w-200">New Clinic</a>
        </div>

        <div class="filters mb-4">
            <form method="get" action="" class="row">
                <div class="col-lg-4 col-md-6 pr-md-0 mb-lg-0 mb-3">
                    <input type="text" name="name" value="<?php echo e($request->name); ?>" class="form-control" placeholder="Name" autofocus />
                </div>
                <div class="col-lg-6 col-md-6 pr-lg-0 mb-lg-0 mb-3">
                    <input type="text" name="address" value="<?php echo e($request->address); ?>" class="form-control" placeholder="Address" />
                </div>
                <div class="col-lg-2 col-md-12">
                    <button type="submit" class="btn btn-secondary w-100">
                        Search
                    </button>
                </div>
            </form>
        </div>
        <div class="records">
            <?php if(session('success')): ?>
                <div class="alert alert-success block">
                    <b><span class="oi oi-info"></span></b> <?php echo session('success'); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Address</th>
                            <th scope="col">Email</th>
                            <th scope="col">Phone</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($clinics): ?> 
                            <?php $__currentLoopData = $clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr>
                                    <th scope="row"><?php echo e($clinic->id); ?></th>
                                    <td class="nowrap"><?php echo e($clinic->name); ?></td>
                                    <td class=""><?php echo e($clinic->address); ?></td>
                                    <td class="nowrap"><?php echo e($clinic->email); ?></td>
                                    <td class="nowrap"><?php echo e($clinic->contact_no); ?></td>
                                    <td class="text-center" style="width: 130px">
                                        <div class="nowrap">
                                            <a href="<?php echo e(route('clinics.edit', $clinic->id)); ?>" class="btn btn-primary btn-sm min-w-50" title="View Details"><i class="fas fa-eye"></i></a>
                                            <button type="button" class="btn btn-secondary btn-sm min-w-50" title="Delete" data-toggle="modal" data-target="#delete-<?php echo e($clinic->id); ?>">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>

                                        <!-- Modal -->
                                        <div class="modal fade" id="delete-<?php echo e($clinic->id); ?>" tabindex="-1" aria-labelledby="delete-<?php echo e($clinic->id); ?>-Label" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <form method="POST" action="<?php echo e(route('clinics.destroy', $clinic->id)); ?>" class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="delete-<?php echo e($clinic->id); ?>-Label">Delete Record</h5>
                                                        <a href="#" class="btn-close" data-dismiss="modal" aria-label="Close">
                                                            <i class="fas fa-times"></i>
                                                        </a>
                                                    </div>
                                                    <div class="modal-body">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <input type="hidden" name="id" value="<?php echo e($clinic->id); ?>">
                                                        <div class="text-center mb-3">
                                                            <i class="far fa-question-circle text-primary" style="font-size: 60px;line-height: 1em;"></i>
                                                        </div>
                                                        <div class="max-w-400 m-auto">
                                                            Are you sure you want to permanetly delete the record of <strong><?php echo e($clinic->name); ?></strong>?
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-danger">Delete</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="pagination">
                <?php echo $clinics->appends(Request::except('page'))->links(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinic\app\resources\views/pages/clinics/index.blade.php ENDPATH**/ ?>