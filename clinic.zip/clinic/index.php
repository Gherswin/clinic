<?php
// echo "homepage";
require(__DIR__ . '/app/public/index.php');