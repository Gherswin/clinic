<?php
// echo symlink('/home/steppsclients16/public_html/listingsync/app/storage/app/public', '/home/steppsclients16/public_html/listingsync/storage');
echo "Link Storage:<br>\n ";
echo symlink(__DIR__ . '/app/storage/app/public', __DIR__ . '/storage');

echo "Link css:<br>\n ";
echo symlink(__DIR__ . '/app/public/css', __DIR__ . '/css');
echo "Link js:<br>\n ";
echo symlink(__DIR__ . '/app/public/js', __DIR__ . '/js');
echo "Link fonts:<br>\n ";
echo symlink(__DIR__ . '/app/public/fonts', __DIR__ . '/fonts');

echo "exit page";