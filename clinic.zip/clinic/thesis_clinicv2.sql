-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 01, 2023 at 01:49 PM
-- Server version: 8.0.30
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thesis_clinic`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` bigint UNSIGNED NOT NULL,
  `clinic_id` int DEFAULT NULL,
  `patient_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pet_id` bigint DEFAULT NULL,
  `appointment_date` date DEFAULT NULL,
  `appointment_time` time DEFAULT NULL,
  `appointment_timeend` time NOT NULL,
  `services` json DEFAULT NULL,
  `message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `findings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `clinic_id`, `patient_id`, `pet_id`, `appointment_date`, `appointment_time`, `appointment_timeend`, `services`, `message`, `findings`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, '14', 1, '2023-03-18', '09:30:00', '11:30:00', '[\"1\", \"2\", \"5\"]', NULL, NULL, 'pending', '2023-02-11 10:36:22', '2023-02-28 10:04:53'),
(2, 3, '14', 3, '2023-03-20', '12:00:00', '13:30:00', '[\"6\"]', NULL, NULL, 'cancelled', '2023-02-11 11:19:20', '2023-02-28 10:04:53'),
(6, 3, '15', 7, '2023-03-21', '13:00:00', '14:00:00', '[\"6\"]', '', '', 'pending', '2023-02-12 01:51:25', '2023-02-28 10:04:53'),
(7, 2, '17', 8, '2023-03-18', '07:30:00', '09:30:00', '[\"2\", \"5\"]', NULL, NULL, 'pending', '2023-02-15 10:12:49', '2023-02-28 12:31:00'),
(8, 3, '17', 8, '2023-03-18', '12:00:00', '13:00:00', '[\"6\"]', NULL, NULL, 'pending', '2023-02-28 12:48:35', '2023-02-28 12:49:43');

-- --------------------------------------------------------

--
-- Table structure for table `clinics`
--

CREATE TABLE `clinics` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `operating_hours` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `clinics`
--

INSERT INTO `clinics` (`id`, `user_id`, `name`, `address`, `email`, `contact_no`, `operating_hours`, `image`, `created_at`, `updated_at`) VALUES
(1, 4, 'SM North EDSA', 'Upper Ground Floor, The Annex Building SM North Quezon City', 'jaycelcunanan30@gmail.com', '8396-9899', 'a:6:{i:0;a:3:{s:3:\"day\";s:3:\"mon\";s:9:\"timestart\";s:5:\"08:00\";s:7:\"timeend\";s:5:\"18:00\";}i:1;a:3:{s:3:\"day\";s:3:\"tue\";s:9:\"timestart\";s:5:\"08:00\";s:7:\"timeend\";s:5:\"18:00\";}i:2;a:3:{s:3:\"day\";s:3:\"wed\";s:9:\"timestart\";s:5:\"08:00\";s:7:\"timeend\";s:5:\"18:00\";}i:3;a:3:{s:3:\"day\";s:3:\"thu\";s:9:\"timestart\";s:5:\"08:00\";s:7:\"timeend\";s:5:\"18:00\";}i:4;a:3:{s:3:\"day\";s:3:\"fri\";s:9:\"timestart\";s:5:\"08:00\";s:7:\"timeend\";s:5:\"18:00\";}i:5;a:3:{s:3:\"day\";s:3:\"sat\";s:9:\"timestart\";s:5:\"08:00\";s:7:\"timeend\";s:5:\"12:00\";}}', '1670737849.jpg', NULL, '2022-12-11 05:50:49'),
(2, 5, 'Petbero', 'Dau, Mabalacat City, Pampanga', 'chito@gmail.com', '8396-9899', 'a:5:{i:0;a:3:{s:3:\"day\";s:3:\"mon\";s:9:\"timestart\";s:5:\"09:00\";s:7:\"timeend\";s:5:\"16:00\";}i:1;a:3:{s:3:\"day\";s:3:\"tue\";s:9:\"timestart\";s:5:\"09:00\";s:7:\"timeend\";s:5:\"16:00\";}i:2;a:3:{s:3:\"day\";s:3:\"wed\";s:9:\"timestart\";s:5:\"09:00\";s:7:\"timeend\";s:5:\"16:00\";}i:3;a:3:{s:3:\"day\";s:3:\"thu\";s:9:\"timestart\";s:5:\"09:00\";s:7:\"timeend\";s:5:\"16:00\";}i:4;a:3:{s:3:\"day\";s:3:\"fri\";s:9:\"timestart\";s:5:\"09:00\";s:7:\"timeend\";s:5:\"16:00\";}}', '1670838603.jpg', NULL, '2023-02-15 10:16:13'),
(3, 7, 'PetWise Animal Clinic', 'Ramram Arcade, Stalls 3-7, San AntonioGuagua, Pampanga, Philippines', 'taylor@gmail.com', '+63 917 638 5594', 'a:5:{i:0;a:3:{s:3:\"day\";s:3:\"mon\";s:9:\"timestart\";s:5:\"06:00\";s:7:\"timeend\";s:5:\"17:00\";}i:1;a:3:{s:3:\"day\";s:3:\"tue\";s:9:\"timestart\";s:5:\"06:00\";s:7:\"timeend\";s:5:\"17:00\";}i:2;a:3:{s:3:\"day\";s:3:\"wed\";s:9:\"timestart\";s:5:\"06:00\";s:7:\"timeend\";s:5:\"17:00\";}i:3;a:3:{s:3:\"day\";s:3:\"thu\";s:9:\"timestart\";s:5:\"06:00\";s:7:\"timeend\";s:5:\"17:00\";}i:4;a:3:{s:3:\"day\";s:3:\"fri\";s:9:\"timestart\";s:5:\"06:00\";s:7:\"timeend\";s:5:\"12:00\";}}', '', '2022-12-11 05:53:59', '2023-02-12 04:33:15'),
(4, NULL, 'Vet Precision Animal Health Centre', 'Gapan-Olongapo Rd., San Juan Nepomuceno, Betis Guagua, Pampanga, Philippines', 'test@gmail.com', '0917 824 6458', 'a:4:{i:0;a:3:{s:3:\"day\";s:3:\"mon\";s:9:\"timestart\";s:5:\"06:00\";s:7:\"timeend\";s:5:\"21:00\";}i:1;a:3:{s:3:\"day\";s:3:\"tue\";s:9:\"timestart\";s:5:\"06:00\";s:7:\"timeend\";s:5:\"21:00\";}i:2;a:3:{s:3:\"day\";s:3:\"wed\";s:9:\"timestart\";s:5:\"06:00\";s:7:\"timeend\";s:5:\"21:00\";}i:3;a:3:{s:3:\"day\";s:3:\"thu\";s:9:\"timestart\";s:5:\"06:00\";s:7:\"timeend\";s:5:\"21:00\";}}', '', NULL, '2022-12-11 06:24:21');

-- --------------------------------------------------------

--
-- Table structure for table `clinicservices`
--

CREATE TABLE `clinicservices` (
  `id` int NOT NULL,
  `clinic_id` int DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `price` float NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `clinicservices`
--

INSERT INTO `clinicservices` (`id`, `clinic_id`, `title`, `description`, `price`, `created_at`, `updated_at`) VALUES
(1, 2, 'Wellnes and sick exams', 'Our vets examine your pet from nose to tail—evaluating their overall health and recommending preventive care, diagnostics and treatments.', 500, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 2, 'Vaccinations', 'Vaccinations are recommended for all dogs, cats and ferrets to help protect your pet from deadly infectious diseases.', 800, '0000-00-00 00:00:00', '2022-12-12 10:39:13'),
(5, 2, 'Dental Care', 'Complete dental care diagnostics—including digital dental X-rays, anesthetized cleanings and common surgical procedures—help support their overall health.', 1000, '2022-12-12 10:47:19', '2022-12-12 10:47:19'),
(6, 3, 'Pest & Parasite Prevention & Testing', 'Help protect your pet from fleas, ticks, heartworms and other parasites year-round so they avoid deadly diseases.', 650, '2022-12-12 10:58:22', '2022-12-12 10:58:33');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `histories`
--

CREATE TABLE `histories` (
  `id` bigint UNSIGNED NOT NULL,
  `data_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `module` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2021_08_24_094829_create_appointments_table', 1),
(6, '2021_08_24_124444_create_patients_table', 1),
(7, '2021_09_03_102738_create_items_table', 1),
(8, '2021_09_03_102929_create_itemstocks_table', 1),
(9, '2021_09_03_230738_create_purchases_table', 2),
(10, '2021_09_03_230800_create_purchasedetails_table', 3),
(11, '2021_09_18_082141_create_pets_table', 4),
(12, '2021_11_14_144658_create_histories_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` bigint UNSIGNED NOT NULL,
  `firstname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `firstname`, `lastname`, `email`, `phone`, `address`, `created_at`, `updated_at`) VALUES
(1, 'Jenny', 'Smith', 'jenny@gmail.com', '0908 123 4568', 'Balibago, Angeles City', '2022-12-11 07:03:19', '2022-12-12 10:59:35'),
(2, 'John Jason', 'Smith', 'smith@gmail.com', '0987 654 3422', 'Test Address', '2022-12-11 08:15:52', '2022-12-11 08:15:52'),
(3, 'Jomar', 'De leon', 'deleon@gmail.com', '0908 123 4000', 'Gapan-Olongapo Rd., San Juan Nepomuceno, Betis Guagua, Pampanga, Philippines', '2022-12-11 11:12:38', '2022-12-11 11:12:38'),
(4, 'Sangre', 'Luna', 'luna@gmail.com', '0908 123 1234', 'Angeles City', '2022-12-11 11:38:11', '2022-12-11 11:38:11'),
(5, 'Jay', 'Cun', 'jay@gmail.com', '0987 654 3210', 'Balibago, Angeles City', '2023-02-11 00:02:33', '2023-02-11 00:14:16');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pets`
--

CREATE TABLE `pets` (
  `id` bigint UNSIGNED NOT NULL,
  `patient_id` int DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `species` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `breed` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weight` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clinics` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pets`
--

INSERT INTO `pets` (`id`, `patient_id`, `name`, `species`, `breed`, `birthdate`, `gender`, `color`, `weight`, `clinics`, `created_at`, `updated_at`) VALUES
(1, 14, 'Bartolo', 'Dog', 'Aspin', '2018-09-05', 'male', 'Brown', '5KG', 'null', '2022-12-11 07:07:01', '2023-02-11 11:22:54'),
(2, 4, 'Orange', 'Cat', 'cat', '2020-06-02', 'female', 'Orange', '1.2 Kg', 'null', '2022-12-11 11:44:42', '2022-12-11 11:44:42'),
(3, 14, 'Chany', 'Dog', 'Aspin', '2020-11-30', 'female', 'Black', '3kg', 'null', '2022-12-12 09:11:51', '2023-02-11 11:22:36'),
(7, 15, 'Snow', 'Fish', 'Hito', '2022-11-30', 'female', 'Orange', '1.2 Kg', 'null', '2023-02-12 01:51:25', '2023-02-12 01:51:25'),
(8, 17, 'Carl', 'Dog', 'Aspin', '2020-01-01', 'female', 'Brown', '5.6 KG', '[\"2\", \"3\"]', '2023-02-15 10:12:49', '2023-02-28 12:48:35'),
(9, 17, 'Marl', 'Dog', 'bulldog', '2022-11-04', 'male', 'brown', '5.2 KG', '[\"2\"]', '2023-02-28 11:15:14', '2023-02-28 11:15:14');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `clinic_id` int DEFAULT NULL,
  `firstname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `clinic_id`, `firstname`, `lastname`, `address`, `contact_no`, `email`, `username`, `role`, `status`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 0, 'John', 'Doe', '', '', 'jaycelcunanan@gmail.com', 'johndoe', 'admin', 'active', NULL, '$2y$10$hJl3rlkTaOTg1Uk8Wllsi.otxGzqSe/o/R3HSjYjrzlNi3nPuk5NK', 'RiGfaGtVCxXRSzkTrYzNlUsoAtydFC0U5bUWzFe8SJypJXXrqL9i6Dwckjw6', '2021-09-03 10:33:52', '2022-12-11 11:40:02'),
(4, 1, 'Rikko', 'Blanco', '', '', 'jaycelcunanan30@gmail.com', 'rikkoblanco', 'clinic-admin', 'active', NULL, '$2y$10$U3J6di5LQvDhErZoapUPU.Sk/6teCqSxEvOk9lJKfvmI7KkiBbq7G', NULL, NULL, NULL),
(5, 2, 'Chito', 'Miranda', '', '', 'chito@gmail.com', 'chitomiranda', 'clinic-admin', 'active', NULL, '$2y$10$qDHQxObmKUOmMVfzJcst6.plRRFv859zvTnVeJZ1XlnXpfnL11TWq', NULL, NULL, NULL),
(6, 3, 'Arnel', 'Pineda', '', '', 'arnel@gmail.com', 'arnelpineda', 'clinic-staff', 'active', NULL, '$2y$10$XTi2kqx/IXxEFxFGe0EM9u0zXVSLVQ1FNzNThtEmp6qyif6LyYFpC', NULL, NULL, NULL),
(7, 3, 'Taylor', 'Swift', '', '', 'taylor@gmail.com', 'taylorswith', 'clinic-admin', 'active', NULL, '$2y$10$sS9m8x9i7WAYhZ6FCZ3aRewkJS6wisN.arje0j5ehK/FnBJauq34y', NULL, NULL, NULL),
(14, 0, 'Jayden', 'Cun', 'Balibago, Angeles City', '0987 654 3210', 'jay@gmail.com', NULL, 'clinic-client', 'active', NULL, '$2y$10$fe6HIJVKMyYM6Y56D/ULe.lnyyL2lpZBKhZWK5FkpR5dNnYLcOoXq', NULL, '2023-02-11 00:02:33', '2023-02-11 00:24:42'),
(15, 0, 'Teresa', 'Bau', 'Dau, Mabalacat City', '0983 214 6578', 'teresa@gmail.com', NULL, 'clinic-client', 'active', NULL, 'LMZz4nuT', NULL, '2023-02-11 00:40:41', '2023-02-11 00:40:41'),
(16, 3, 'Arriana', 'Grande', NULL, NULL, 'ariana@gmail.com', 'ariana', 'clinic-staff', 'active', NULL, '$2y$10$xuV08WO4KHXhOMU4LfeDp.wDdng9EkuQl1HIdnBzggix.L1DKL4q.', NULL, NULL, NULL),
(17, 0, 'Kyle', 'Santino', NULL, '0987 654 1230', 'kyle@gmail.com', NULL, 'clinic-client', 'active', NULL, '$2y$10$2lQQ743TGA.btCJZqfsA5OSVCeKIQ3EjDDQ2PbgupymOdryEFlwfW', NULL, '2023-02-15 10:11:00', '2023-02-15 10:11:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clinics`
--
ALTER TABLE `clinics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clinicservices`
--
ALTER TABLE `clinicservices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `histories`
--
ALTER TABLE `histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `pets`
--
ALTER TABLE `pets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_username_unique` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `clinics`
--
ALTER TABLE `clinics`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `clinicservices`
--
ALTER TABLE `clinicservices`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `histories`
--
ALTER TABLE `histories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pets`
--
ALTER TABLE `pets`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
